// ✅ alerts.js (constant alert badge count)

// --- Run when the page loads ---
document.addEventListener("DOMContentLoaded", () => {
  // Load saved alert count or set a default
  const savedCount = localStorage.getItem("alertCount");

  if (!savedCount) {
    // Set default alert count ONCE (e.g., 14)
    const defaultCount = 14;
    localStorage.setItem("alertCount", defaultCount);
    updateAlertCountDisplay(defaultCount);
  } else {
    updateAlertCountDisplay(savedCount);
  }
});

// --- Function to update the alert badge everywhere ---
function updateAlertCountDisplay(count = localStorage.getItem("alertCount")) {
  const navBadge = document.getElementById("navAlertCount");
  if (navBadge) {
    navBadge.textContent = count > 0 ? count : "";
    navBadge.style.display = count > 0 ? "inline-block" : "none";
  }

  const activeLabel = document.getElementById("activeAlertCount");
  if (activeLabel) activeLabel.textContent = `${count} Active Alerts`;
}

// --- Optional: Function to manually update or change alert count ---
function setAlertCount(newCount) {
  localStorage.setItem("alertCount", newCount);
  updateAlertCountDisplay(newCount);
}

function toggleSettings() {
    const dropdown = document.getElementById('settingsDropdown');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    updateSettingsDisplay();
}

function updateSettingsDisplay() {
    const commonSettings = PharmacySettings.getModuleSettings('common');
    
    // Update common toggles
    document.getElementById('darkModeToggle').checked = commonSettings.darkMode;
    document.getElementById('notificationsToggle').checked = commonSettings.desktopNotifications;
    document.getElementById('soundToggle').checked = commonSettings.soundEnabled;
    document.getElementById('autoRefreshToggle').checked = commonSettings.autoRefresh;
    
    // Update module-specific displays
    const currentPage = getCurrentPageModule();
    updateModuleSpecificDisplays(currentPage);
}

function getCurrentPageModule() {
    const path = window.location.pathname;
    if (path.includes('alerts')) return 'alerts';
    if (path.includes('billing')) return 'billing';
    if (path.includes('inventory')) return 'inventory';
    if (path.includes('dashboard')) return 'dashboard';
    return 'common';
}

function updateModuleSpecificDisplays(module) {
    const settings = PharmacySettings.getModuleSettings(module);
    
    switch(module) {
        case 'alerts':
            document.getElementById('currentThreshold').textContent = settings.lowStockThreshold + ' units';
            document.getElementById('currentExpiryDays').textContent = settings.expiryDays + ' days';
            break;
        case 'billing':
            document.getElementById('currentTaxRate').textContent = settings.taxRate + '%';
            document.getElementById('currentCurrency').textContent = settings.currency;
            break;
        case 'inventory':
            document.getElementById('currentThreshold').textContent = settings.lowStockThreshold + ' units';
            document.getElementById('currentItemsPerPage').textContent = settings.itemsPerPage;
            break;
    }
}

// Module-specific setting handlers
function showModuleSettings() {
    const module = getCurrentPageModule();
    switch(module) {
        case 'alerts':
            alertsSettings.showAlertsSettingsModal();
            break;
        case 'billing':
            billingSettings.showBillingSettingsModal();
            break;
        case 'inventory':
            inventorySettings.showInventorySettingsModal();
            break;
        default:
            showCommonSettingsModal();
    }
}