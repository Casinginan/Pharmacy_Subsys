// inventory_admin.js - Inventory Management for PharmaCare Admin

class InventoryManager {
    constructor() {
        this.inventoryData = [];
        this.currentEditId = null;
        this.CURRENCY = {
            symbol: '₱',
            code: 'PHP',
            locale: 'en-PH',
            decimalPlaces: 2
        };
        this.init();
    }

    init() {
        this.loadSampleData();
        this.setupEventListeners();
        this.renderInventoryTable();
        this.updateAlerts();
        this.addExportButton();
        this.setupModalEvents();
        console.log("Inventory Manager initialized successfully!");
    }

    // Dummy Sample Data with Philippine Peso prices
    loadSampleData() {
        this.inventoryData = [
            {
                id: 1,
                name: "Paracetamol 500mg",
                batchNumber: "PAR2024001",
                quantity: 150,
                expiryDate: "2025-06-15",
                supplier: "MedCorp Ltd",
                price: 12.50,
                status: "In Stock",
                minStockLevel: 20
            },
            {
                id: 2,
                name: "Amoxicillin 250mg",
                batchNumber: "AMX2024002",
                quantity: 8,
                expiryDate: "2024-12-20",
                supplier: "PharmaPhil Inc",
                price: 45.75,
                status: "Low Stock",
                minStockLevel: 15
            }
            // ... rest of your sample data
        ];
    }

    setupEventListeners() {
        const searchInput = document.getElementById('searchInput');
        const addMedicineBtn = document.getElementById('addMedicineBtn');
        const filterBtn = document.getElementById('filterBtn');

        console.log("Setting up event listeners...");

        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.handleSearch(e));
            console.log("Search input listener added");
        } else {
            console.error("Search input not found!");
        }
        
        if (addMedicineBtn) {
            addMedicineBtn.addEventListener('click', () => this.openAddMedicineModal());
            console.log("Add medicine button listener added");
        } else {
            console.error("Add medicine button not found!");
        }

        if (filterBtn) {
            filterBtn.addEventListener('click', () => this.openFilterModal());
            console.log("Filter button listener added");
        } else {
            console.error("Filter button not found!");
        }
    }

    setupModalEvents() {
        // Add Medicine Modal Events
        const addModal = document.getElementById('addMedicineModal');
        const cancelBtn = document.getElementById('cancelMedicineBtn');
        const saveBtn = document.getElementById('saveMedicineBtn');

        if (addModal && cancelBtn && saveBtn) {
            // Close modal when Cancel button is clicked
            cancelBtn.addEventListener('click', () => {
                this.closeAddMedicineModal();
            });

            // Save medicine when Save button is clicked
            saveBtn.addEventListener('click', () => {
                this.saveMedicine();
            });

            // Close modal when clicking outside
            addModal.addEventListener('click', (e) => {
                if (e.target === addModal) {
                    this.closeAddMedicineModal();
                }
            });

            // Close modal with Escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && !addModal.classList.contains('hidden')) {
                    this.closeAddMedicineModal();
                }
            });
        } else {
            console.warn("Add medicine modal elements not found");
        }

        // Edit Medicine Modal Events
        const editModal = document.getElementById('editMedicineModal');
        const cancelEditBtn = document.getElementById('cancelEditMedicineBtn');
        const updateBtn = document.getElementById('updateMedicineBtn');

        if (editModal && cancelEditBtn && updateBtn) {
            cancelEditBtn.addEventListener('click', () => {
                this.closeEditMedicineModal();
            });

            updateBtn.addEventListener('click', () => {
                this.updateMedicine();
            });

            editModal.addEventListener('click', (e) => {
                if (e.target === editModal) {
                    this.closeEditMedicineModal();
                }
            });
        }
    }

    openAddMedicineModal() {
        const modal = document.getElementById('addMedicineModal');
        if (!modal) {
            console.error("Add medicine modal not found!");
            return;
        }
        
        modal.classList.remove('hidden');
        
        // Reset form
        const form = document.getElementById('medicineForm');
        if (form) form.reset();
        
        // Generate new batch number
        const batchNumberInput = document.getElementById('batchNumber');
        if (batchNumberInput) batchNumberInput.value = this.generateBatchNumber();
        
        // Set default expiry date to 1 year from now
        const expiryDateInput = document.getElementById('expiryDate');
        if (expiryDateInput) {
            const oneYearFromNow = new Date();
            oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);
            expiryDateInput.value = oneYearFromNow.toISOString().split('T')[0];
        }
        
        // Set default minimum stock level
        const minStockInput = document.getElementById('minStockLevel');
        if (minStockInput) minStockInput.value = 10;
        
        // Set focus to medicine name
        const medicineNameInput = document.getElementById('medicineName');
        if (medicineNameInput) medicineNameInput.focus();
    }

    closeAddMedicineModal() {
        const modal = document.getElementById('addMedicineModal');
        if (modal) modal.classList.add('hidden');
    }

    openEditMedicineModal(medicineId) {
        const medicine = this.inventoryData.find(item => item.id === medicineId);
        if (!medicine) {
            console.error("Medicine not found for ID:", medicineId);
            return;
        }
        
        this.currentEditId = medicineId;
        
        const modal = document.getElementById('editMedicineModal');
        if (!modal) {
            console.error("Edit medicine modal not found!");
            // Fallback to simple prompt for demo
            this.editMedicineWithPrompt(medicineId);
            return;
        }
        
        modal.classList.remove('hidden');
        
        // Populate form with medicine data
        document.getElementById('editMedicineName').value = medicine.name;
        document.getElementById('editBatchNumber').value = medicine.batchNumber;
        document.getElementById('editQuantity').value = medicine.quantity;
        document.getElementById('editPrice').value = medicine.price;
        document.getElementById('editExpiryDate').value = medicine.expiryDate;
        document.getElementById('editSupplier').value = medicine.supplier;
        document.getElementById('editMinStockLevel').value = medicine.minStockLevel;
        
        // Set focus to medicine name
        document.getElementById('editMedicineName').focus();
    }

    closeEditMedicineModal() {
        const modal = document.getElementById('editMedicineModal');
        if (modal) modal.classList.add('hidden');
        this.currentEditId = null;
    }

    // Fallback edit method if modal doesn't exist
    editMedicineWithPrompt(medicineId) {
        const medicine = this.inventoryData.find(item => item.id === medicineId);
        if (!medicine) return;

        const newPrice = parseFloat(prompt(`Enter new price for ${medicine.name}:`, medicine.price));
        if (isNaN(newPrice)) return;

        const newQuantity = parseInt(prompt(`Enter new quantity for ${medicine.name}:`, medicine.quantity));
        if (isNaN(newQuantity)) return;

        this.updateMedicineData(medicineId, {
            price: newPrice,
            quantity: newQuantity
        });
    }

    saveMedicine() {
        const form = document.getElementById('medicineForm');
        if (!form) {
            console.error("Medicine form not found!");
            return;
        }
        
        // Validate form
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const medicineData = {
            name: document.getElementById('medicineName').value,
            batchNumber: document.getElementById('batchNumber').value,
            quantity: parseInt(document.getElementById('quantity').value),
            price: parseFloat(document.getElementById('price').value),
            expiryDate: document.getElementById('expiryDate').value,
            supplier: document.getElementById('supplier').value,
            minStockLevel: parseInt(document.getElementById('minStockLevel').value)
        };

        this.addMedicine(medicineData);
        this.closeAddMedicineModal();
    }

    updateMedicine() {
        const form = document.getElementById('editMedicineForm');
        if (!form) {
            console.error("Edit medicine form not found!");
            return;
        }
        
        // Validate form
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        const updatedData = {
            name: document.getElementById('editMedicineName').value,
            batchNumber: document.getElementById('editBatchNumber').value,
            quantity: parseInt(document.getElementById('editQuantity').value),
            price: parseFloat(document.getElementById('editPrice').value),
            expiryDate: document.getElementById('editExpiryDate').value,
            supplier: document.getElementById('editSupplier').value,
            minStockLevel: parseInt(document.getElementById('editMinStockLevel').value)
        };

        this.updateMedicineData(this.currentEditId, updatedData);
        this.closeEditMedicineModal();
    }

    generateBatchNumber() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return `BCH${year}${month}${random}`;
    }

    addExportButton() {
        const headerActions = document.querySelector('.flex.items-center.justify-between');
        if (headerActions && !document.getElementById('exportBtn')) {
            const exportBtn = document.createElement('button');
            exportBtn.id = 'exportBtn';
            exportBtn.className = 'bg-primary hover:bg-primary/90 text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2 transition-colors shadow-md ml-4';
            exportBtn.innerHTML = '<span class="material-icons">download</span> Export CSV';
            exportBtn.onclick = () => this.exportToCSV();
            headerActions.appendChild(exportBtn);
            console.log("Export button added");
        }
    }

    renderInventoryTable(filteredData = null) {
        const inventoryTable = document.getElementById('inventoryTableBody');
        if (!inventoryTable) {
            console.error("Inventory table body not found!");
            return;
        }
        
        const dataToRender = filteredData || this.inventoryData;
        
        inventoryTable.innerHTML = dataToRender.map(item => `
            <tr class="border-b border-border-light dark:border-border-dark hover:bg-gray-50/50 dark:hover:bg-gray-800/50 transition-colors">
                <td class="px-6 py-4 font-medium whitespace-nowrap text-text-light dark:text-text-dark">${item.name}</td>
                <td class="px-6 py-4 text-subtext-light dark:text-subtext-dark">${item.batchNumber}</td>
                <td class="px-6 py-4 text-subtext-light dark:text-subtext-dark">${item.quantity}</td>
                <td class="px-6 py-4 text-subtext-light dark:text-subtext-dark">${this.formatDate(item.expiryDate)}</td>
                <td class="px-6 py-4 text-subtext-light dark:text-subtext-dark">${item.supplier}</td>
                <td class="px-6 py-4 text-subtext-light dark:text-subtext-dark">${this.formatCurrency(item.price)}</td>
                <td class="px-6 py-4">
                    <span class="px-3 py-1 text-xs font-medium rounded-full ${this.getStatusClass(item)}">${this.getStatusText(item)}</span>
                </td>
                <td class="px-6 py-4 text-center">
                    <div class="flex items-center justify-center gap-4">
                        <button class="text-subtext-light dark:text-subtext-dark hover:text-primary dark:hover:text-primary transition-colors" onclick="inventoryManager.openEditMedicineModal(${item.id})">
                            <span class="material-icons text-sm">edit</span>
                        </button>
                        <button class="text-subtext-light dark:text-subtext-dark hover:text-danger dark:hover:text-danger transition-colors" onclick="inventoryManager.deleteMedicine(${item.id})">
                            <span class="material-icons text-sm">delete_outline</span>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
        
        console.log("Inventory table rendered with", dataToRender.length, "items");
    }

    handleSearch(event) {
        const searchTerm = event.target.value.toLowerCase().trim();
        console.log("Searching for:", searchTerm);
        
        if (searchTerm === '') {
            this.renderInventoryTable();
            return;
        }
        
        const filteredData = this.inventoryData.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.batchNumber.toLowerCase().includes(searchTerm) ||
            (item.supplier && item.supplier.toLowerCase().includes(searchTerm))
        );
        
        this.renderInventoryTable(filteredData);
    }

    addMedicine(medicineData) {
        const newMedicine = {
            id: this.generateId(),
            ...medicineData,
            status: this.calculateStatus(medicineData.quantity, medicineData.minStockLevel)
        };
        
        this.inventoryData.push(newMedicine);
        this.renderInventoryTable();
        this.updateAlerts();
        this.showNotification("Medicine added successfully", "success");
    }

    updateMedicineData(medicineId, updatedData) {
        const index = this.inventoryData.findIndex(item => item.id === medicineId);
        if (index === -1) {
            console.error("Medicine not found for update:", medicineId);
            return;
        }
        
        this.inventoryData[index] = {
            ...this.inventoryData[index],
            ...updatedData,
            status: this.calculateStatus(updatedData.quantity, updatedData.minStockLevel)
        };
        
        this.renderInventoryTable();
        this.updateAlerts();
        this.showNotification("Medicine updated successfully", "success");
    }

    deleteMedicine(medicineId) {
        if (!confirm("Are you sure you want to delete this medicine?")) {
            return;
        }
        
        this.inventoryData = this.inventoryData.filter(item => item.id !== medicineId);
        this.renderInventoryTable();
        this.updateAlerts();
        this.showNotification("Medicine deleted successfully", "success");
    }

    updateAlerts() {
        this.updateLowStockAlerts();
        this.updateExpiryAlerts();
    }

    updateLowStockAlerts() {
        const lowStockItems = this.inventoryData.filter(item => 
            item.quantity <= item.minStockLevel && item.quantity > 0
        );
        
        const outOfStockItems = this.inventoryData.filter(item => item.quantity === 0);
        
        const alertList = document.getElementById('lowStockAlerts');
        if (alertList) {
            const alerts = [
                ...lowStockItems.map(item => 
                    `<li class="py-1">${item.name} - Batch: ${item.batchNumber} (${item.quantity} units)</li>`
                ),
                ...outOfStockItems.map(item => 
                    `<li class="py-1">${item.name} - Batch: ${item.batchNumber} (${item.quantity} units)</li>`
                )
            ];
            
            alertList.innerHTML = alerts.length > 0 ? alerts.join('') : 
                '<li class="py-1">No low stock alerts</li>';
        }
    }

    updateExpiryAlerts() {
        const thirtyDaysFromNow = new Date();
        thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
        
        const expiringItems = this.inventoryData.filter(item => {
            const expiryDate = new Date(item.expiryDate);
            return expiryDate <= thirtyDaysFromNow && expiryDate > new Date();
        });
        
        const alertList = document.getElementById('expiryAlerts');
        if (alertList) {
            const alerts = expiringItems.map(item => 
                `<li class="py-1">${item.name} - Batch: ${item.batchNumber} (Expires: ${this.formatDate(item.expiryDate)})</li>`
            );
            
            alertList.innerHTML = alerts.length > 0 ? alerts.join('') : 
                '<li class="py-1">No expiry alerts</li>';
        }
    }

    // Currency formatting
    formatCurrency(amount) {
        return `${this.CURRENCY.symbol}${amount.toFixed(this.CURRENCY.decimalPlaces)}`;
    }

    // Utility functions
    getStatusClass(medicine) {
        if (medicine.quantity === 0) {
            return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300";
        } else if (medicine.quantity <= medicine.minStockLevel) {
            return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300";
        } else {
            return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300";
        }
    }

    getStatusText(medicine) {
        if (medicine.quantity === 0) {
            return "Out of Stock";
        } else if (medicine.quantity <= medicine.minStockLevel) {
            return "Low Stock";
        } else {
            return "In Stock";
        }
    }

    calculateStatus(quantity, minStockLevel) {
        if (quantity === 0) return "Out of Stock";
        if (quantity <= minStockLevel) return "Low Stock";
        return "In Stock";
    }

    formatDate(dateString) {
        try {
            return new Date(dateString).toLocaleDateString('en-PH', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        } catch (error) {
            console.error("Date formatting error:", error);
            return dateString;
        }
    }

    generateId() {
        return this.inventoryData.length > 0 ? Math.max(...this.inventoryData.map(item => item.id)) + 1 : 1;
    }

    showNotification(message, type = "info") {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 transform transition-all duration-300 ${
            type === 'success' ? 'bg-green-500 text-white' :
            type === 'error' ? 'bg-red-500 text-white' :
            'bg-blue-500 text-white'
        }`;
        notification.innerHTML = `
            <div class="flex items-center gap-2">
                <span class="material-icons">${type === 'success' ? 'check_circle' : type === 'error' ? 'error' : 'info'}</span>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    openFilterModal() {
        this.showNotification("Filter functionality coming soon", "info");
    }

    // Export data functionality
    exportToCSV() {
        const headers = ['Name', 'Batch Number', 'Quantity', 'Expiry Date', 'Supplier', 'Price', 'Status'];
        const csvData = this.inventoryData.map(item => [
            `"${item.name}"`,
            `"${item.batchNumber}"`,
            item.quantity,
            item.expiryDate,
            `"${item.supplier}"`,
            this.formatCurrency(item.price),
            item.status
        ]);
        
        const csvContent = [headers, ...csvData].map(row => row.join(',')).join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `pharmacare-inventory-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        this.showNotification("Inventory exported to CSV", "success");
    }
}

// Initialize only once
if (typeof inventoryManager === 'undefined') {
    let inventoryManager;
    
    document.addEventListener('DOMContentLoaded', function() {
        console.log("DOM loaded, initializing Inventory Manager...");
        inventoryManager = new InventoryManager();
        window.inventoryManager = inventoryManager; // Make it globally available
    });
}