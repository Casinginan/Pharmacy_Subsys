// Pharmacy Prescriptions JavaScript

// Global variables
const medicines = [
    { name: "Paracetamol 500mg", stock: 150, batch: "A2024001", price: 12.5 },
    { name: "Amoxicillin 250mg", stock: 8, batch: "AMX2024002", price: 25.0 },
    { name: "Ibuprofen 400mg", stock: 75, batch: "IB2024003", price: 15.3 }
];

// Sample patient data - Expanded with more patients
const patients = [
    { id: "P001", name: "John Smith", age: 45, contact: "john.smith@email.com", lastVisit: "2024-01-15" },
    { id: "P002", name: "Sarah Johnson", age: 32, contact: "sarah.j@email.com", lastVisit: "2024-01-10" },
    { id: "P003", name: "Michael Brown", age: 58, contact: "m.brown@email.com", lastVisit: "2024-01-08" },
    { id: "P004", name: "Emily Davis", age: 29, contact: "emily.davis@email.com", lastVisit: "2024-01-12" },
    { id: "P005", name: "Robert Wilson", age: 67, contact: "r.wilson@email.com", lastVisit: "2024-01-05" },
    { id: "P006", name: "Maria Garcia", age: 41, contact: "maria.g@email.com", lastVisit: "2024-01-14" },
    { id: "P007", name: "David Lee", age: 53, contact: "d.lee@email.com", lastVisit: "2024-01-09" },
    { id: "P008", name: "Lisa Martinez", age: 38, contact: "l.martinez@email.com", lastVisit: "2024-01-11" }
];

let prescriptions = JSON.parse(sessionStorage.getItem("prescriptions") || "[]");
let selectedMeds = [];
let selectedPatient = null;

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    renderMedicines();
    renderRecent();
    setupEventListeners();
    updateSelectedMedicinesDisplay();
    
    // Show all patients initially when clicking on search
    const patientSearch = document.getElementById('patient-search');
    if (patientSearch) {
        patientSearch.addEventListener('focus', function() {
            if (!this.value) {
                showAllPatients();
            }
        });
    }
});

// Setup event listeners
function setupEventListeners() {
    // Add keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+P to focus on patient search
        if (e.ctrlKey && e.key === 'p') {
            e.preventDefault();
            document.getElementById('patient-search').focus();
        }
        
        // Ctrl+M to focus on medicine search
        if (e.ctrlKey && e.key === 'm') {
            e.preventDefault();
            document.getElementById('searchBox').focus();
        }
        
        // Escape to close patient results
        if (e.key === 'Escape') {
            const resultsContainer = document.getElementById('patient-results');
            if (resultsContainer) {
                resultsContainer.classList.add('hidden');
            }
        }
    });
    
    // Close patient results when clicking outside
    document.addEventListener('click', function(e) {
        const patientSearch = document.getElementById('patient-search');
        const patientResults = document.getElementById('patient-results');
        
        if (patientSearch && patientResults && 
            !patientSearch.contains(e.target) && 
            !patientResults.contains(e.target)) {
            patientResults.classList.add('hidden');
        }
    });
}

// Show all patients when search is focused
function showAllPatients() {
    const resultsContainer = document.getElementById('patient-results');
    if (!resultsContainer) return;
    
    resultsContainer.innerHTML = patients.map(patient => `
        <div class="p-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors patient-result"
             onclick="selectPatient('${patient.id}', '${patient.name}', ${patient.age}, '${patient.contact}')">
            <div class="flex justify-between items-center">
                <div class="flex-1">
                    <p class="font-medium text-text-light">${patient.name}</p>
                    <div class="flex items-center gap-4 text-sm text-subtext-light mt-1">
                        <span>ID: ${patient.id}</span>
                        <span>Age: ${patient.age}</span>
                        <span>Last Visit: ${patient.lastVisit}</span>
                    </div>
                </div>
                <span class="material-icons text-primary text-lg">arrow_forward_ios</span>
            </div>
        </div>
    `).join('');
    
    resultsContainer.classList.remove('hidden');
}

// Search patients function
function searchPatients(searchTerm) {
    const resultsContainer = document.getElementById('patient-results');
    if (!resultsContainer) return;
    
    if (!searchTerm || searchTerm.trim() === '') {
        showAllPatients();
        return;
    }
    
    const searchLower = searchTerm.toLowerCase().trim();
    const filteredPatients = patients.filter(patient => 
        patient.name.toLowerCase().includes(searchLower) ||
        patient.id.toLowerCase().includes(searchLower) ||
        patient.contact.toLowerCase().includes(searchLower)
    );
    
    if (filteredPatients.length === 0) {
        resultsContainer.innerHTML = `
            <div class="p-4 text-center text-subtext-light">
                <span class="material-icons text-3xl mb-2 text-gray-400">person_off</span>
                <p class="font-medium">No patients found</p>
                <p class="text-sm mt-1">Try searching with different keywords</p>
            </div>
        `;
    } else {
        resultsContainer.innerHTML = filteredPatients.map(patient => `
            <div class="p-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer transition-colors patient-result"
                 onclick="selectPatient('${patient.id}', '${patient.name}', ${patient.age}, '${patient.contact}')">
                <div class="flex justify-between items-center">
                    <div class="flex-1">
                        <p class="font-medium text-text-light">${patient.name}</p>
                        <div class="flex items-center gap-4 text-sm text-subtext-light mt-1">
                            <span>ID: ${patient.id}</span>
                            <span>Age: ${patient.age}</span>
                            <span>Last Visit: ${patient.lastVisit}</span>
                        </div>
                    </div>
                    <span class="material-icons text-primary text-lg">arrow_forward_ios</span>
                </div>
            </div>
        `).join('');
    }
    
    resultsContainer.classList.remove('hidden');
}

// Select patient function
function selectPatient(id, name, age, contact) {
    selectedPatient = { id, name, age, contact };
    
    const selectedPatientContainer = document.getElementById('selected-patient');
    const resultsContainer = document.getElementById('patient-results');
    const patientSearch = document.getElementById('patient-search');
    
    if (selectedPatientContainer) {
        selectedPatientContainer.innerHTML = `
            <div class="flex justify-between items-start">
                <div class="flex-1">
                    <div class="flex items-center gap-2 mb-1">
                        <span class="material-icons text-primary text-lg">person</span>
                        <p class="font-semibold text-text-light text-lg">${name}</p>
                    </div>
                    <div class="grid grid-cols-2 gap-2 text-sm text-subtext-light">
                        <div class="flex items-center gap-1">
                            <span class="material-icons text-xs">badge</span>
                            <span>ID: ${id}</span>
                        </div>
                        <div class="flex items-center gap-1">
                            <span class="material-icons text-xs">cake</span>
                            <span>Age: ${age}</span>
                        </div>
                        <div class="flex items-center gap-1 col-span-2">
                            <span class="material-icons text-xs">email</span>
                            <span class="truncate">${contact}</span>
                        </div>
                    </div>
                </div>
                <button onclick="clearPatientSelection()" 
                        class="text-red-500 hover:text-red-700 transition-colors p-1 rounded-full hover:bg-red-50"
                        title="Remove patient">
                    <span class="material-icons text-lg">close</span>
                </button>
            </div>
        `;
        selectedPatientContainer.classList.remove('hidden');
    }
    
    if (resultsContainer) {
        resultsContainer.classList.add('hidden');
    }
    
    if (patientSearch) {
        patientSearch.value = '';
    }
    
    showNotification(`Patient ${name} selected successfully`, 'success');
}

// Clear patient selection
function clearPatientSelection() {
    selectedPatient = null;
    const selectedPatientContainer = document.getElementById('selected-patient');
    if (selectedPatientContainer) {
        selectedPatientContainer.classList.add('hidden');
    }
    showNotification('Patient selection cleared', 'info');
}

// Render medicine list with add buttons
function renderMedicines() {
    const container = document.getElementById("medicineList");
    if (!container) return;
    
    container.innerHTML = "";
    medicines.forEach((m, i) => {
        const stockStatus = m.stock <= 10 ? 'text-red-500' : 'text-green-500';
        const stockText = m.stock <= 10 ? 'Low Stock' : 'In Stock';
        const stockIcon = m.stock <= 10 ? 'warning' : 'check_circle';
        
        container.innerHTML += `
            <div class="medicine-item flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-primary/30 transition-colors">
                <div class="flex-1">
                    <p class="font-medium text-text-light">${m.name}</p>
                    <div class="flex items-center gap-4 text-sm text-subtext-light mt-1">
                        <div class="flex items-center gap-1">
                            <span class="material-icons text-base">inventory_2</span>
                            <span>Stock: ${m.stock}</span>
                        </div>
                        <div class="flex items-center gap-1">
                            <span class="material-icons text-base">qr_code</span>
                            <span>Batch: ${m.batch}</span>
                        </div>
                        <div class="flex items-center gap-1 ${stockStatus}">
                            <span class="material-icons text-base">${stockIcon}</span>
                            <span>${stockText}</span>
                        </div>
                        <div class="flex items-center gap-1">
                            <span class="material-icons text-base">payments</span>
                            <span class="font-semibold">₱${m.price.toFixed(2)}</span>
                        </div>
                    </div>
                </div>
                <button onclick="addMedicine(${i})" 
                        class="w-10 h-10 flex items-center justify-center bg-primary/10 hover:bg-primary/20 rounded-full text-primary transition-colors hover:scale-105"
                        title="Add ${m.name} to prescription">
                    <span class="material-icons text-xl">add</span>
                </button>
            </div>
        `;
    });
}

// Add medicine to prescription
function addMedicine(index) {
    const medicine = medicines[index];
    
    // Check stock availability
    if (medicine.stock <= 0) {
        showNotification(`${medicine.name} is out of stock!`, 'error');
        return;
    }
    
    // Check if medicine is already added
    const existingMed = selectedMeds.find(m => m.name === medicine.name);
    if (existingMed) {
        // If already added, just increase quantity by 1
        if (existingMed.quantity < medicine.stock) {
            existingMed.quantity += 1;
            showNotification(`${medicine.name} quantity increased to ${existingMed.quantity}`, 'success');
        } else {
            showNotification(`Cannot add more ${medicine.name}. Maximum stock available: ${medicine.stock}`, 'warning');
        }
    } else {
        // Add new medicine with quantity 1
        selectedMeds.push({
            ...medicine,
            quantity: 1
        });
        showNotification(`${medicine.name} added to prescription`, 'success');
    }
    
    // Update UI to show selected medicines
    updateSelectedMedicinesDisplay();
}

// Update selected medicines display with quantity controls
function updateSelectedMedicinesDisplay() {
    const container = document.getElementById("selectedMedicinesList");
    const noMedicinesMessage = document.getElementById("no-medicines-message");
    
    if (!container || !noMedicinesMessage) return;
    
    if (selectedMeds.length === 0) {
        container.innerHTML = '';
        noMedicinesMessage.classList.remove('hidden');
        return;
    }
    
    noMedicinesMessage.classList.add('hidden');
    
    container.innerHTML = selectedMeds.map((med, index) => {
        const totalPrice = (med.price * med.quantity).toFixed(2);
        const maxStock = medicines.find(m => m.name === med.name)?.stock || 0;
        
        return `
            <div class="selected-medicine-item p-4 bg-background-light border border-primary/20 rounded-lg">
                <div class="flex justify-between items-start mb-3">
                    <div class="flex-1">
                        <p class="font-semibold text-text-light">${med.name}</p>
                        <div class="flex items-center gap-4 text-sm text-subtext-light mt-1">
                            <span>Unit Price: ₱${med.price.toFixed(2)}</span>
                            <span>Total: ₱${totalPrice}</span>
                            <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Available: ${maxStock}</span>
                        </div>
                    </div>
                    <button onclick="removeMedicine(${index})" 
                            class="text-red-500 hover:text-red-700 transition-colors p-1 rounded-full hover:bg-red-50"
                            title="Remove ${med.name}">
                        <span class="material-icons text-lg">delete</span>
                    </button>
                </div>
                
                <div class="flex items-center justify-between">
                    <label class="text-sm font-medium text-text-light">Quantity:</label>
                    <div class="flex items-center gap-3">
                        <!-- Minus Button -->
                        <button onclick="decreaseQuantity(${index})" 
                                class="w-8 h-8 flex items-center justify-center bg-red-100 hover:bg-red-200 text-red-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                ${med.quantity <= 1 ? 'disabled' : ''}
                                title="Decrease quantity">
                            <span class="material-icons text-sm">remove</span>
                        </button>
                        
                        <!-- Quantity Input -->
                        <input type="number" 
                               value="${med.quantity}" 
                               min="1" 
                               max="${maxStock}"
                               onchange="updateQuantityDirectly(${index}, this.value)"
                               onblur="validateQuantity(${index}, this)"
                               class="w-16 text-center border border-gray-300 rounded-lg py-1 px-2 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                               title="Type quantity directly">
                        
                        <!-- Plus Button -->
                        <button onclick="increaseQuantity(${index})" 
                                class="w-8 h-8 flex items-center justify-center bg-green-100 hover:bg-green-200 text-green-600 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                ${med.quantity >= maxStock ? 'disabled' : ''}
                                title="Increase quantity">
                            <span class="material-icons text-sm">add</span>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// Increase quantity for a medicine
function increaseQuantity(index) {
    const med = selectedMeds[index];
    const maxStock = medicines.find(m => m.name === med.name)?.stock || 0;
    
    if (med.quantity < maxStock) {
        med.quantity += 1;
        updateSelectedMedicinesDisplay();
        showNotification(`${med.name} quantity increased to ${med.quantity}`, 'success');
    } else {
        showNotification(`Cannot increase quantity. Maximum stock available: ${maxStock}`, 'warning');
    }
}

// Decrease quantity for a medicine
function decreaseQuantity(index) {
    const med = selectedMeds[index];
    
    if (med.quantity > 1) {
        med.quantity -= 1;
        updateSelectedMedicinesDisplay();
        showNotification(`${med.name} quantity decreased to ${med.quantity}`, 'info');
    } else {
        showNotification(`Minimum quantity is 1`, 'warning');
    }
}

// Update quantity directly via input
function updateQuantityDirectly(index, newQuantity) {
    const med = selectedMeds[index];
    const maxStock = medicines.find(m => m.name === med.name)?.stock || 0;
    const quantity = parseInt(newQuantity);
    
    if (isNaN(quantity) || quantity < 1) {
        med.quantity = 1;
        showNotification(`Quantity must be at least 1`, 'warning');
    } else if (quantity > maxStock) {
        med.quantity = maxStock;
        showNotification(`Quantity limited to available stock: ${maxStock}`, 'warning');
    } else {
        med.quantity = quantity;
        showNotification(`${med.name} quantity set to ${quantity}`, 'success');
    }
    
    updateSelectedMedicinesDisplay();
}

// Validate quantity on input blur
function validateQuantity(index, inputElement) {
    const med = selectedMeds[index];
    const maxStock = medicines.find(m => m.name === med.name)?.stock || 0;
    const quantity = parseInt(inputElement.value);
    
    if (isNaN(quantity) || quantity < 1) {
        inputElement.value = 1;
        med.quantity = 1;
    } else if (quantity > maxStock) {
        inputElement.value = maxStock;
        med.quantity = maxStock;
    }
}

// Remove medicine from prescription
function removeMedicine(index) {
    const med = selectedMeds[index];
    selectedMeds.splice(index, 1);
    updateSelectedMedicinesDisplay();
    showNotification(`${med.name} removed from prescription`, 'info');
}

// Process prescription
function processPrescription() {
    // Validation
    if (!selectedPatient) {
        showNotification("Please select a patient first", 'error');
        return;
    }
    
    if (selectedMeds.length === 0) {
        showNotification("Please add at least one medicine to the prescription", 'error');
        return;
    }
    
    // Check stock for all selected medicines
    const outOfStockMeds = selectedMeds.filter(med => {
        const medicine = medicines.find(m => m.name === med.name);
        return medicine && med.quantity > medicine.stock;
    });
    
    if (outOfStockMeds.length > 0) {
        const medNames = outOfStockMeds.map(m => `${m.name} (requested: ${m.quantity}, available: ${medicines.find(med => med.name === m.name)?.stock})`).join(', ');
        showNotification(`Insufficient stock for: ${medNames}`, 'error');
        return;
    }
    
    const total = selectedMeds.reduce((sum, m) => sum + (m.price * m.quantity), 0).toFixed(2);

    // Create prescription record
    const record = {
        id: generatePrescriptionId(),
        patientId: selectedPatient.id,
        patientName: selectedPatient.name,
        medicines: selectedMeds.map(m => `${m.name} x${m.quantity}`),
        quantities: selectedMeds.map(m => m.quantity),
        total: total,
        doctor: "Dr. Emily Chen",
        date: new Date().toLocaleString(),
        status: 'completed'
    };

    // Add to prescriptions array and save to session storage
    prescriptions.unshift(record);
    sessionStorage.setItem("prescriptions", JSON.stringify(prescriptions));
    
    // Update stock levels (in a real app, this would be a backend call)
    updateStockLevels(selectedMeds);
    
    // Reset form and update UI
    selectedMeds = [];
    clearPatientSelection();
    updateSelectedMedicinesDisplay();
    renderRecent();
    
    showNotification(`Prescription processed successfully for ${record.patientName}! Total: ₱${total}`, 'success');
}

// Update stock levels after prescription is processed
function updateStockLevels(dispensedMeds) {
    dispensedMeds.forEach(dispensed => {
        const medicine = medicines.find(m => m.name === dispensed.name);
        if (medicine) {
            medicine.stock = Math.max(0, medicine.stock - dispensed.quantity);
        }
    });
    renderMedicines(); // Refresh medicine list to show updated stock
}

// Generate unique prescription ID
function generatePrescriptionId() {
    return 'RX' + Date.now().toString().slice(-6);
}

// Render recent prescriptions
function renderRecent() {
    const container = document.getElementById("recentPrescriptions");
    if (!container) return;
    
    container.innerHTML = "";
    
    if (prescriptions.length === 0) {
        container.innerHTML = `
            <div class="text-center py-8 text-subtext-light">
                <span class="material-icons text-4xl mb-2">receipt_long</span>
                <p>No recent prescriptions</p>
                <p class="text-sm mt-1">Processed prescriptions will appear here</p>
            </div>
        `;
        return;
    }
    
    prescriptions.slice(0, 5).forEach(p => { // Show only last 5 prescriptions
        container.innerHTML += `
            <div class="prescription-card p-4 bg-background-light rounded-lg border border-gray-200 hover:border-primary/30 transition-colors">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <p class="font-semibold text-text-light">${p.patientName}</p>
                        <p class="text-sm text-subtext-light">ID: ${p.patientId} | RX: ${p.id}</p>
                    </div>
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 border border-green-200">
                        <span class="material-icons text-sm mr-1">check_circle</span> Completed
                    </span>
                </div>
                <div class="mb-3">
                    <p class="text-sm font-medium text-text-light">Medicines:</p>
                    <ul class="list-disc list-inside text-sm mt-1 text-subtext-light">
                        ${p.medicines.map(m => `<li>${m}</li>`).join("")}
                    </ul>
                </div>
                <div class="flex items-center justify-between text-sm text-subtext-light border-t border-gray-200 pt-3 mt-3">
                    <div class="flex items-center">
                        <span class="material-icons text-base mr-1">calendar_today</span>
                        <span>${p.date}</span>
                    </div>
                    <p class="font-semibold text-text-light">Total: ₱${p.total}</p>
                </div>
                <p class="text-xs text-subtext-light mt-2 text-right">By: ${p.doctor}</p>
            </div>
        `;
    });
}

// Search prescriptions
function searchPrescriptions(searchTerm) {
    if (!searchTerm) {
        renderRecent();
        return;
    }
    
    const filtered = prescriptions.filter(p => 
        p.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.medicines.some(m => m.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    
    const container = document.getElementById("recentPrescriptions");
    if (!container) return;
    
    container.innerHTML = "";
    
    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="text-center py-8 text-subtext-light">
                <span class="material-icons text-4xl mb-2">search_off</span>
                <p>No prescriptions found</p>
                <p class="text-sm mt-1">Try different search terms</p>
            </div>
        `;
        return;
    }
    
    filtered.forEach(p => {
        container.innerHTML += `
            <div class="p-4 bg-background-light rounded-lg border border-gray-200">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <p class="font-semibold text-text-light">${p.patientName}</p>
                        <p class="text-sm text-subtext-light">ID: ${p.patientId}</p>
                    </div>
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <span class="material-icons text-sm mr-1">check_circle</span> Completed
                    </span>
                </div>
                <div class="mb-3">
                    <p class="text-sm font-medium text-text-light">Medicines:</p>
                    <ul class="list-disc list-inside text-sm mt-1 text-subtext-light">
                        ${p.medicines.map(m => `<li>${m}</li>`).join("")}
                    </ul>
                </div>
                <div class="flex items-center justify-between text-sm text-subtext-light border-t border-gray-200 pt-3 mt-3">
                    <div class="flex items-center">
                        <span class="material-icons text-base mr-1">calendar_today</span>
                        <span>${p.date}</span>
                    </div>
                    <p class="font-semibold text-text-light">Total: ₱${p.total}</p>
                </div>
                <p class="text-xs text-subtext-light mt-2 text-right">By: ${p.doctor}</p>
            </div>
        `;
    });
}

// Show notification
function showNotification(message, type = 'info') {
    // For now, using alert for simplicity
    // In a real application, you would use a proper toast notification system
    const typeIcons = {
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️'
    };
    
    const icon = typeIcons[type] || 'ℹ️';
    alert(`${icon} ${message}`);
}

window.PrescriptionManager = {
    renderMedicines,
    addMedicine,
    processPrescription,
    searchPrescriptions,
    renderRecent,
    searchPatients,
    selectPatient,
    clearPatientSelection,
    showAllPatients,
    increaseQuantity,
    decreaseQuantity,
    updateQuantityDirectly,
    removeMedicine
};