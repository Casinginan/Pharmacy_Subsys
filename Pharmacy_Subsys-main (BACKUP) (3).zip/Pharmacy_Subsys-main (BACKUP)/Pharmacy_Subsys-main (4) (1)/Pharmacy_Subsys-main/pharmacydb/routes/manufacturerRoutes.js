import express from 'express';
import Manufacturer from '../models/Manufacturer.js';

const router = express.Router();

// @route   POST /api/manufacturers
// @desc    Add a new manufacturer
router.post('/', async (req, res) => {
  try {
    const { name, contactInfo } = req.body;

    const newManufacturer = new Manufacturer({ name, contactInfo });
    const manufacturer = await newManufacturer.save();

    res.status(201).json(manufacturer);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

export default router;