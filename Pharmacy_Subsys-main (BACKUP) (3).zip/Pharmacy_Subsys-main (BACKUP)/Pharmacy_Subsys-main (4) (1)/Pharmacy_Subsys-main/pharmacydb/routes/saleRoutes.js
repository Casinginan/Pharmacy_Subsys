import express from 'express';
import { protect, admin } from '../middleware/authMiddleware.js';
import User from '../models/User.js';
import Prescription from '../models/Prescription.js';
import Inventory from '../models/Inventory.js';
import Sale from '../models/Sale.js';
import Medicine from '../models/Medicine.js';

const router = express.Router();

// @route   POST /api/sales/dispense/:patientId
// @desc    Dispense all pending prescriptions for a patient (NO SUDO)
// @access  Private/Admin
router.post('/dispense/:patientId', protect, admin, async (req, res) => {
  try {
    const { patientId } = req.params;

    // --- PASSWORD CHECK REMOVED ---

    // 2. Find all pending prescriptions for this patient
    const prescriptionsToFill = await Prescription.find({ 
      patient: patientId, 
      isFilled: false 
    }).populate('medicines.medicine', 'name');

    if (prescriptionsToFill.length === 0) {
      return res.status(404).json({ message: 'No pending prescriptions found for this patient.' });
    }

    let totalAmount = 0;
    let masterSaleItems = [];
    let inventoryUpdates = [];

    // 3. First Loop: Check stock for ALL items
    for (const rx of prescriptionsToFill) {
      for (const med of rx.medicines) {
        const inventoryBatch = await Inventory.findOne({
          medicine: med.medicine._id,
          quantity: { $gte: med.quantity },
          isArchived: false,
        });

        if (!inventoryBatch) {
          return res.status(400).json({ message: `Out of stock for: ${med.medicine.name}. Cannot dispense.` });
        }
      }
    }

    // 4. Second Loop: Process the transaction
    for (const rx of prescriptionsToFill) {
      for (const med of rx.medicines) {
        const inventoryBatch = await Inventory.findOne({
          medicine: med.medicine._id,
          quantity: { $gte: med.quantity },
          isArchived: false,
        });

        inventoryBatch.quantity -= med.quantity;
        inventoryUpdates.push(inventoryBatch.save());

        totalAmount += inventoryBatch.sellingPrice * med.quantity;
        masterSaleItems.push({
          medicine: med.medicine._id,
          inventory: inventoryBatch._id,
          quantity: med.quantity,
          priceAtSale: inventoryBatch.sellingPrice
        });
      }
      
      rx.isFilled = true;
      inventoryUpdates.push(rx.save());
    }

    // 5. Save all database changes
    await Promise.all(inventoryUpdates);

    // 6. Create the final Sale record
    const newSale = await Sale.create({
      patient: patientId,
      pharmacist: req.user._id,
      totalAmount,
      items: masterSaleItems,
      prescriptions: prescriptionsToFill.map(rx => rx._id)
    });

    res.status(201).json({ message: 'Dispensing complete!', sale: newSale });

  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

export default router;