import express from 'express';
import User from '../models/User.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

// @route   POST /api/users
// @desc    Register a new user (by a re-authenticated Admin)
// @access  Private/Admin
router.post('/', protect, admin, async (req, res) => {
  try {
    const { adminPassword, newUserData } = req.body;
    const { name, email, password, role, status } = newUserData; // Added status

    if (!adminPassword || !newUserData) {
      return res.status(400).json({ message: 'Missing admin password or new user data' });
    }

    const adminUser = await User.findById(req.user._id);

    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists with that email' });
    }

    const user = await User.create({ name, email, password, role, status }); // Added status
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   POST /api/users/login
// @desc    Authenticate user & get token
// @access  Public
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    
    // Check if user is inactive
    if (user.status === 'inactive') {
      return res.status(403).json({ message: 'Account is deactivated. Please contact an admin.' });
    }

    if (await user.matchPassword(password)) {
      // --- UPDATE LAST LOGIN ---
      user.lastLogin = Date.now();
      await user.save();
      // -------------------------

      res.json({
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        status: user.status,
        lastLogin: user.lastLogin,
        token: jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
          expiresIn: '1d',
        }),
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   GET /api/users
// @desc    Get all users (Admin only)
// @access  Private/Admin
router.get('/', protect, admin, async (req, res) => {
  try {
    const users = await User.find({}).select('-password');
    res.json(users);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// --- NEW ---
// @route   PUT /api/users/:id
// @desc    Update a user (by Admin with "sudo")
// @access  Private/Admin
router.put('/:id', protect, admin, async (req, res) => {
  try {
    const { adminPassword, updatedUserData } = req.body;
    const { name, email, role, password } = updatedUserData;
    
    if (!adminPassword || !updatedUserData) {
      return res.status(400).json({ message: 'Missing admin password or update data' });
    }

    const adminUser = await User.findById(req.user._id);
    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.name = name || user.name;
    user.email = email || user.email;
    user.role = role || user.role;
    
    // Only update password if a new one is provided
    if (password) {
      user.password = password;
    }
    
    const updatedUser = await user.save();
    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      role: updatedUser.role,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// --- NEW ---
// @route   DELETE /api/users/:id
// @desc    Delete a user (by Admin with "sudo")
// @access  Private/Admin
router.delete('/:id', protect, admin, async (req, res) => {
  try {
    const { adminPassword } = req.body;
    
    if (!adminPassword) {
      return res.status(400).json({ message: 'Admin password is required' });
    }
    
    const adminUser = await User.findById(req.user._id);
    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }
    
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Prevent an admin from deleting themselves
    if (user._id.equals(req.user._id)) {
      return res.status(400).json({ message: 'You cannot delete your own admin account.' });
    }

    await User.deleteOne({ _id: req.params.id });
    res.json({ message: 'User removed successfully' });
  
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// --- NEW ---
// @route   PATCH /api/users/:id/status
// @desc    Toggle user status (by Admin with "sudo")
// @access  Private/Admin
router.patch('/:id/status', protect, admin, async (req, res) => {
  try {
    const { adminPassword } = req.body;
    
    if (!adminPassword) {
      return res.status(400).json({ message: 'Admin password is required' });
    }

    const adminUser = await User.findById(req.user._id);
    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }
    
    const user = await User.findById(req.params.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Prevent an admin from deactivating themselves
    if (user._id.equals(req.user._id)) {
      return res.status(400).json({ message: 'You cannot deactivate your own account.' });
    }

    user.status = user.status === 'active' ? 'inactive' : 'active';
    await user.save();
    
    res.json(user);
  
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

export default router;