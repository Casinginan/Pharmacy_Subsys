import express from 'express';
import { protect, admin } from '../middleware/authMiddleware.js';
import Inventory from '../models/Inventory.js';
import Medicine from '../models/Medicine.js';
import Manufacturer from '../models/Manufacturer.js';
import User from '../models/User.js';

const router = express.Router();

// @route   GET /api/inventory
// @desc    Get all ACTIVE inventory items, with filters
// @access  Private/Admin
router.get('/', protect, admin, async (req, res) => {
  try {
    let query = { isArchived: false };
    
    // --- THIS IS THE FIX ---
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Set to midnight this morning
    // -----------------------

    // --- Status Filter Logic ---
    if (req.query.status) {
      switch (req.query.status) {
        case 'inStock':
          query.$expr = { $gt: ["$quantity", "$minStockLevel"] };
          query.expiryDate = { $gte: today }; // Also ensure it's not expired
          break;
        case 'lowStock':
          query.$expr = { $lte: ["$quantity", "$minStockLevel"] };
          query.quantity = { $gt: 0 };
          query.expiryDate = { $gte: today }; // Also ensure it's not expired
          break;
        case 'outOfStock':
          query.quantity = 0;
          query.expiryDate = { $gte: today }; // Also ensure it's not expired
          break;
        case 'expired':
          query.expiryDate = { $lt: today };
          break;
        // 'all' case does nothing
      }
    }

    // --- Name Search Logic ---
    if (req.query.name) {
      // Find the Medicine IDs that match the name search
      const medicines = await Medicine.find({
        name: { $regex: req.query.name, $options: 'i' },
      });
      const medicineIds = medicines.map(m => m._id);
      
      // Add this to our main query
      query.medicine = { $in: medicineIds };
    }

    // Find all items matching the combined query
    const inventoryItems = await Inventory.find(query).populate({
      path: 'medicine',
      populate: {
        path: 'manufacturer',
        model: 'Manufacturer',
      },
    });
    
    res.json(inventoryItems);

  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   GET /api/inventory/archived
// @desc    Get all ARCHIVED inventory items
// @access  Private/Admin
router.get('/archived', protect, admin, async (req, res) => {
  try {
    // We populate 'medicine' and then also populate 'manufacturer' inside 'medicine'
    const archivedItems = await Inventory.find({ isArchived: true }) // Finds only archived items
      .populate({
        path: 'medicine',
        populate: {
          path: 'manufacturer',
          model: 'Manufacturer',
        },
      });
    res.json(archivedItems);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   POST /api/inventory
// @desc    Add a new inventory batch (and create medicine/manufacturer if new)
// @access  Private/Admin
router.post('/', protect, admin, async (req, res) => {
  try {
    const {
      medicineName,
      batchNumber,
      quantity,
      price, // This is 'sellingPrice' from the form
      expiryDate,
      supplier, // This is the manufacturer's name (string)
      minStockLevel,
    } = req.body;

    // --- Step 1: Find or Create the Manufacturer ---
    let manufacturer = await Manufacturer.findOneAndUpdate(
      { name: { $regex: new RegExp(`^${supplier}$`, 'i') } },
      { $setOnInsert: { name: supplier } },
      { upsert: true, new: true }
    );

    // --- Step 2: Find or Create the Medicine ---
    let medicine = await Medicine.findOneAndUpdate(
      { name: { $regex: new RegExp(`^${medicineName}$`, 'i') } },
      {
        $setOnInsert: {
          name: medicineName,
          manufacturer: manufacturer._id,
          type: 'Generic', // Set a default
          strength: 'N/A', // Set a default
        },
      },
      { upsert: true, new: true }
    );

    // --- Step 3: Create the Inventory Item ---
    const newInventoryItem = new Inventory({
      medicine: medicine._id,
      batchNumber,
      expiryDate: expiryDate || null, // Handle blank date
      quantity,
      costPrice: price, // Using 'price' from form
      sellingPrice: price, // Using 'price' from form
      minStockLevel,
      isArchived: false, // Default to active
    });

    await newInventoryItem.save();

    // Populate the response so the front-end can display it right away
    const populatedItem = await Inventory.findById(newInventoryItem._id).populate({
      path: 'medicine',
      populate: { path: 'manufacturer' },
    });
    
    res.status(201).json(populatedItem);

  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   PUT /api/inventory/:id
// @desc    Update an inventory item
// @access  Private/Admin
router.put('/:id', protect, admin, async (req, res) => {
  try {
    // --- SUDO CHECK REMOVED ---
    const {
      medicineName, batchNumber, quantity, price,
      expiryDate, supplier, minStockLevel
    } = req.body;

    const inventoryItem = await Inventory.findById(req.params.id);
    if (!inventoryItem) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }

    const medicine = await Medicine.findById(inventoryItem.medicine);
    const manufacturer = await Manufacturer.findOneAndUpdate(
      { name: { $regex: new RegExp(`^${supplier}$`, 'i') } },
      { $setOnInsert: { name: supplier } },
      { upsert: true, new: true }
    );
    
    if (medicine) {
        medicine.name = medicineName || medicine.name;
        medicine.manufacturer = manufacturer._id;
        await medicine.save();
    }

    inventoryItem.batchNumber = batchNumber || inventoryItem.batchNumber;
    inventoryItem.quantity = quantity;
    inventoryItem.sellingPrice = price || inventoryItem.sellingPrice;
    inventoryItem.costPrice = price || inventoryItem.costPrice;
    inventoryItem.expiryDate = expiryDate || inventoryItem.expiryDate;
    inventoryItem.minStockLevel = minStockLevel || inventoryItem.minStockLevel;

    await inventoryItem.save();
    const populatedItem = await Inventory.findById(inventoryItem._id).populate({
      path: 'medicine',
      populate: { path: 'manufacturer' },
    });
    res.json(populatedItem);

  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   PATCH /api/inventory/:id/archive
// @desc    Archive an inventory item (soft delete)
// @access  Private/Admin
router.patch('/:id/archive', protect, admin, async (req, res) => {
  try {
    // --- SUDO CHECK REMOVED ---
    const inventoryItem = await Inventory.findById(req.params.id);
    if (!inventoryItem) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    inventoryItem.isArchived = true;
    await inventoryItem.save();
    res.json({ message: 'Item archived successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   PATCH /api/inventory/:id/restore
// @desc    Restore an inventory item
// @access  Private/Admin
router.patch('/:id/restore', protect, admin, async (req, res) => {
  try {
    // --- SUDO CHECK REMOVED ---
    const inventoryItem = await Inventory.findById(req.params.id);
    if (!inventoryItem) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    inventoryItem.isArchived = false;
    await inventoryItem.save();
    res.json({ message: 'Item restored successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   DELETE /api/inventory/:id
// @desc    Permanently delete an inventory item
// @access  Private/Admin
router.delete('/:id', protect, admin, async (req, res) => {
  try {
    // --- ADDED SUDO CHECK ---
    const { adminPassword } = req.body;
    if (!adminPassword) {
      return res.status(400).json({ message: 'Admin password is required' });
    }
    const adminUser = await User.findById(req.user._id);
    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }
    // --- END SUDO CHECK ---

    const inventoryItem = await Inventory.findById(req.params.id);
    if (!inventoryItem) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    
    if (!inventoryItem.isArchived) {
       return res.status(400).json({ message: 'Item must be archived before deletion.' });
    }

    await Inventory.deleteOne({ _id: req.params.id });
    res.json({ message: 'Inventory item permanently removed' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// --- NEW ---
// @route   DELETE /api/inventory/archive/all
// @desc    Permanently delete ALL archived items (Sudo required)
// @access  Private/Admin
router.delete('/archive/all', protect, admin, async (req, res) => {
  try {
    const { adminPassword } = req.body;

    if (!adminPassword) {
      return res.status(400).json({ message: 'Admin password is required' });
    }

    // Find the logged-in admin (ID comes from the 'protect' middleware)
    const adminUser = await User.findById(req.user._id);

    // Check if the provided admin password is correct
    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }

    // --- If password is correct, proceed with deletion ---
    const deleteResult = await Inventory.deleteMany({ isArchived: true });

    res.json({ 
      message: 'Archive cleared successfully',
      deletedCount: deleteResult.deletedCount 
    });
  
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});
export default router;