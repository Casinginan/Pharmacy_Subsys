import mongoose from 'mongoose';

const manufacturerSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true, // No two manufacturers should have the same name
    },
    contactInfo: {
      type: String,
    },
  },
  { timestamps: true }
);

const Manufacturer = mongoose.model('Manufacturer', manufacturerSchema);

export default Manufacturer;