tailwind.config = {
    darkMode: "class",
    theme: {
        extend: {
            colors: {
                primary: "#358E83",
                "background-light": "#F9FAFB",
                "background-dark": "#111827",
                "surface-light": "#FFFFFF",
                "surface-dark": "#1F2937",
                "text-light": "#1F2937",
                "text-dark": "#F9FAFB",
                "subtext-light": "#6B7280",
                "subtext-dark": "#9CA3AF",
                "border-light": "#E5E7EB",
                "border-dark": "#374151",
                "success": "#22C55E",
                "warning": "#F59E0B",
                "danger": "#EF4444"
            },
            fontFamily: {
                display: ["Inter", "sans-serif"],
            },
            borderRadius: {
                DEFAULT: "0.5rem",
            },
        },
    },
};

class SearchManager {
    constructor() {
        this.searchableItems = [
            { id: 'emr-enable', title: 'EMR Integration', category: 'Integration', type: 'toggle' },
            { id: 'emr-url', title: 'EMR API URL', category: 'Integration', type: 'input' },
            { id: 'emr-api-key', title: 'EMR API Key', category: 'Integration', type: 'password' },
            { id: 'emr-sync', title: 'EMR Sync Interval', category: 'Integration', type: 'input' },
            { id: 'billing-enable', title: 'Billing Integration', category: 'Integration', type: 'toggle' },
            { id: 'billing-url', title: 'Billing API URL', category: 'Integration', type: 'input' },
            { id: 'billing-api-key', title: 'Billing API Key', category: 'Integration', type: 'password' },
            { id: 'billing-sync', title: 'Billing Sync Interval', category: 'Integration', type: 'input' },
            { id: 'saveBtn', title: 'Save Settings', category: 'Actions', type: 'button' },
            { id: 'resetBtn', title: 'Reset Settings', category: 'Actions', type: 'button' },
            { id: 'test-emr', title: 'Test EMR Connection', category: 'Actions', type: 'button' },
            { id: 'test-billing', title: 'Test Billing Connection', category: 'Actions', type: 'button' }
        ];
        this.initializeSearchListeners();
    }

    initializeSearchListeners() {
        const searchInput = document.getElementById('searchInput');
        const searchDropdown = document.getElementById('searchDropdown');
        const clearSearch = document.getElementById('clearSearch');

        searchInput.addEventListener('input', (e) => {
            this.handleSearch(e.target.value);
        });

        searchInput.addEventListener('focus', () => {
            if (searchInput.value.length > 0) {
                searchDropdown.classList.add('show');
            }
        });

        document.addEventListener('click', (e) => {
            if (!searchInput.contains(e.target) && !searchDropdown.contains(e.target)) {
                searchDropdown.classList.remove('show');
            }
        });

        clearSearch.addEventListener('click', () => {
            searchInput.value = '';
            searchDropdown.classList.remove('show');
            searchInput.focus();
        });

        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                searchDropdown.classList.remove('show');
                searchInput.blur();
            }
            if (e.key === 'Enter' && searchInput.value.trim()) {
                this.performSearch(searchInput.value.trim());
            }
        });
    }

    handleSearch(query) {
        const searchDropdown = document.getElementById('searchDropdown');
        const searchResults = document.getElementById('searchResults');

        if (query.length === 0) {
            searchDropdown.classList.remove('show');
            return;
        }

        const results = this.searchableItems.filter(item =>
            item.title.toLowerCase().includes(query.toLowerCase()) ||
            item.category.toLowerCase().includes(query.toLowerCase())
        );

        if (results.length > 0) {
            this.renderSearchResults(results);
            searchDropdown.classList.add('show');
        } else {
            searchResults.innerHTML = `
                <div class="p-4 text-center text-text-light-secondary dark:text-text-dark-secondary">
                    <span class="material-icons-outlined text-4xl mb-2 opacity-50">search_off</span>
                    <p>No results found for "${query}"</p>
                </div>
            `;
            searchDropdown.classList.add('show');
        }
    }

    renderSearchResults(results) {
        const searchResults = document.getElementById('searchResults');
        const groupedResults = this.groupByCategory(results);

        let html = '';
        Object.keys(groupedResults).forEach(category => {
            html += `
                <div class="p-3 border-b border-border-light dark:border-border-dark">
                    <h4 class="font-semibold text-text-light dark:text-text-dark text-sm mb-2">${category}</h4>
                    <div class="space-y-2">
            `;
            
            groupedResults[category].forEach(item => {
                html += `
                    <button onclick="searchManager.navigateToItem('${item.id}')" 
                            class="w-full text-left p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-3">
                        <span class="material-icons-outlined text-primary text-sm">${this.getItemIcon(item.type)}</span>
                        <div class="flex-1">
                            <div class="text-sm font-medium text-text-light dark:text-text-dark">${item.title}</div>
                            <div class="text-xs text-text-light-secondary dark:text-text-dark-secondary">${item.type}</div>
                        </div>
                    </button>
                `;
            });
            
            html += `</div></div>`;
        });

        searchResults.innerHTML = html;
    }

    groupByCategory(items) {
        return items.reduce((groups, item) => {
            const category = item.category;
            if (!groups[category]) {
                groups[category] = [];
            }
            groups[category].push(item);
            return groups;
        }, {});
    }

    getItemIcon(type) {
        const icons = {
            toggle: 'toggle_on',
            input: 'input',
            password: 'password',
            button: 'play_arrow'
        };
        return icons[type] || 'settings';
    }

    navigateToItem(itemId) {
        const element = document.getElementById(itemId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            if (element.type === 'checkbox') {
                element.parentElement.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    element.parentElement.style.transform = 'scale(1)';
                }, 300);
            } else {
                element.style.boxShadow = '0 0 0 2px #358E83';
                setTimeout(() => {
                    element.style.boxShadow = '';
                }, 1000);
            }
            
            if (element.type === 'button') {
                element.classList.add('bg-opacity-80');
                setTimeout(() => {
                    element.classList.remove('bg-opacity-80');
                }, 500);
            }
            
            element.focus();
        }
        
        document.getElementById('searchDropdown').classList.remove('show');
        document.getElementById('searchInput').value = '';
    }

    performSearch(query) {
        const results = this.searchableItems.filter(item =>
            item.title.toLowerCase().includes(query.toLowerCase())
        );

        if (results.length === 1) {
            this.navigateToItem(results[0].id);
        } else if (results.length > 1) {
            this.handleSearch(query);
        } else {
            Swal.fire({
                title: 'Search',
                text: `No exact match found for "${query}"`,
                icon: 'info',
                timer: 2000,
                showConfirmButton: false,
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
        }
    }
}

class NotificationManager {
    constructor() {
        this.notifications = this.loadNotifications();
        this.initializeNotificationListeners();
        this.renderNotifications();
        this.updateNotificationCount();
    }

    loadNotifications() {
        const saved = localStorage.getItem('notifications');
        if (saved) {
            return JSON.parse(saved);
        }
        return [
            {
                id: 1,
                title: 'EMR Connection Issue',
                message: 'Connection to EMR system failed. Please check settings.',
                type: 'error',
                timestamp: new Date(Date.now() - 15 * 60000).toISOString(),
                read: false
            },
            {
                id: 2,
                title: 'Settings Saved',
                message: 'System settings have been updated successfully.',
                type: 'success',
                timestamp: new Date(Date.now() - 2 * 3600000).toISOString(),
                read: false
            },
            {
                id: 3,
                title: 'Billing Integration',
                message: 'Billing system integration has been enabled.',
                type: 'info',
                timestamp: new Date(Date.now() - 5 * 3600000).toISOString(),
                read: false
            }
        ];
    }

    initializeNotificationListeners() {
        document.getElementById('notificationBtn').addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleNotificationDropdown();
        });

        document.getElementById('markAllRead').addEventListener('click', () => {
            this.markAllAsRead();
        });

        document.getElementById('viewAllNotifications').addEventListener('click', () => {
            this.viewAllNotifications();
        });

        document.addEventListener('click', () => {
            this.hideNotificationDropdown();
        });
    }

    toggleNotificationDropdown() {
        const dropdown = document.getElementById('notificationDropdown');
        dropdown.classList.toggle('show');
    }

    hideNotificationDropdown() {
        const dropdown = document.getElementById('notificationDropdown');
        dropdown.classList.remove('show');
    }

    renderNotifications() {
        const container = document.getElementById('notificationList');
        container.innerHTML = '';

        const recentNotifications = [...this.notifications]
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, 5);

        if (recentNotifications.length === 0) {
            container.innerHTML = `
                <div class="p-4 text-center text-text-light-secondary dark:text-text-dark-secondary">
                    <span class="material-icons-outlined text-4xl mb-2 opacity-50">notifications_off</span>
                    <p>No notifications</p>
                </div>
            `;
            return;
        }

        recentNotifications.forEach(notification => {
            const notificationElement = document.createElement('div');
            notificationElement.className = `notification-item p-4 border-b border-border-light dark:border-border-dark ${notification.read ? '' : 'unread'}`;
            
            const icon = this.getNotificationIcon(notification.type);
            const timeAgo = this.getTimeAgo(notification.timestamp);
            
            notificationElement.innerHTML = `
                <div class="flex gap-3">
                    <div class="flex-shrink-0 mt-1">
                        <span class="material-icons-outlined ${this.getNotificationIconColor(notification.type)}">${icon}</span>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex justify-between items-start">
                            <h4 class="text-sm font-medium text-text-light dark:text-text-dark">${notification.title}</h4>
                            <span class="text-xs text-text-light-secondary dark:text-text-dark-secondary">${timeAgo}</span>
                        </div>
                        <p class="text-sm text-text-light-secondary dark:text-text-dark-secondary mt-1">${notification.message}</p>
                        <div class="mt-2 flex gap-2">
                            <button onclick="notificationManager.markAsRead(${notification.id})" class="text-xs text-primary hover:underline">
                                Mark as read
                            </button>
                            <button onclick="notificationManager.dismissNotification(${notification.id})" class="text-xs text-text-light-secondary dark:text-text-dark-secondary hover:underline">
                                Dismiss
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            container.appendChild(notificationElement);
        });
    }

    getNotificationIcon(type) {
        switch(type) {
            case 'error': return 'error';
            case 'warning': return 'warning';
            case 'success': return 'check_circle';
            case 'info': return 'info';
            default: return 'notifications';
        }
    }

    getNotificationIconColor(type) {
        switch(type) {
            case 'error': return 'text-red-500';
            case 'warning': return 'text-yellow-500';
            case 'success': return 'text-green-500';
            case 'info': return 'text-blue-500';
            default: return 'text-gray-500';
        }
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const past = new Date(timestamp);
        const diffInSeconds = Math.floor((now - past) / 1000);
        
        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
        return `${Math.floor(diffInSeconds / 86400)}d ago`;
    }

    markAsRead(id) {
        const notification = this.notifications.find(n => n.id === id);
        if (notification && !notification.read) {
            notification.read = true;
            this.saveNotifications();
            this.renderNotifications();
            this.updateNotificationCount();
        }
    }

    markAllAsRead() {
        let updated = false;
        this.notifications.forEach(notification => {
            if (!notification.read) {
                notification.read = true;
                updated = true;
            }
        });
        
        if (updated) {
            this.saveNotifications();
            this.renderNotifications();
            this.updateNotificationCount();
            
            Swal.fire({
                title: 'All notifications marked as read',
                icon: 'success',
                timer: 1500,
                showConfirmButton: false,
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
        }
    }

    dismissNotification(id) {
        this.notifications = this.notifications.filter(n => n.id !== id);
        this.saveNotifications();
        this.renderNotifications();
        this.updateNotificationCount();
    }

    addNotification(title, message, type = 'info') {
        const newNotification = {
            id: Date.now(),
            title,
            message,
            type,
            timestamp: new Date().toISOString(),
            read: false
        };
        
        this.notifications.unshift(newNotification);
        this.saveNotifications();
        this.renderNotifications();
        this.updateNotificationCount();
        
        this.showToastNotification(newNotification);
    }

    showToastNotification(notification) {
        const toast = document.createElement('div');
        toast.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg border-l-4 ${
            notification.type === 'error' ? 'bg-red-50 border-red-500 dark:bg-red-900/20' :
            notification.type === 'warning' ? 'bg-yellow-50 border-yellow-500 dark:bg-yellow-900/20' :
            notification.type === 'success' ? 'bg-green-50 border-green-500 dark:bg-green-900/20' :
            'bg-blue-50 border-blue-500 dark:bg-blue-900/20'
        } max-w-sm z-50 transform transition-transform duration-300 translate-x-full`;
        
        toast.innerHTML = `
            <div class="flex items-start gap-3">
                <span class="material-icons-outlined ${this.getNotificationIconColor(notification.type)}">${this.getNotificationIcon(notification.type)}</span>
                <div class="flex-1">
                    <h4 class="font-medium text-text-light dark:text-text-dark">${notification.title}</h4>
                    <p class="text-sm text-text-light-secondary dark:text-text-dark-secondary mt-1">${notification.message}</p>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" class="text-text-light-secondary dark:text-text-dark-secondary hover:text-text-light dark:hover:text-text-dark">
                    <span class="material-icons-outlined text-sm">close</span>
                </button>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.remove('translate-x-full');
        }, 10);
        
        setTimeout(() => {
            if (toast.parentElement) {
                toast.classList.add('translate-x-full');
                setTimeout(() => {
                    if (toast.parentElement) {
                        toast.remove();
                    }
                }, 300);
            }
        }, 5000);
    }

    viewAllNotifications() {
        this.hideNotificationDropdown();
        
        Swal.fire({
            title: 'All Notifications',
            html: `
                <div class="text-left max-h-96 overflow-y-auto space-y-4">
                    ${this.notifications.length === 0 ? 
                        '<div class="text-center text-text-light-secondary dark:text-text-dark-secondary py-8">No notifications</div>' :
                        this.notifications.map(notification => `
                            <div class="p-3 rounded-lg border border-border-light dark:border-border-dark ${notification.read ? '' : 'bg-blue-50 dark:bg-blue-900/20'}">
                                <div class="flex justify-between items-start">
                                    <div class="flex items-center gap-2">
                                        <span class="material-icons-outlined text-sm ${this.getNotificationIconColor(notification.type)}">${this.getNotificationIcon(notification.type)}</span>
                                        <strong class="text-text-light dark:text-text-dark">${notification.title}</strong>
                                    </div>
                                    <span class="text-xs text-text-light-secondary dark:text-text-dark-secondary">${this.getTimeAgo(notification.timestamp)}</span>
                                </div>
                                <p class="text-sm text-text-light-secondary dark:text-text-dark-secondary mt-1">${notification.message}</p>
                                <div class="mt-2 flex gap-2">
                                    ${!notification.read ? `
                                        <button onclick="notificationManager.markAsRead(${notification.id}); Swal.close();" class="text-xs text-primary hover:underline">
                                            Mark as read
                                        </button>
                                    ` : ''}
                                    <button onclick="notificationManager.dismissNotification(${notification.id}); Swal.close();" class="text-xs text-text-light-secondary dark:text-text-dark-secondary hover:underline">
                                        Dismiss
                                    </button>
                                </div>
                            </div>
                        `).join('')
                    }
                </div>
            `,
            width: 600,
            showConfirmButton: false,
            showCloseButton: true,
            background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
            color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
        });
    }

    updateNotificationCount() {
        const unreadCount = this.notifications.filter(n => !n.read).length;
        const countElement = document.getElementById('notificationCount');
        
        if (unreadCount === 0) {
            countElement.style.display = 'none';
        } else {
            countElement.style.display = 'flex';
            countElement.textContent = unreadCount > 99 ? '99+' : unreadCount;
        }
    }

    saveNotifications() {
        localStorage.setItem('notifications', JSON.stringify(this.notifications));
    }
}

class SystemSettingsManager {
    constructor() {
        this.settings = this.loadSettings();
        this.activityLog = this.loadActivityLog();
        this.initializeEventListeners();
        this.renderActivityLog();
        this.updateUIFromSettings();
    }

    loadSettings() {
        const saved = localStorage.getItem('systemSettings');
        if (saved) {
            return JSON.parse(saved);
        }
        return {
            emr: {
                enabled: false,
                url: 'https://emr-system-integration.ph',
                apiKey: 'emr_secret_key_2024',
                syncInterval: 15
            },
            billing: {
                enabled: false,
                url: 'https://pharmacy-system-integration.ph',
                apiKey: 'billing_secret_key_2024',
                syncInterval: 5
            }
        };
    }

    loadActivityLog() {
        const saved = localStorage.getItem('integrationActivity');
        if (saved) {
            return JSON.parse(saved);
        }
        return [
            {
                system: 'EMR Integration',
                status: 'success',
                timestamp: new Date(Date.now() - 1800000).toISOString(),
                details: 'Sync completed successfully.'
            },
            {
                system: 'Billing System',
                status: 'failed',
                timestamp: new Date(Date.now() - 2100000).toISOString(),
                details: 'API connection error.'
            }
        ];
    }

    initializeEventListeners() {
        document.getElementById('saveBtn').addEventListener('click', () => this.saveSettings());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetSettings());
        document.getElementById('test-emr').addEventListener('click', () => this.testConnection('emr'));
        document.getElementById('test-billing').addEventListener('click', () => this.testConnection('billing'));
        document.getElementById('refreshActivity').addEventListener('click', () => this.refreshActivity());
        document.getElementById('helpBtn').addEventListener('click', () => this.showHelp());
        document.getElementById('emr-enable').addEventListener('change', (e) => this.toggleIntegration('emr', e.target.checked));
        document.getElementById('billing-enable').addEventListener('change', (e) => this.toggleIntegration('billing', e.target.checked));
        document.getElementById('emr-url').addEventListener('change', (e) => this.updateSetting('emr', 'url', e.target.value));
        document.getElementById('emr-api-key').addEventListener('change', (e) => this.updateSetting('emr', 'apiKey', e.target.value));
        document.getElementById('emr-sync').addEventListener('change', (e) => this.updateSetting('emr', 'syncInterval', parseInt(e.target.value)));
        document.getElementById('billing-url').addEventListener('change', (e) => this.updateSetting('billing', 'url', e.target.value));
        document.getElementById('billing-api-key').addEventListener('change', (e) => this.updateSetting('billing', 'apiKey', e.target.value));
        document.getElementById('billing-sync').addEventListener('change', (e) => this.updateSetting('billing', 'syncInterval', parseInt(e.target.value)));
    }

    updateSetting(system, key, value) {
        this.settings[system][key] = value;
        this.updateStatusBadge(system);
    }

    toggleIntegration(system, enabled) {
        this.settings[system].enabled = enabled;
        this.updateStatusBadge(system);
        
        this.addActivityLog(
            system === 'emr' ? 'EMR Integration' : 'Billing System',
            'info',
            `${system === 'emr' ? 'EMR' : 'Billing'} integration ${enabled ? 'enabled' : 'disabled'}`
        );
        
        notificationManager.addNotification(
            `${system === 'emr' ? 'EMR' : 'Billing'} Integration ${enabled ? 'Enabled' : 'Disabled'}`,
            `${system === 'emr' ? 'EMR' : 'Billing'} integration has been ${enabled ? 'enabled' : 'disabled'}.`,
            'info'
        );
    }

    updateStatusBadge(system) {
        const badge = document.getElementById(`${system}-status`);
        if (this.settings[system].enabled) {
            badge.textContent = 'Enabled';
            badge.className = 'bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-green-900 dark:text-green-300';
        } else {
            badge.textContent = 'Disabled';
            badge.className = 'bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-red-900 dark:text-red-300';
        }
    }

    updateUIFromSettings() {
        document.getElementById('emr-enable').checked = this.settings.emr.enabled;
        document.getElementById('emr-url').value = this.settings.emr.url;
        document.getElementById('emr-api-key').value = this.settings.emr.apiKey;
        document.getElementById('emr-sync').value = this.settings.emr.syncInterval;
        document.getElementById('billing-enable').checked = this.settings.billing.enabled;
        document.getElementById('billing-url').value = this.settings.billing.url;
        document.getElementById('billing-api-key').value = this.settings.billing.apiKey;
        document.getElementById('billing-sync').value = this.settings.billing.syncInterval;
        this.updateStatusBadge('emr');
        this.updateStatusBadge('billing');
    }

    async testConnection(system) {
        const button = document.getElementById(`test-${system}`);
        const originalText = button.innerHTML;
        
        button.innerHTML = '<span class="material-icons-outlined loading text-base mr-2">autorenew</span> Testing...';
        button.disabled = true;
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const success = Math.random() > 0.3;
        
        if (success) {
            Swal.fire({
                title: 'Connection Successful!',
                text: `${system.toUpperCase()} integration is working properly.`,
                icon: 'success',
                confirmButtonText: 'OK',
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
            this.addActivityLog(
                system === 'emr' ? 'EMR Integration' : 'Billing System',
                'success',
                'Connection test completed successfully'
            );
            
            notificationManager.addNotification(
                `${system.toUpperCase()} Connection Test`,
                `${system.toUpperCase()} integration is working properly.`,
                'success'
            );
        } else {
            Swal.fire({
                title: 'Connection Failed',
                text: `Unable to connect to ${system.toUpperCase()} system. Please check your settings.`,
                icon: 'error',
                confirmButtonText: 'OK',
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
            this.addActivityLog(
                system === 'emr' ? 'EMR Integration' : 'Billing System',
                'failed',
                'Connection test failed - check API settings'
            );
            
            notificationManager.addNotification(
                `${system.toUpperCase()} Connection Failed`,
                `Unable to connect to ${system.toUpperCase()} system. Please check your settings.`,
                'error'
            );
        }
        
        button.innerHTML = originalText;
        button.disabled = false;
    }

    saveSettings() {
        localStorage.setItem('systemSettings', JSON.stringify(this.settings));
        localStorage.setItem('integrationActivity', JSON.stringify(this.activityLog));
        
        Swal.fire({
            title: 'Settings Saved!',
            text: 'Your system settings have been saved successfully.',
            icon: 'success',
            timer: 2000,
            showConfirmButton: false,
            background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
            color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
        });
        
        this.addActivityLog('System', 'success', 'Settings updated and saved');
        
        notificationManager.addNotification(
            'Settings Saved',
            'Your system settings have been saved successfully.',
            'success'
        );
    }

    resetSettings() {
        Swal.fire({
            title: 'Reset Settings?',
            text: 'This will restore all settings to their default values.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, reset',
            cancelButtonText: 'Cancel',
            background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
            color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
        }).then((result) => {
            if (result.isConfirmed) {
                localStorage.removeItem('systemSettings');
                this.settings = this.loadSettings();
                this.updateUIFromSettings();
                
                Swal.fire({
                    title: 'Settings Reset!',
                    text: 'All settings have been restored to defaults.',
                    icon: 'success',
                    timer: 2000,
                    showConfirmButton: false,
                    background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                    color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
                });
                
                this.addActivityLog('System', 'info', 'Settings reset to defaults');
                
                notificationManager.addNotification(
                    'Settings Reset',
                    'All settings have been restored to defaults.',
                    'info'
                );
            }
        });
    }

    addActivityLog(system, status, details) {
        this.activityLog.unshift({
            system,
            status,
            timestamp: new Date().toISOString(),
            details
        });
        
        if (this.activityLog.length > 50) {
            this.activityLog = this.activityLog.slice(0, 50);
        }
        
        this.renderActivityLog();
    }

    renderActivityLog() {
        const container = document.getElementById('activityTable');
        container.innerHTML = '';
        
        this.activityLog.forEach(activity => {
            const row = document.createElement('tr');
            
            const statusClass = activity.status === 'success' 
                ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                : activity.status === 'failed'
                ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                : 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
            
            const statusText = activity.status === 'success' ? 'Success' 
                : activity.status === 'failed' ? 'Failed' 
                : 'Info';
            
            row.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-text-light dark:text-text-dark">${activity.system}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">${statusText}</span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-text-light-secondary dark:text-text-dark-secondary">
                    ${new Date(activity.timestamp).toLocaleString()}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-text-light-secondary dark:text-text-dark-secondary">${activity.details}</td>
            `;
            
            container.appendChild(row);
        });
    }

    refreshActivity() {
        const button = document.getElementById('refreshActivity');
        const originalText = button.innerHTML;
        
        button.innerHTML = '<span class="material-icons-outlined loading text-base mr-1">autorenew</span> Refreshing...';
        
        setTimeout(() => {
            this.renderActivityLog();
            button.innerHTML = originalText;
            
            Swal.fire({
                title: 'Refreshed!',
                text: 'Activity log has been updated.',
                icon: 'success',
                timer: 1500,
                showConfirmButton: false,
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
        }, 1000);
    }

    showHelp() {
        Swal.fire({
            title: 'System Settings Help',
            html: `
                <div class="text-left space-y-3">
                    <div>
                        <strong>EMR Integration</strong>
                        <p class="text-sm text-gray-600 dark:text-gray-300">Connect to Electronic Medical Records system for patient data synchronization.</p>
                    </div>
                    <div>
                        <strong>Billing Integration</strong>
                        <p class="text-sm text-gray-600 dark:text-gray-300">Integrate with external billing systems for automated payment processing.</p>
                    </div>
                    <div>
                        <strong>API Configuration</strong>
                        <p class="text-sm text-gray-600 dark:text-gray-300">Ensure correct API URLs and authentication keys for successful integration.</p>
                    </div>
                </div>
            `,
            icon: 'info',
            confirmButtonText: 'Got it!',
            background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
            color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
        });
    }
}

function togglePasswordVisibility(inputId) {
    const input = document.getElementById(inputId);
    const button = input.nextElementSibling;
    const icon = button.querySelector('span');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.textContent = 'visibility_off';
    } else {
        input.type = 'password';
        icon.textContent = 'visibility';
    }
}

function confirmBackToHMS(event) {
    event.preventDefault();
    Swal.fire({
        title: 'Leave System Settings?',
        text: 'Any unsaved changes will be lost.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, go back',
        cancelButtonText: 'Stay here',
        background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
        color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'index.html';
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    window.searchManager = new SearchManager();
    window.notificationManager = new NotificationManager();
    window.settingsManager = new SystemSettingsManager();
});

setTimeout(() => {
    if (window.settingsManager) {
        window.settingsManager.addActivityLog('System', 'info', 'System settings page loaded');
    }
}, 1000);