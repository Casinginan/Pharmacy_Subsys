// Button Management System
class ButtonManager {
    constructor() {
        this.buttonStates = new Map();
        this.init();
    }

    init() {
        this.setupButtonConfigurations();
        this.setupButtonEventListeners();
        this.loadButtonStates();
    }

    // Configure button behaviors and styles
    setupButtonConfigurations() {
        const buttonConfigs = {
            'addUserBtn': {
                type: 'primary',
                icon: 'add',
                loadingText: 'Adding User...',
                successText: 'User Added',
                errorText: 'Failed to Add'
            },
            'exportUsersBtn': {
                type: 'secondary',
                icon: 'download',
                loadingText: 'Exporting...',
                successText: 'Exported Successfully',
                errorText: 'Export Failed'
            },
            'saveUserBtn': {
                type: 'primary',
                icon: 'save',
                loadingText: 'Saving...',
                successText: 'Saved',
                errorText: 'Save Failed'
            },
            'updateUserBtn': {
                type: 'primary',
                icon: 'update',
                loadingText: 'Updating...',
                successText: 'Updated',
                errorText: 'Update Failed'
            },
            'cancelAddUserBtn': {
                type: 'outline',
                icon: 'cancel',
                loadingText: 'Cancelling...'
            },
            'cancelEditUserBtn': {
                type: 'outline',
                icon: 'cancel',
                loadingText: 'Cancelling...'
            }
        };

        this.applyButtonStyles(buttonConfigs);
    }

    // Apply consistent styles to buttons
    applyButtonStyles(configs) {
        Object.keys(configs).forEach(buttonId => {
            const button = document.getElementById(buttonId);
            if (!button) return;

            const config = configs[buttonId];
            
            // Base styles
            button.classList.add('transition-all', 'duration-200', 'ease-in-out');
            
            // Type-specific styles
            switch(config.type) {
                case 'primary':
                    button.classList.add('bg-primary', 'hover:bg-primary/90', 'text-white', 'shadow-sm');
                    break;
                case 'secondary':
                    button.classList.add('bg-blue-500', 'hover:bg-blue-600', 'text-white', 'shadow-sm');
                    break;
                case 'outline':
                    button.classList.add('border', 'border-gray-300', 'dark:border-gray-600', 
                                       'hover:bg-gray-50', 'dark:hover:bg-gray-700', 
                                       'text-gray-700', 'dark:text-gray-300');
                    break;
                case 'danger':
                    button.classList.add('bg-red-500', 'hover:bg-red-600', 'text-white', 'shadow-sm');
                    break;
            }

            // Store configuration
            this.buttonStates.set(buttonId, {
                ...config,
                originalHTML: button.innerHTML,
                isDisabled: false,
                isLoading: false
            });
        });
    }

    // Setup global button event listeners
    setupButtonEventListeners() {
        // Prevent multiple rapid clicks
        document.addEventListener('click', (e) => {
            if (e.target.closest('button')) {
                const button = e.target.closest('button');
                this.handleButtonClick(button);
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl+Shift+N for new user
            if (e.ctrlKey && e.shiftKey && e.key === 'N') {
                e.preventDefault();
                document.getElementById('addUserBtn')?.click();
            }
            // Ctrl+E for export
            if (e.ctrlKey && e.key === 'E') {
                e.preventDefault();
                document.getElementById('exportUsersBtn')?.click();
            }
            // Escape to close modals
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    // Handle button click with debouncing
    handleButtonClick(button) {
        const buttonId = button.id;
        if (!buttonId) return;

        const state = this.buttonStates.get(buttonId);
        if (state && (state.isLoading || state.isDisabled)) {
            return;
        }

        // Add click animation
        this.animateButtonClick(button);

        // Handle specific button actions
        switch(buttonId) {
            case 'addUserBtn':
                this.debounce(() => userManager.openAddUserModal(), 300)();
                break;
            case 'exportUsersBtn':
                this.debounce(() => userManager.exportUsers(), 300)();
                break;
            case 'saveUserBtn':
                this.setButtonLoading('saveUserBtn', true);
                break;
            case 'updateUserBtn':
                this.setButtonLoading('updateUserBtn', true);
                break;
        }
    }

    // Set button loading state
    setButtonLoading(buttonId, isLoading) {
        const button = document.getElementById(buttonId);
        const state = this.buttonStates.get(buttonId);
        
        if (!button || !state) return;

        state.isLoading = isLoading;
        
        if (isLoading) {
            const originalWidth = button.offsetWidth;
            button.style.minWidth = `${originalWidth}px`;
            button.innerHTML = `
                <span class="flex items-center gap-2">
                    <span class="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span>
                    ${state.loadingText}
                </span>
            `;
            button.disabled = true;
            button.classList.add('opacity-75', 'cursor-not-allowed');
        } else {
            button.style.minWidth = '';
            button.innerHTML = state.originalHTML;
            button.disabled = false;
            button.classList.remove('opacity-75', 'cursor-not-allowed');
        }
    }

    // Set button enabled/disabled state
    setButtonState(buttonId, enabled) {
        const button = document.getElementById(buttonId);
        const state = this.buttonStates.get(buttonId);
        
        if (!button || !state) return;

        state.isDisabled = !enabled;
        button.disabled = !enabled;
        
        if (enabled) {
            button.classList.remove('opacity-50', 'cursor-not-allowed');
        } else {
            button.classList.add('opacity-50', 'cursor-not-allowed');
        }
    }

    // Show button success state temporarily
    showButtonSuccess(buttonId) {
        const button = document.getElementById(buttonId);
        const state = this.buttonStates.get(buttonId);
        
        if (!button || !state) return;

        const originalHTML = button.innerHTML;
        button.innerHTML = `
            <span class="flex items-center gap-2">
                <span class="material-icons text-sm">check</span>
                ${state.successText}
            </span>
        `;
        button.classList.add('bg-success', 'hover:bg-success');
        button.classList.remove('bg-primary', 'hover:bg-primary/90');

        setTimeout(() => {
            button.innerHTML = originalHTML;
            button.classList.remove('bg-success', 'hover:bg-success');
            button.classList.add('bg-primary', 'hover:bg-primary/90');
        }, 2000);
    }

    // Show button error state
    showButtonError(buttonId) {
        const button = document.getElementById(buttonId);
        const state = this.buttonStates.get(buttonId);
        
        if (!button || !state) return;

        const originalHTML = button.innerHTML;
        button.innerHTML = `
            <span class="flex items-center gap-2">
                <span class="material-icons text-sm">error</span>
                ${state.errorText}
            </span>
        `;
        button.classList.add('bg-danger', 'hover:bg-danger');
        button.classList.remove('bg-primary', 'hover:bg-primary/90');

        setTimeout(() => {
            button.innerHTML = originalHTML;
            button.classList.remove('bg-danger', 'hover:bg-danger');
            button.classList.add('bg-primary', 'hover:bg-primary/90');
        }, 3000);
    }

    // Animate button click
    animateButtonClick(button) {
        button.style.transform = 'scale(0.95)';
        setTimeout(() => {
            button.style.transform = 'scale(1)';
        }, 150);
    }

    // Close all modals
    closeAllModals() {
        document.getElementById('addUserModal')?.classList.add('hidden');
        document.getElementById('editUserModal')?.classList.add('hidden');
        
        // Reset any loading buttons
        this.setButtonLoading('saveUserBtn', false);
        this.setButtonLoading('updateUserBtn', false);
    }

    // Debounce function to prevent multiple rapid clicks
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Load saved button states from localStorage
    loadButtonStates() {
        const savedStates = localStorage.getItem('buttonStates');
        if (savedStates) {
            const states = JSON.parse(savedStates);
            Object.keys(states).forEach(buttonId => {
                this.setButtonState(buttonId, states[buttonId]);
            });
        }
    }

    // Save button states to localStorage
    saveButtonStates() {
        const states = {};
        this.buttonStates.forEach((state, buttonId) => {
            states[buttonId] = !state.isDisabled;
        });
        localStorage.setItem('buttonStates', JSON.stringify(states));
    }

    // Enable/disable all action buttons
    toggleAllActionButtons(enabled) {
        const actionButtons = ['addUserBtn', 'exportUsersBtn', 'saveUserBtn', 'updateUserBtn'];
        actionButtons.forEach(buttonId => {
            this.setButtonState(buttonId, enabled);
        });
    }

    // Add ripple effect to buttons
    addRippleEffect(button) {
        button.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = button.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;

            ripple.style.cssText = `
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                transform: scale(0);
                animation: ripple 600ms linear;
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
            `;

            button.style.position = 'relative';
            button.style.overflow = 'hidden';
            button.appendChild(ripple);

            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    }

    // Initialize ripple effects for all buttons
    initRippleEffects() {
        const buttons = document.querySelectorAll('button');
        buttons.forEach(button => {
            this.addRippleEffect(button);
        });
    }
}

// Add CSS for ripple animation
const rippleStyles = `
@keyframes ripple {
    to {
        transform: scale(4);
        opacity: 0;
    }
}
`;
const styleSheet = document.createElement('style');
styleSheet.textContent = rippleStyles;
document.head.appendChild(styleSheet);

// Enhanced UserManager with button integration
class EnhancedUserManager extends UserManager {
    constructor() {
        super();
        this.buttonManager = new ButtonManager();
    }

    saveUser() {
        this.buttonManager.setButtonLoading('saveUserBtn', true);
        
        setTimeout(() => {
            super.saveUser();
            this.buttonManager.setButtonLoading('saveUserBtn', false);
            this.buttonManager.showButtonSuccess('saveUserBtn');
        }, 1000);
    }

    updateUser() {
        this.buttonManager.setButtonLoading('updateUserBtn', true);
        
        setTimeout(() => {
            super.updateUser();
            this.buttonManager.setButtonLoading('updateUserBtn', false);
            this.buttonManager.showButtonSuccess('updateUserBtn');
        }, 1000);
    }

    exportUsers() {
        this.buttonManager.setButtonLoading('exportUsersBtn', true);
        
        setTimeout(() => {
            super.exportUsers();
            this.buttonManager.setButtonLoading('exportUsersBtn', false);
            this.buttonManager.showButtonSuccess('exportUsersBtn');
        }, 1500);
    }
}

// Initialize enhanced system
let userManager;
let buttonManager;

document.addEventListener('DOMContentLoaded', function() {
    userManager = new EnhancedUserManager();
    buttonManager = new ButtonManager();
    
    // Add ripple effects to all buttons
    buttonManager.initRippleEffects();
    
    console.log("Enhanced System Management initialized!");
});

// Utility functions for button management
window.ButtonUtils = {
    // Quick enable/disable buttons by type
    disableButtonsByType(type) {
        const buttons = document.querySelectorAll(`button[data-type="${type}"]`);
        buttons.forEach(button => {
            button.disabled = true;
            button.classList.add('opacity-50', 'cursor-not-allowed');
        });
    },
    
    enableButtonsByType(type) {
        const buttons = document.querySelectorAll(`button[data-type="${type}"]`);
        buttons.forEach(button => {
            button.disabled = false;
            button.classList.remove('opacity-50', 'cursor-not-allowed');
        });
    },
    
    // Show loading state for multiple buttons
    setButtonsLoading(buttonIds, isLoading) {
        buttonIds.forEach(buttonId => {
            if (buttonManager) {
                buttonManager.setButtonLoading(buttonId, isLoading);
            }
        });
    },
    
    // Reset all buttons to default state
    resetAllButtons() {
        if (buttonManager) {
            buttonManager.toggleAllActionButtons(true);
        }
    }
};