// Tailwind Configuration
tailwind.config = {
    darkMode: "class",
    theme: {
        extend: {
            colors: {
                primary: "#007A7A",
                "background-light": "#F0F7F7",
                "background-dark": "#0A1919",
                "surface-light": "#FFFFFF",
                "surface-dark": "#112222",
                "text-light": "#0D1A1A",
                "text-dark": "#E0F2F2",
                "subtext-light": "#4D6969",
                "subtext-dark": "#80B3B3",
            },
            fontFamily: {
                sans: ['Inter', 'sans-serif'],
            },
            borderRadius: {
                'lg': '0.75rem',
                'xl': '1rem',
                '2xl': '1.5rem',
            },
        },
    },
};

// ==================== DATA ====================
let transactions = [
    { id: 1, date: '2024-01-23', patientId: 'PID-00123', medicine: 'Paracetamol', amount: 10.50, status: 'Paid' },
    { id: 2, date: '2024-01-22', patientId: 'PID-00122', medicine: 'Amoxicillin', amount: 25.00, status: 'Pending' },
    { id: 3, date: '2024-01-21', patientId: 'PID-00121', medicine: 'Ibuprofen', amount: 8.25, status: 'Failed' },
    { id: 4, date: '2024-01-20', patientId: 'PID-00120', medicine: 'Aspirin', amount: 5.50, status: 'Paid' },
    { id: 5, date: '2024-01-19', patientId: 'PID-00119', medicine: 'Omeprazole', amount: 18.75, status: 'Paid' },
    { id: 6, date: '2024-01-18', patientId: 'PID-00118', medicine: 'Metformin', amount: 13.65, status: 'Paid' }
];

let filteredTransactions = [...transactions];
let currentSort = { field: null, ascending: true };
let selectedTransaction = null;
let statusFilters = ['all'];

// ==================== RENDERING ====================
function renderTransactions() {
    const tbody = document.getElementById('transactionsTableBody');
    const noResults = document.getElementById('noResults');
    
    if (filteredTransactions.length === 0) {
        tbody.innerHTML = '';
        noResults.classList.remove('hidden');
        return;
    }
    
    noResults.classList.add('hidden');
    tbody.innerHTML = filteredTransactions.map(t => `
        <tr class="border-b border-primary/10 dark:border-primary/20 hover:bg-primary/5 dark:hover:bg-primary/10 transition-colors">
            <td class="px-6 py-4">${formatDate(t.date)}</td>
            <td class="px-6 py-4">${t.patientId}</td>
            <td class="px-6 py-4">${t.medicine}</td>
            <td class="px-6 py-4">₱${t.amount.toFixed(2)}</td>
            <td class="px-6 py-4">
                <span class="px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(t.status)}">${t.status}</span>
            </td>
            <td class="px-6 py-4">
                <button onclick="showTransactionDetails(${t.id})" class="text-subtext-light dark:text-subtext-dark hover:text-primary transition-colors">
                    <span class="material-icons text-base">more_vert</span>
                </button>
            </td>
        </tr>
    `).join('');
    
    updateStats();
}

function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function getStatusClass(status) {
    switch(status) {
        case 'Paid': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
        case 'Pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
        case 'Failed': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
        default: return '';
    }
}

function updateStats() {
    const today = new Date().toISOString().split('T')[0];
    const todayTransactions = transactions.filter(t => t.date === today);
    const todaysSales = todayTransactions.reduce((sum, t) => t.status === 'Paid' ? sum + t.amount : sum, 0);
    
    const paidTransactions = transactions.filter(t => t.status === 'Paid');
    const totalRevenue = paidTransactions.reduce((sum, t) => sum + t.amount, 0);
    
    document.getElementById('todaysSales').textContent = `₱${todaysSales.toFixed(2)}`;
    document.getElementById('totalTransactions').textContent = transactions.length;
    document.getElementById('totalRevenue').textContent = `₱${totalRevenue.toFixed(2)}`;
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    const yesterdayTransactions = transactions.filter(t => t.date === yesterdayStr);
    const yesterdaysSales = yesterdayTransactions.reduce((sum, t) => t.status === 'Paid' ? sum + t.amount : sum, 0);
    
    let change = 0;
    if (yesterdaysSales > 0) {
        change = ((todaysSales - yesterdaysSales) / yesterdaysSales * 100).toFixed(0);
    } else if (todaysSales > 0) {
        change = 100;
    }
    
    document.getElementById('todaysChange').textContent = `${change >= 0 ? '+' : ''}${change}% from yesterday`;
}

// ==================== SORTING ====================
function sortTable(field) {
    if (currentSort.field === field) {
        currentSort.ascending = !currentSort.ascending;
    } else {
        currentSort.field = field;
        currentSort.ascending = true;
    }
    
    filteredTransactions.sort((a, b) => {
        let aVal = a[field];
        let bVal = b[field];
        
        if (field === 'amount') {
            aVal = parseFloat(aVal);
            bVal = parseFloat(bVal);
        } else if (field === 'date') {
            aVal = new Date(aVal);
            bVal = new Date(bVal);
        } else {
            aVal = aVal.toString().toLowerCase();
            bVal = bVal.toString().toLowerCase();
        }
        
        if (aVal < bVal) return currentSort.ascending ? -1 : 1;
        if (aVal > bVal) return currentSort.ascending ? 1 : -1;
        return 0;
    });
    
    renderTransactions();
}

// ==================== FILTERING ====================
function filterTransactions() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    filteredTransactions = transactions.filter(t => {
        const matchesSearch = t.patientId.toLowerCase().includes(searchTerm) ||
                            t.medicine.toLowerCase().includes(searchTerm);
        
        const matchesStatus = statusFilters.includes('all') || statusFilters.includes(t.status);
        
        return matchesSearch && matchesStatus;
    });
    
    renderTransactions();
}

function toggleDateFilter() {
    const panel = document.getElementById('dateFilterPanel');
    panel.classList.toggle('hidden');
    if (!panel.classList.contains('hidden')) {
        document.getElementById('statusFilterPanel').classList.add('hidden');
    }
}

function toggleStatusFilter() {
    const panel = document.getElementById('statusFilterPanel');
    panel.classList.toggle('hidden');
    if (!panel.classList.contains('hidden')) {
        document.getElementById('dateFilterPanel').classList.add('hidden');
    }
}

function clearDateFilter() {
    document.getElementById('fromDate').value = '';
    document.getElementById('toDate').value = '';
    filteredTransactions = [...transactions];
    renderTransactions();
}

function applyDateFilter() {
    const fromDate = document.getElementById('fromDate').value;
    const toDate = document.getElementById('toDate').value;

    filteredTransactions = transactions.filter(t => {
        const tDate = new Date(t.date);
        return (!fromDate || tDate >= new Date(fromDate)) &&
               (!toDate || tDate <= new Date(toDate));
    });

    renderTransactions();
    toggleDateFilter();
}

function handleStatusFilter(checkbox) {
    if (checkbox.value === "all" && checkbox.checked) {
        document.querySelectorAll('#statusFilterPanel input[type="checkbox"]').forEach(cb => {
            if (cb.value !== "all") cb.checked = false;
        });
        statusFilters = ['all'];
    } else {
        document.querySelector('#statusFilterPanel input[value="all"]').checked = false;
        const checked = Array.from(document.querySelectorAll('#statusFilterPanel input[type="checkbox"]:checked')).map(cb => cb.value);
        statusFilters = checked.length > 0 ? checked : ['all'];
    }
    filterTransactions();
}

// ==================== MODAL HANDLING ====================
function showNewTransactionModal() {
    document.getElementById('newTransactionModal').classList.remove('hidden');
}

function closeNewTransactionModal() {
    document.getElementById('newTransactionModal').classList.add('hidden');
    document.getElementById('newTransactionForm').reset();
}

function addTransaction(event) {
    event.preventDefault();
    const id = transactions.length ? transactions[transactions.length - 1].id + 1 : 1;
    const newT = {
        id,
        date: new Date().toISOString().split('T')[0],
        patientId: document.getElementById('newPatientId').value,
        medicine: document.getElementById('newMedicine').value,
        amount: parseFloat(document.getElementById('newAmount').value),
        status: document.getElementById('newStatus').value,
    };
    transactions.push(newT);
    filteredTransactions = [...transactions];
    renderTransactions();
    closeNewTransactionModal();
}

function showTransactionDetails(id) {
    selectedTransaction = transactions.find(t => t.id === id);
    const details = document.getElementById('transactionDetails');
    details.innerHTML = `
        <p><strong>Date:</strong> ${formatDate(selectedTransaction.date)}</p>
        <p><strong>Patient ID:</strong> ${selectedTransaction.patientId}</p>
        <p><strong>Medicine:</strong> ${selectedTransaction.medicine}</p>
        <p><strong>Amount:</strong> ₱${selectedTransaction.amount.toFixed(2)}</p>
        <p><strong>Status:</strong> ${selectedTransaction.status}</p>
    `;
    document.getElementById('transactionModal').classList.remove('hidden');
}

function closeTransactionModal() {
    document.getElementById('transactionModal').classList.add('hidden');
}

function deleteTransaction() {
    if (!selectedTransaction) return;
    transactions = transactions.filter(t => t.id !== selectedTransaction.id);
    filteredTransactions = [...transactions];
    renderTransactions();
    closeTransactionModal();
}

function editTransaction() {
    if (!selectedTransaction) return;
    closeTransactionModal();
    showNewTransactionModal();
    document.getElementById('newPatientId').value = selectedTransaction.patientId;
    document.getElementById('newMedicine').value = selectedTransaction.medicine;
    document.getElementById('newAmount').value = selectedTransaction.amount;
    document.getElementById('newStatus').value = selectedTransaction.status;

    // Override submit
    const form = document.getElementById('newTransactionForm');
    form.onsubmit = function(e) {
        e.preventDefault();
        selectedTransaction.patientId = document.getElementById('newPatientId').value;
        selectedTransaction.medicine = document.getElementById('newMedicine').value;
        selectedTransaction.amount = parseFloat(document.getElementById('newAmount').value);
        selectedTransaction.status = document.getElementById('newStatus').value;
        renderTransactions();
        closeNewTransactionModal();
        form.onsubmit = addTransaction; // reset back
    }
}

// ==================== EXPORT FUNCTIONS ====================
function exportCSV() {
    let csv = "Date,Patient ID,Medicine,Amount,Status\n";
    transactions.forEach(t => {
        csv += `${t.date},${t.patientId},${t.medicine},${t.amount},${t.status}\n`;
    });
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "transactions.csv";
    a.click();
    URL.revokeObjectURL(url);
}

function exportPDF() {
    const printContent = document.getElementById('transactionsTableBody').innerHTML;
    const win = window.open("", "", "height=600,width=800");
    win.document.write("<h3>Sales & Billing Transactions</h3><table border='1'>" + printContent + "</table>");
    win.document.close();
    win.print();
}

// ==================== EVENT LISTENERS ====================
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('searchInput').addEventListener('input', filterTransactions);
    renderTransactions();
});

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        renderTransactions();
    });
} else {
    renderTransactions();
}

function deleteTransaction() {
  Swal.fire({
    title: "Delete Transaction?",
    text: "This action cannot be undone.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#007A7A", // ✅ teal like others
    cancelButtonColor: "#6B7280", // ✅ gray
    confirmButtonText: "Yes, delete it",
    cancelButtonText: "Cancel"
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: "Deleted!",
        text: "Transaction has been successfully deleted.",
        icon: "success",
        timer: 1500,
        showConfirmButton: false
      });

      // optional: close modal or refresh
      setTimeout(() => {
        const modal = document.getElementById('transactionModal');
        if (modal) modal.classList.add('hidden');
      }, 1500);
    }
  });
}

// Billing Page Specific Settings
class BillingSettings {
    constructor() {
        this.settings = PharmacySettings.getModuleSettings('billing');
        this.initializeBillingSettings();
    }

    initializeBillingSettings() {
        this.applyBillingSettings();
        
        window.addEventListener('pharmacyModuleSettingsChanged', (event) => {
            if (event.detail.module === 'billing') {
                this.settings = event.detail.settings;
                this.applyBillingSettings();
            }
        });
    }

    applyBillingSettings() {
        // Update currency display
        this.updateCurrencyDisplay();
        
        // Update receipt settings
        this.updateReceiptSettings();
        
        // Update pagination
        this.updatePagination();
    }

    updateCurrencyDisplay() {
        const currencyElements = document.querySelectorAll('[data-currency]');
        currencyElements.forEach(el => {
            const amount = el.getAttribute('data-amount');
            if (amount) {
                el.textContent = this.formatCurrency(parseFloat(amount));
            }
        });
    }

    formatCurrency(amount) {
        const symbols = {
            'PHP': '₱',
            'USD': '$',
            'EUR': '€'
        };
        return `${symbols[this.settings.currency] || ''}${amount.toFixed(2)}`;
    }

    updateReceiptSettings() {
        // Apply receipt template settings
        const receiptStyle = document.getElementById('receipt-style');
        if (receiptStyle) {
            receiptStyle.innerHTML = this.getReceiptCSS();
        }
    }

    updatePagination() {
        // Update items per page in tables
        const tables = document.querySelectorAll('table');
        tables.forEach(table => {
            // Implement pagination logic based on itemsPerPage
        });
    }

    showBillingSettingsModal() {
        Swal.fire({
            title: 'Billing Settings',
            html: this.getBillingSettingsHTML(),
            width: 500,
            showConfirmButton: false,
            showCloseButton: true,
            background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
            color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
        });
    }

    getBillingSettingsHTML() {
        return `
            <div class="space-y-4 text-left">
                <div>
                    <label class="block text-sm font-medium mb-2">Tax Rate (%)</label>
                    <input type="number" id="billingTaxRate" value="${this.settings.taxRate}" 
                           step="0.1" min="0" max="50" class="w-full p-2 border rounded-lg dark:bg-gray-700">
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Currency</label>
                    <select id="billingCurrency" class="w-full p-2 border rounded-lg dark:bg-gray-700">
                        <option value="PHP" ${this.settings.currency === 'PHP' ? 'selected' : ''}>Philippine Peso (₱)</option>
                        <option value="USD" ${this.settings.currency === 'USD' ? 'selected' : ''}>US Dollar ($)</option>
                        <option value="EUR" ${this.settings.currency === 'EUR' ? 'selected' : ''}>Euro (€)</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium mb-2">Receipt Template</label>
                    <select id="billingReceiptTemplate" class="w-full p-2 border rounded-lg dark:bg-gray-700">
                        <option value="standard" ${this.settings.receiptTemplate === 'standard' ? 'selected' : ''}>Standard</option>
                        <option value="detailed" ${this.settings.receiptTemplate === 'detailed' ? 'selected' : ''}>Detailed</option>
                        <option value="minimal" ${this.settings.receiptTemplate === 'minimal' ? 'selected' : ''}>Minimal</option>
                    </select>
                </div>

                <div class="space-y-2">
                    <label class="flex items-center gap-2">
                        <input type="checkbox" id="billingPrintReceipt" ${this.settings.printReceipt ? 'checked' : ''}>
                        <span>Auto-print Receipts</span>
                    </label>
                </div>

                <div class="flex gap-2 pt-4">
                    <button onclick="billingSettings.resetToDefaults()" class="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                        Reset to Defaults
                    </button>
                    <button onclick="billingSettings.saveBillingSettings()" class="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90">
                        Save Settings
                    </button>
                </div>
            </div>
        `;
    }

    saveBillingSettings() {
        const settings = {
            taxRate: parseFloat(document.getElementById('billingTaxRate').value),
            currency: document.getElementById('billingCurrency').value,
            receiptTemplate: document.getElementById('billingReceiptTemplate').value,
            printReceipt: document.getElementById('billingPrintReceipt').checked
        };

        Object.keys(settings).forEach(key => {
            PharmacySettings.updateModuleSetting('billing', key, settings[key]);
        });

        Swal.close();
        Swal.fire('Success', 'Billing settings saved!', 'success');
    }

    resetToDefaults() {
        PharmacySettings.resetModuleToDefaults('billing');
        Swal.close();
        Swal.fire('Reset Complete', 'Billing settings restored to defaults.', 'success');
    }
}

// Initialize billing settings
const billingSettings = new BillingSettings();

function toggleSettings() {
    const dropdown = document.getElementById('settingsDropdown');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    updateSettingsDisplay();
}

function updateSettingsDisplay() {
    const commonSettings = PharmacySettings.getModuleSettings('common');
    
    // Update common toggles
    document.getElementById('darkModeToggle').checked = commonSettings.darkMode;
    document.getElementById('notificationsToggle').checked = commonSettings.desktopNotifications;
    document.getElementById('soundToggle').checked = commonSettings.soundEnabled;
    document.getElementById('autoRefreshToggle').checked = commonSettings.autoRefresh;
    
    // Update module-specific displays
    const currentPage = getCurrentPageModule();
    updateModuleSpecificDisplays(currentPage);
}

function getCurrentPageModule() {
    const path = window.location.pathname;
    if (path.includes('alerts')) return 'alerts';
    if (path.includes('billing')) return 'billing';
    if (path.includes('inventory')) return 'inventory';
    if (path.includes('dashboard')) return 'dashboard';
    return 'common';
}

function updateModuleSpecificDisplays(module) {
    const settings = PharmacySettings.getModuleSettings(module);
    
    switch(module) {
        case 'alerts':
            document.getElementById('currentThreshold').textContent = settings.lowStockThreshold + ' units';
            document.getElementById('currentExpiryDays').textContent = settings.expiryDays + ' days';
            break;
        case 'billing':
            document.getElementById('currentTaxRate').textContent = settings.taxRate + '%';
            document.getElementById('currentCurrency').textContent = settings.currency;
            break;
        case 'inventory':
            document.getElementById('currentThreshold').textContent = settings.lowStockThreshold + ' units';
            document.getElementById('currentItemsPerPage').textContent = settings.itemsPerPage;
            break;
    }
}

// Module-specific setting handlers
function showModuleSettings() {
    const module = getCurrentPageModule();
    switch(module) {
        case 'alerts':
            alertsSettings.showAlertsSettingsModal();
            break;
        case 'billing':
            billingSettings.showBillingSettingsModal();
            break;
        case 'inventory':
            inventorySettings.showInventorySettingsModal();
            break;
        default:
            showCommonSettingsModal();
    }
}
// Settings functionality
function toggleSettings() {
    const dropdown = document.getElementById('settingsDropdown');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    updateSettingsDisplay();
}

function updateSettingsDisplay() {
    document.getElementById('darkModeToggle').checked = PharmacySettings.current.darkMode;
    document.getElementById('notificationsToggle').checked = PharmacySettings.current.desktopNotifications;
    document.getElementById('soundToggle').checked = PharmacySettings.current.soundEnabled;
    document.getElementById('autoRefreshToggle').checked = PharmacySettings.current.autoRefresh;
    document.getElementById('currentItemsPerPage').textContent = PharmacySettings.current.itemsPerPage;
    document.getElementById('currentTaxRate').textContent = PharmacySettings.current.taxRate + '%';
    document.getElementById('currentCurrency').textContent = PharmacySettings.current.currency;
    document.getElementById('currentReceiptTemplate').textContent = PharmacySettings.current.receiptTemplate.charAt(0).toUpperCase() + PharmacySettings.current.receiptTemplate.slice(1);
    document.getElementById('currentTheme').textContent = PharmacySettings.current.theme === 'default' ? 'Default' : 'Premium';
}

// Close settings when clicking outside
document.addEventListener('click', function(event) {
    const settingsBtn = document.querySelector('button[onclick="toggleSettings()"]');
    const dropdown = document.getElementById('settingsDropdown');
    if (settingsBtn && !settingsBtn.contains(event.target) && dropdown && !dropdown.contains(event.target)) {
        dropdown.style.display = 'none';
    }
});

// Billing-specific settings functions
function showTaxSettings() {
    Swal.fire({
        title: 'Tax Rate Settings',
        html: `
            <div class="text-left">
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Set tax rate (%):
                </label>
                <input type="number" id="taxRateInput" value="${PharmacySettings.current.taxRate}" 
                       step="0.1" min="0" max="50" class="w-full p-2 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Save',
        cancelButtonText: 'Cancel',
        preConfirm: () => {
            const value = parseFloat(document.getElementById('taxRateInput').value);
            if (value < 0 || value > 50) {
                Swal.showValidationMessage('Please enter a value between 0 and 50');
            }
            return value;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            PharmacySettings.updateSetting('taxRate', result.value);
            updateSettingsDisplay();
            Swal.fire('Success', `Tax rate set to ${result.value}%`, 'success');
        }
    });
}

function showCurrencySettings() {
    Swal.fire({
        title: 'Currency Settings',
        html: `
            <div class="text-left">
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Select currency:
                </label>
                <select id="currencyInput" class="w-full p-2 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    <option value="PHP" ${PharmacySettings.current.currency === 'PHP' ? 'selected' : ''}>Philippine Peso (₱)</option>
                    <option value="USD" ${PharmacySettings.current.currency === 'USD' ? 'selected' : ''}>US Dollar ($)</option>
                    <option value="EUR" ${PharmacySettings.current.currency === 'EUR' ? 'selected' : ''}>Euro (€)</option>
                </select>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Save',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            const value = document.getElementById('currencyInput').value;
            PharmacySettings.updateSetting('currency', value);
            updateSettingsDisplay();
            Swal.fire('Success', `Currency set to ${value}`, 'success');
        }
    });
}

function showReceiptSettings() {
    Swal.fire({
        title: 'Receipt Template',
        html: `
            <div class="text-left">
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Select receipt template:
                </label>
                <select id="receiptTemplateInput" class="w-full p-2 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    <option value="standard" ${PharmacySettings.current.receiptTemplate === 'standard' ? 'selected' : ''}>Standard</option>
                    <option value="detailed" ${PharmacySettings.current.receiptTemplate === 'detailed' ? 'selected' : ''}>Detailed</option>
                    <option value="minimal" ${PharmacySettings.current.receiptTemplate === 'minimal' ? 'selected' : ''}>Minimal</option>
                </select>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Save',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            const value = document.getElementById('receiptTemplateInput').value;
            PharmacySettings.updateSetting('receiptTemplate', value);
            updateSettingsDisplay();
            Swal.fire('Success', `Receipt template set to ${value}`, 'success');
        }
    });
}

function showItemsPerPageSettings() {
    Swal.fire({
        title: 'Items Per Page',
        html: `
            <div class="text-left">
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Set number of items per page:
                </label>
                <select id="itemsPerPageInput" class="w-full p-2 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    <option value="10" ${PharmacySettings.current.itemsPerPage === 10 ? 'selected' : ''}>10 items</option>
                    <option value="25" ${PharmacySettings.current.itemsPerPage === 25 ? 'selected' : ''}>25 items</option>
                    <option value="50" ${PharmacySettings.current.itemsPerPage === 50 ? 'selected' : ''}>50 items</option>
                    <option value="100" ${PharmacySettings.current.itemsPerPage === 100 ? 'selected' : ''}>100 items</option>
                </select>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Save',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            const value = parseInt(document.getElementById('itemsPerPageInput').value);
            PharmacySettings.updateSetting('itemsPerPage', value);
            updateSettingsDisplay();
            Swal.fire('Success', `Items per page set to ${value}`, 'success');
        }
    });
}

function showThemeSettings() {
    Swal.fire({
        title: 'Theme Color',
        html: `
            <div class="text-left">
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Select theme:
                </label>
                <select id="themeInput" class="w-full p-2 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    <option value="default" ${PharmacySettings.current.theme === 'default' ? 'selected' : ''}>Default Teal</option>
                    <option value="premium" ${PharmacySettings.current.theme === 'premium' ? 'selected' : ''}>Premium Indigo</option>
                </select>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Save',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            const value = document.getElementById('themeInput').value;
            PharmacySettings.updateSetting('theme', value);
            updateSettingsDisplay();
            Swal.fire('Success', `Theme updated to ${value}`, 'success');
        }
    });
}

// Export/Import functions
function exportSettings() {
    PharmacySettings.exportSettings();
    Swal.fire('Success', 'Settings exported successfully!', 'success');
}

function importSettings() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
        PharmacySettings.importSettings(e.target.files[0]);
    };
    input.click();
}

// Initialize settings when page loads
document.addEventListener('DOMContentLoaded', function() {
    PharmacySettings.init();
    updateSettingsDisplay();
});