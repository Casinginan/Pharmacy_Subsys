// Patient Records JavaScript

// Global variables
let currentPatientId = null;

// Enhanced patient data with prescriptions and status
const patientData = {
    'PT001': { 
        age: 34, 
        lastVisit: '2024-01-15', 
        balance: '₱245.50',
        originalBalance: '₱245.50',
        prescriptions: 3,
        status: 'Paid'
    },
    'PT002': { 
        age: 58, 
        lastVisit: '2024-01-18', 
        balance: '₱189.75',
        originalBalance: '₱189.75',
        prescriptions: 5,
        status: 'Pending'
    },
    'PT003': { 
        age: 29, 
        lastVisit: '2024-01-20', 
        balance: '₱0.00',
        originalBalance: '₱0.00',
        prescriptions: 2,
        status: 'Paid'
    },
    'PT004': { 
        age: 67, 
        lastVisit: '2024-01-12', 
        balance: '₱485.25',
        originalBalance: '₱485.25',
        prescriptions: 7,
        status: 'Overdue'
    }
};

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initSearch();
    initFilter();
    initModalCloseListeners();
    initTableWithPaidStatus();
    updateStatsCards(); // Initialize stats cards
});

// Helper function to update individual stat cards
function updateStatCard(statId, value) {
    const element = document.querySelector(`[data-stat="${statId}"]`);
    if (element) {
        element.textContent = value;
    }
}

// Function to calculate and update all statistics - SIMPLIFIED AND FIXED
function updateStatsCards() {
    const table = document.getElementById('patientsTable');
    let totalPatients = 0;
    let activePrescriptions = 0;
    let pendingBills = 0;
    let outstandingAmount = 0;
    
    if (table) {
        const rows = table.querySelectorAll('tbody tr');
        totalPatients = rows.length;
        
        rows.forEach(row => {
            // Get prescriptions count
            const prescriptionsCell = row.cells[3];
            const prescriptions = parseInt(prescriptionsCell.textContent) || 0;
            activePrescriptions += prescriptions;
            
            // Get status from the badge in the table
            const statusCell = row.cells[4];
            const statusBadge = statusCell.querySelector('span');
            const status = statusBadge ? statusBadge.textContent.trim() : '';
            
            // Get patient ID to find balance
            const patientId = row.cells[0].textContent;
            const patient = patientData[patientId];
            
            if (patient) {
                // Only count as pending if status is NOT "Paid"
                if (status !== 'Paid') {
                    pendingBills++;
                    outstandingAmount += parseFloat(patient.originalBalance.replace('₱', ''));
                }
            }
        });
    }
    
    // Update the DOM elements
    updateStatCard('totalPatients', totalPatients);
    updateStatCard('activePrescriptions', activePrescriptions);
    updateStatCard('pendingBills', pendingBills);
    updateStatCard('outstandingAmount', `₱${outstandingAmount.toFixed(2)}`);
    
    console.log('Stats updated - Pending Bills:', pendingBills, 'Outstanding:', outstandingAmount);
}

// Open patient modal function - FIXED
function openPatientModal(patientName, patientId) {
    currentPatientId = patientId;
    
    const modal = document.getElementById('patientModal');
    const patient = getPatientData(patientId);
    
    if (modal && patient) {
        // Set modal content
        document.getElementById('modalPatientName').textContent = patientName;
        document.getElementById('modalPatientId').textContent = patientId;
        document.getElementById('modalPatientAge').textContent = patient.age;
        document.getElementById('modalLastVisit').textContent = patient.lastVisit;
        
        // Check current status from the table
        const table = document.getElementById('patientsTable');
        let currentStatus = patient.status;
        if (table) {
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const rowPatientId = row.cells[0].textContent;
                if (rowPatientId === patientId) {
                    const statusCell = row.cells[4];
                    const statusBadge = statusCell.querySelector('span');
                    currentStatus = statusBadge ? statusBadge.textContent.trim() : patient.status;
                }
            });
        }
        
        const outstandingBalance = document.getElementById('outstandingBalance');
        const markAsPaidBtn = document.getElementById('markAsPaidBtn');
        
        if (currentStatus === 'Paid') {
            outstandingBalance.textContent = '₱0.00';
            markAsPaidBtn.textContent = 'Paid';
            markAsPaidBtn.classList.remove('bg-primary', 'hover:bg-primary/90');
            markAsPaidBtn.classList.add('bg-green-500', 'hover:bg-green-600');
        } else {
            outstandingBalance.textContent = patient.balance;
            markAsPaidBtn.textContent = 'Mark as Paid';
            markAsPaidBtn.classList.remove('bg-green-500', 'hover:bg-green-600');
            markAsPaidBtn.classList.add('bg-primary', 'hover:bg-primary/90');
        }
        
        // Show modal
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
}

// Close modal function
function closeModal() {
    const modal = document.getElementById('patientModal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
        currentPatientId = null;
    }
}

// Initialize modal close listeners
function initModalCloseListeners() {
    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
    
    // Close modal when clicking outside (on the backdrop)
    const modal = document.getElementById('patientModal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
    }
    
    // Direct event listener for close button
    document.addEventListener('click', function(e) {
        if (e.target.closest('.material-icons') && e.target.textContent === 'close') {
            closeModal();
        }
    });
}

// Mark as paid function with confirmation - COMPLETELY FIXED
function markAsPaid() {
    if (!currentPatientId) return;
    
    const confirmed = confirm('Are you sure you want to mark this patient as paid? This action will set the outstanding balance to zero.');
    
    if (confirmed) {
        // Update the table status to "Paid"
        updateTableStatus(currentPatientId, 'Paid');
        
        // Update localStorage
        const paidStatus = JSON.parse(localStorage.getItem('patientPaidStatus') || '{}');
        paidStatus[currentPatientId] = true;
        localStorage.setItem('patientPaidStatus', JSON.stringify(paidStatus));
        
        // Update patient data
        if (patientData[currentPatientId]) {
            patientData[currentPatientId].status = 'Paid';
            patientData[currentPatientId].balance = '₱0.00';
        }
        
        // Close modal and update stats
        closeModal();
        updateStatsCards();
        
        // Show success notification
        showNotification('Payment recorded successfully! Patient marked as paid.', 'success');
    }
}

// Mark as unpaid function - COMPLETELY FIXED
function markAsUnpaid() {
    if (!currentPatientId) return;
    
    const confirmed = confirm('Are you sure you want to mark this patient as unpaid? This will restore the original outstanding balance.');
    
    if (confirmed) {
        // Get the original status (Pending for most, Overdue for David Wilson)
        const patient = getPatientData(currentPatientId);
        const originalStatus = currentPatientId === 'PT004' ? 'Overdue' : 'Pending';
        
        // Update the table status
        updateTableStatus(currentPatientId, originalStatus);
        
        // Update localStorage
        const paidStatus = JSON.parse(localStorage.getItem('patientPaidStatus') || '{}');
        paidStatus[currentPatientId] = false;
        localStorage.setItem('patientPaidStatus', JSON.stringify(paidStatus));
        
        // Update patient data
        if (patientData[currentPatientId]) {
            patientData[currentPatientId].status = originalStatus;
            patientData[currentPatientId].balance = patient.originalBalance;
        }
        
        // Close modal and update stats
        closeModal();
        updateStatsCards();
        
        // Show success notification
        showNotification('Patient status updated to unpaid.', 'success');
    }
}

// Update patient balance in data
function updatePatientBalance(patientId, newBalance, isPaid) {
    // Store in localStorage to persist the state
    const paidStatus = JSON.parse(localStorage.getItem('patientPaidStatus') || '{}');
    paidStatus[patientId] = isPaid;
    localStorage.setItem('patientPaidStatus', JSON.stringify(paidStatus));
    
    // Update patient data
    if (patientData[patientId]) {
        patientData[patientId].status = isPaid ? 'Paid' : 'Pending';
    }
}

// Update table status with paid status check - FIXED
function updateTableStatus(patientId, newStatus) {
    const table = document.getElementById('patientsTable');
    if (table) {
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const rowPatientId = row.cells[0].textContent;
            if (rowPatientId === patientId) {
                const statusCell = row.cells[4];
                const statusBadge = statusCell.querySelector('span');
                
                if (statusBadge) {
                    // Update badge based on new status
                    statusBadge.textContent = newStatus;
                    statusBadge.className = ''; // Clear existing classes
                    
                    if (newStatus === 'Paid') {
                        statusBadge.classList.add('bg-green-100', 'text-green-800', 'text-xs', 'font-medium', 'px-2.5', 'py-0.5', 'rounded-full', 'dark:bg-green-900', 'dark:text-green-300');
                    } else if (newStatus === 'Pending') {
                        statusBadge.classList.add('bg-yellow-100', 'text-yellow-800', 'text-xs', 'font-medium', 'px-2.5', 'py-0.5', 'rounded-full', 'dark:bg-yellow-900', 'dark:text-yellow-300');
                    } else if (newStatus === 'Overdue') {
                        statusBadge.classList.add('bg-red-100', 'text-red-800', 'text-xs', 'font-medium', 'px-2.5', 'py-0.5', 'rounded-full', 'dark:bg-red-900', 'dark:text-red-300');
                    }
                    
                    console.log(`Updated ${patientId} to ${newStatus}`);
                }
            }
        });
    }
}

// Initialize table with paid status on page load - FIXED
function initTableWithPaidStatus() {
    const paidStatus = JSON.parse(localStorage.getItem('patientPaidStatus') || '{}');
    const table = document.getElementById('patientsTable');
    
    if (table) {
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            const patientId = row.cells[0].textContent;
            const statusCell = row.cells[4];
            const statusBadge = statusCell.querySelector('span');
            
            // If patient is marked as paid in localStorage, update their status
            if (paidStatus[patientId]) {
                if (statusBadge) {
                    statusBadge.textContent = 'Paid';
                    statusBadge.className = '';
                    statusBadge.classList.add('bg-green-100', 'text-green-800', 'text-xs', 'font-medium', 'px-2.5', 'py-0.5', 'rounded-full', 'dark:bg-green-900', 'dark:text-green-300');
                }
            }
        });
    }
    
    // Update stats after initializing table
    updateStatsCards();
}

// Enhanced mock patient data with original balances
function getPatientData(patientId) {
    return patientData[patientId] || { age: 'Unknown', lastVisit: 'Unknown', balance: '₱0.00', originalBalance: '₱0.00', prescriptions: 0, status: 'Unknown' };
}

// Search functionality
function initSearch() {
    const searchInput = document.getElementById('tableSearch');
    
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase().trim();
            const table = document.getElementById('patientsTable');
            
            if (table) {
                const rows = table.querySelectorAll('tbody tr');
                let hasVisibleRows = false;
                
                rows.forEach(row => {
                    const patientId = row.cells[0].textContent.toLowerCase();
                    const patientName = row.cells[1].textContent.toLowerCase();
                    const status = row.cells[4].textContent.toLowerCase();
                    
                    const matchesSearch = patientId.includes(searchTerm) || 
                                        patientName.includes(searchTerm) ||
                                        status.includes(searchTerm);
                    
                    if (matchesSearch) {
                        row.style.display = '';
                        hasVisibleRows = true;
                    } else {
                        row.style.display = 'none';
                    }
                });
                
                // Show/hide no results message
                showNoResultsMessage(!hasVisibleRows && searchTerm !== '');
            }
        });
    }
}

// Filter functionality
function initFilter() {
    const statusFilter = document.getElementById('statusFilter');
    
    if (statusFilter) {
        statusFilter.addEventListener('change', function() {
            const selectedStatus = this.value;
            const table = document.getElementById('patientsTable');
            
            if (table) {
                const rows = table.querySelectorAll('tbody tr');
                let hasVisibleRows = false;
                
                rows.forEach(row => {
                    const statusCell = row.cells[4];
                    const statusBadge = statusCell.querySelector('span');
                    const rowStatus = statusBadge ? statusBadge.textContent.trim() : '';
                    
                    if (selectedStatus === '' || rowStatus === selectedStatus) {
                        row.style.display = '';
                        hasVisibleRows = true;
                    } else {
                        row.style.display = 'none';
                    }
                });
                
                // Show/hide no results message
                showNoResultsMessage(!hasVisibleRows && selectedStatus !== '');
            }
        });
    }
}

// Show/hide no results message
function showNoResultsMessage(show) {
    let noResultsRow = document.getElementById('noResultsRow');
    
    if (show && !noResultsRow) {
        const table = document.getElementById('patientsTable');
        if (table) {
            const tbody = table.querySelector('tbody');
            noResultsRow = document.createElement('tr');
            noResultsRow.id = 'noResultsRow';
            noResultsRow.innerHTML = `
                <td colspan="7" class="px-6 py-8 text-center text-subtext-light dark:text-subtext-dark">
                    <span class="material-icons text-4xl mb-2 text-gray-400">search_off</span>
                    <p class="font-medium">No patients found</p>
                    <p class="text-sm mt-1">Try adjusting your search or filter criteria</p>
                </td>
            `;
            tbody.appendChild(noResultsRow);
        }
    } else if (!show && noResultsRow) {
        noResultsRow.remove();
    }
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transform transition-all duration-300 ${
        type === 'success' ? 'bg-green-500 text-white' :
        type === 'error' ? 'bg-red-500 text-white' :
        'bg-blue-500 text-white'
    }`;
    notification.innerHTML = `
        <div class="flex items-center gap-2">
            <span class="material-icons text-sm">${type === 'success' ? 'check_circle' : type === 'error' ? 'error' : 'info'}</span>
            <span class="text-sm">${message}</span>
        </div>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Reset all patients to unpaid - DEBUG FUNCTION
function resetAllPatients() {
    if (confirm('Reset ALL patients to unpaid status?')) {
        localStorage.removeItem('patientPaidStatus');
        location.reload();
    }
}

// Debug function to check current statuses
function debugStatuses() {
    const table = document.getElementById('patientsTable');
    console.log('=== CURRENT PATIENT STATUSES ===');
    if (table) {
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            const patientId = row.cells[0].textContent;
            const name = row.cells[1].textContent;
            const status = row.cells[4].querySelector('span').textContent;
            console.log(`${patientId} - ${name}: ${status}`);
        });
    }
    console.log('================================');
}

// Export functions for potential use in other modules
window.PatientRecords = {
    openPatientModal,
    closeModal,
    markAsPaid,
    initSearch,
    initFilter,
    showNotification,
    updateStatsCards,
    debugStatuses,
    resetAllPatients
};
// Notification System
class NotificationManager {
    constructor() {
        this.notifications = JSON.parse(localStorage.getItem('pharmacyNotifications')) || [];
        this.unreadCount = this.notifications.filter(n => !n.read).length;
        this.init();
    }

    init() {
        this.updateBadge();
        this.renderNotifications();
        this.setupEventListeners();
        
        // Check for new notifications periodically
        setInterval(() => this.checkForNewNotifications(), 30000); // Every 30 seconds
    }

    setupEventListeners() {
        // Toggle notification dropdown
        document.getElementById('notificationBtn').addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleDropdown();
        });

        // Mark all as read
        document.getElementById('markAllAsRead').addEventListener('click', (e) => {
            e.stopPropagation();
            this.markAllAsRead();
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', () => {
            this.closeDropdown();
        });

        // View all notifications
        document.getElementById('viewAllNotifications').addEventListener('click', (e) => {
            e.stopPropagation();
            this.viewAllNotifications();
        });

        // Notification settings
        document.getElementById('notificationSettings').addEventListener('click', (e) => {
            e.stopPropagation();
            this.openNotificationSettings();
        });
    }

    toggleDropdown() {
        const dropdown = document.getElementById('notificationDropdown');
        if (dropdown.classList.contains('hidden')) {
            dropdown.classList.remove('hidden');
            // Mark notifications as read when dropdown is opened
            this.markAllAsRead();
        } else {
            dropdown.classList.add('hidden');
        }
    }

    closeDropdown() {
        document.getElementById('notificationDropdown').classList.add('hidden');
    }

    updateBadge() {
        const badge = document.getElementById('notificationBadge');
        if (this.unreadCount > 0) {
            badge.textContent = this.unreadCount > 99 ? '99+' : this.unreadCount;
            badge.classList.remove('hidden');
            
            // Add pulse animation for new notifications
            if (this.unreadCount > 0) {
                badge.classList.add('animate-pulse');
            }
        } else {
            badge.classList.add('hidden');
            badge.classList.remove('animate-pulse');
        }
    }

    renderNotifications() {
        const container = document.getElementById('notificationList');
        const recentNotifications = this.notifications.slice(0, 10); // Show last 10
        
        if (recentNotifications.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-subtext-light dark:text-subtext-dark">
                    <span class="material-icons text-4xl mb-2">notifications_none</span>
                    <p>No new notifications</p>
                </div>
            `;
            return;
        }

        container.innerHTML = recentNotifications.map(notification => `
            <div class="notification-item ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
                <div class="notification-content">
                    <div class="notification-icon ${notification.type}">
                        <span class="material-icons text-sm">${this.getNotificationIcon(notification.type)}</span>
                    </div>
                    <div class="notification-details">
                        <div class="notification-title">${notification.title}</div>
                        <div class="notification-message">${notification.message}</div>
                        <div class="notification-time">${this.formatTime(notification.timestamp)}</div>
                        ${notification.actions ? `
                            <div class="notification-actions">
                                ${notification.actions.map(action => `
                                    <button class="notification-action" onclick="notificationManager.handleAction('${notification.id}', '${action.type}')">
                                        ${action.label}
                                    </button>
                                `).join('')}
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `).join('');
    }

    getNotificationIcon(type) {
        const icons = {
            info: 'info',
            warning: 'warning',
            error: 'error',
            success: 'check_circle'
        };
        return icons[type] || 'notifications';
    }

    formatTime(timestamp) {
        const now = new Date();
        const notificationTime = new Date(timestamp);
        const diffInMinutes = Math.floor((now - notificationTime) / (1000 * 60));
        
        if (diffInMinutes < 1) return 'Just now';
        if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
        if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
        return notificationTime.toLocaleDateString();
    }

    addNotification(notification) {
        const newNotification = {
            id: Date.now().toString(),
            type: notification.type || 'info',
            title: notification.title,
            message: notification.message,
            timestamp: new Date().toISOString(),
            read: false,
            actions: notification.actions || null,
            data: notification.data || null
        };

        this.notifications.unshift(newNotification);
        this.notifications = this.notifications.slice(0, 100); // Keep only last 100 notifications
        
        this.unreadCount++;
        this.saveToStorage();
        this.updateBadge();
        this.renderNotifications();
        
        // Show desktop notification if enabled
        if (this.shouldShowDesktopNotification()) {
            this.showDesktopNotification(newNotification);
        }

        return newNotification.id;
    }

    markAsRead(notificationId) {
        const notification = this.notifications.find(n => n.id === notificationId);
        if (notification && !notification.read) {
            notification.read = true;
            this.unreadCount--;
            this.saveToStorage();
            this.updateBadge();
            this.renderNotifications();
        }
    }

    markAllAsRead() {
        this.notifications.forEach(notification => {
            if (!notification.read) {
                notification.read = true;
            }
        });
        this.unreadCount = 0;
        this.saveToStorage();
        this.updateBadge();
        this.renderNotifications();
    }

    removeNotification(notificationId) {
        const notificationIndex = this.notifications.findIndex(n => n.id === notificationId);
        if (notificationIndex !== -1) {
            if (!this.notifications[notificationIndex].read) {
                this.unreadCount--;
            }
            this.notifications.splice(notificationIndex, 1);
            this.saveToStorage();
            this.updateBadge();
            this.renderNotifications();
        }
    }

    clearAllNotifications() {
        this.notifications = [];
        this.unreadCount = 0;
        this.saveToStorage();
        this.updateBadge();
        this.renderNotifications();
    }

    handleAction(notificationId, actionType) {
        const notification = this.notifications.find(n => n.id === notificationId);
        if (!notification) return;

        switch (actionType) {
            case 'view_patient':
                if (notification.data && notification.data.patientId) {
                    this.closeDropdown();
                    openPatientModal(notification.data.patientName, notification.data.patientId);
                }
                break;
            case 'view_prescription':
                if (notification.data && notification.data.prescriptionId) {
                    this.closeDropdown();
                    // Navigate to prescriptions page
                    window.location.href = 'prescription.html';
                }
                break;
            case 'dismiss':
                this.removeNotification(notificationId);
                break;
            default:
                console.log('Unknown action:', actionType);
        }
    }

    viewAllNotifications() {
        this.closeDropdown();
        // In a real application, you would navigate to a dedicated notifications page
        Swal.fire({
            title: 'All Notifications',
            html: `
                <div class="max-h-96 overflow-y-auto">
                    ${this.notifications.map(notification => `
                        <div class="p-3 border-b border-gray-200 dark:border-gray-700">
                            <div class="flex justify-between items-start">
                                <div>
                                    <div class="font-medium">${notification.title}</div>
                                    <div class="text-sm text-gray-600 dark:text-gray-400">${notification.message}</div>
                                    <div class="text-xs text-gray-500 mt-1">${this.formatTime(notification.timestamp)}</div>
                                </div>
                                <button onclick="notificationManager.removeNotification('${notification.id}')" class="text-gray-400 hover:text-gray-600">
                                    <span class="material-icons text-sm">close</span>
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `,
            showConfirmButton: false,
            showCloseButton: true,
            width: 600
        });
    }

    openNotificationSettings() {
        Swal.fire({
            title: 'Notification Settings',
            html: `
                <div class="text-left space-y-4">
                    <div class="settings-item">
                        <span class="settings-label">Desktop Notifications</span>
                        <label class="toggle-switch">
                            <input type="checkbox" id="desktopNotificationsToggle" ${this.shouldShowDesktopNotification() ? 'checked' : ''}>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    <div class="settings-item">
                        <span class="settings-label">Sound Alerts</span>
                        <label class="toggle-switch">
                            <input type="checkbox" id="soundAlertsToggle" checked>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    <div class="settings-item">
                        <span class="settings-label">Email Notifications</span>
                        <label class="toggle-switch">
                            <input type="checkbox" id="emailNotificationsToggle">
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    <div>
                        <button onclick="notificationManager.clearAllNotifications()" class="w-full bg-red-100 text-red-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-200 transition-colors">
                            Clear All Notifications
                        </button>
                    </div>
                </div>
            `,
            showConfirmButton: false,
            showCloseButton: true
        });

        // Add event listeners for toggles
        setTimeout(() => {
            document.getElementById('desktopNotificationsToggle').addEventListener('change', (e) => {
                this.toggleDesktopNotifications(e.target.checked);
            });
        }, 100);
    }

    toggleDesktopNotifications(enabled) {
        if (enabled) {
            // Request permission for desktop notifications
            if ('Notification' in window && Notification.permission === 'default') {
                Notification.requestPermission();
            }
        }
        localStorage.setItem('desktopNotifications', enabled.toString());
    }

    shouldShowDesktopNotification() {
        return localStorage.getItem('desktopNotifications') !== 'false' && 
               'Notification' in window && 
               Notification.permission === 'granted';
    }

    showDesktopNotification(notification) {
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(notification.title, {
                body: notification.message,
                icon: '/favicon.ico', // Replace with your app icon
                tag: 'pharmacy-notification'
            });
        }
    }

    checkForNewNotifications() {
        // Simulate checking for new notifications from server
        // In a real application, this would be an API call
        const shouldAddNotification = Math.random() < 0.1; // 10% chance
        
        if (shouldAddNotification) {
            const sampleNotifications = [
                {
                    type: 'warning',
                    title: 'Low Stock Alert',
                    message: 'Amoxicillin 500mg is running low (only 15 units left)',
                    actions: [
                        { type: 'view_inventory', label: 'View Inventory' }
                    ]
                },
                {
                    type: 'info',
                    title: 'New Prescription',
                    message: 'Dr. Smith prescribed Lisinopril 10mg for Sarah Johnson',
                    actions: [
                        { type: 'view_prescription', label: 'View Prescription' },
                        { type: 'view_patient', label: 'View Patient' }
                    ],
                    data: {
                        patientId: 'PT001',
                        patientName: 'Sarah Johnson',
                        prescriptionId: 'RX2024011501'
                    }
                },
                {
                    type: 'success',
                    title: 'Payment Received',
                    message: 'Payment of ₱245.50 received from Michael Chen',
                    actions: [
                        { type: 'view_patient', label: 'View Patient' }
                    ],
                    data: {
                        patientId: 'PT002',
                        patientName: 'Michael Chen'
                    }
                }
            ];
            
            const randomNotification = sampleNotifications[Math.floor(Math.random() * sampleNotifications.length)];
            this.addNotification(randomNotification);
        }
    }

    saveToStorage() {
        localStorage.setItem('pharmacyNotifications', JSON.stringify(this.notifications));
    }
}

// Initialize notification manager
const notificationManager = new NotificationManager();

// Example usage - add these functions to trigger notifications
function triggerLowStockNotification(medicationName, remainingStock) {
    notificationManager.addNotification({
        type: 'warning',
        title: 'Low Stock Alert',
        message: `${medicationName} is running low (only ${remainingStock} units left)`,
        actions: [
            { type: 'view_inventory', label: 'View Inventory' }
        ]
    });
}

function triggerNewPrescriptionNotification(patientName, medication, doctorName) {
    notificationManager.addNotification({
        type: 'info',
        title: 'New Prescription',
        message: `Dr. ${doctorName} prescribed ${medication} for ${patientName}`,
        actions: [
            { type: 'view_prescription', label: 'View Prescription' },
            { type: 'view_patient', label: 'View Patient' }
        ]
    });
}

function triggerPaymentNotification(patientName, amount) {
    notificationManager.addNotification({
        type: 'success',
        title: 'Payment Received',
        message: `Payment of ${amount} received from ${patientName}`,
        actions: [
            { type: 'view_patient', label: 'View Patient' }
        ]
    });
}

// Initialize with some sample notifications on page load
document.addEventListener('DOMContentLoaded', function() {
    // Add sample notifications if none exist
    if (notificationManager.notifications.length === 0) {
        setTimeout(() => {
            triggerNewPrescriptionNotification('Sarah Johnson', 'Lisinopril 10mg', 'Smith');
            triggerLowStockNotification('Amoxicillin 500mg', 15);
        }, 2000);
    }
});