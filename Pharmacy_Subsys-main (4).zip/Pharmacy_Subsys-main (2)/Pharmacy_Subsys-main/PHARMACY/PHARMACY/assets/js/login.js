tailwind.config = {
    darkMode: "class",
    theme: {
        extend: {
            colors: {
                primary: "#358E83", // Updated primary color
                "background-light": "#F0FDF4",
                "background-dark": "#18181B",
                "surface-light": "#FFFFFF",
                "surface-dark": "#27272A",
                "text-light": "#333333",
                "text-dark": "#E4E4E7",
                "muted-light": "#6B7280",
                "muted-dark": "#A1A1AA",
                "border-light": "#E5E7EB",
                "border-dark": "#3F3F46"
            },
            fontFamily: {
                display: ["Poppins", "sans-serif"],
            },
            borderRadius: {
                DEFAULT: "0.5rem",
            },
        },
    },
};

// In login.js or your login page script
document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorMsg = document.getElementById("errorMsg");

  try {
    const response = await fetch("http://localhost:5000/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();

    if (!response.ok) {
      errorMsg.style.display = "block";
      errorMsg.textContent = data.message || "Invalid email or password.";
      return;
    }

    // ✅ Save token and user info
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify(data.user));

    // ✅ Redirect based on role
    if (data.user.role === "admin") {
      window.location.href = "/Admin/html/dashboard_admin.html";
    } else if (data.user.role === "pharmacist") {
      window.location.href = "pharmacist_dashboard.html";
    } else {
      window.location.href = "index.html";
    }
  } catch (err) {
    errorMsg.style.display = "block";
    errorMsg.textContent = "Server error. Please try again later.";
  }
});
