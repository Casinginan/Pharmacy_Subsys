// pharmacy-settings.js - Centralized Settings Manager
class PharmacySettingsManager {
    constructor() {
        this.defaultSettings = {
            // Appearance
            darkMode: false,
            theme: 'default',
            
            // Notifications
            desktopNotifications: true,
            soundEnabled: true,
            
            // System Behavior
            autoRefresh: true,
            itemsPerPage: 25,
            
            // Pharmacy Settings
            lowStockThreshold: 5,
            expiryDays: 30,
            
            // User Preferences
            language: 'en',
            dateFormat: 'MM/DD/YYYY',
            timeFormat: '12h'
        };
        
        this.current = { ...this.defaultSettings };
        this.init();
    }

    init() {
        this.loadSettings();
        this.applySettings();
        this.setupEventListeners();
    }

    loadSettings() {
        try {
            const saved = localStorage.getItem('pharmacyGlobalSettings');
            if (saved) {
                const parsed = JSON.parse(saved);
                this.current = { ...this.defaultSettings, ...parsed };
            }
        } catch (error) {
            console.error('Error loading settings:', error);
            this.current = { ...this.defaultSettings };
        }
    }

    saveSettings() {
        try {
            localStorage.setItem('pharmacyGlobalSettings', JSON.stringify(this.current));
            this.applySettings();
            this.dispatchSettingsChange();
            return true;
        } catch (error) {
            console.error('Error saving settings:', error);
            return false;
        }
    }

    applySettings() {
        // Apply dark mode
        if (this.current.darkMode) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }

        // Apply theme
        this.applyTheme();

        // Apply auto-refresh if the function exists
        if (typeof window.updateAutoRefresh === 'function') {
            window.updateAutoRefresh(this.current.autoRefresh);
        }

        // Update any settings displays
        if (typeof window.updateSettingsDisplay === 'function') {
            window.updateSettingsDisplay();
        }
    }

    applyTheme() {
        const root = document.documentElement;
        if (this.current.theme === 'premium') {
            root.style.setProperty('--primary-color', '#4f46e5');
            root.style.setProperty('--primary-light', '#eef2ff');
            root.style.setProperty('--primary-dark', '#3730a3');
        } else {
            root.style.setProperty('--primary-color', '#007A7A');
            root.style.setProperty('--primary-light', '#F0F7F7');
            root.style.setProperty('--primary-dark', '#0A1919');
        }
    }

    updateSetting(key, value) {
        if (key in this.current) {
            this.current[key] = value;
            if (this.saveSettings()) {
                return true;
            }
        }
        return false;
    }

    updateMultipleSettings(settings) {
        Object.keys(settings).forEach(key => {
            if (key in this.current) {
                this.current[key] = settings[key];
            }
        });
        return this.saveSettings();
    }

    dispatchSettingsChange() {
        window.dispatchEvent(new CustomEvent('pharmacySettingsChanged', {
            detail: { settings: this.current }
        }));
    }

    setupEventListeners() {
        window.addEventListener('pharmacySettingsChanged', (event) => {
            this.current = event.detail.settings;
            this.applySettings();
        });
    }

    exportSettings() {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(this.current, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", `pharmacy_settings_${new Date().toISOString().split('T')[0]}.json`);
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        document.body.removeChild(downloadAnchorNode);
    }

    async importSettings(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const imported = JSON.parse(e.target.result);
                    // Validate imported settings
                    const validSettings = {};
                    Object.keys(this.defaultSettings).forEach(key => {
                        if (key in imported) {
                            validSettings[key] = imported[key];
                        }
                    });
                    
                    if (this.updateMultipleSettings(validSettings)) {
                        resolve(true);
                    } else {
                        reject(new Error('Failed to save imported settings'));
                    }
                } catch (error) {
                    reject(new Error('Invalid settings file'));
                }
            };
            reader.onerror = () => reject(new Error('Error reading file'));
            reader.readAsText(file);
        });
    }

    resetToDefaults() {
        this.current = { ...this.defaultSettings };
        if (this.saveSettings()) {
            return true;
        }
        return false;
    }

    showNotification(message, type = 'info') {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                title: message,
                icon: type,
                timer: 2000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }

    getSetting(key) {
        return this.current[key];
    }

    getAllSettings() {
        return { ...this.current };
    }
}

// Global instance
window.PharmacySettings = new PharmacySettingsManager();

// Auto-initialize when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.PharmacySettings.init();
    });
} else {
    window.PharmacySettings.init();
}