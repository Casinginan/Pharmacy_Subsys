// Tailwind configuration
tailwind.config = {
    darkMode: "class",
    theme: {
        extend: {
            colors: {
                primary: "#007A7A",
                "background-light": "#F0F7F7",
                "background-dark": "#0A1919",
                "surface-light": "#FFFFFF",
                "surface-dark": "#112222",
                "text-light": "#0D1A1A",
                "text-dark": "#E0F2F2",
                "subtext-light": "#4D6969",
                "subtext-dark": "#80B3B3",
            },
            fontFamily: { sans: ['Inter', 'sans-serif'] },
            borderRadius: { 'lg': '0.75rem','xl': '1rem','2xl': '1.5rem' },
        },
    },
};

// Initialize inventory data
let inventory = [
    {id: 1, name: 'Paracetamol 500mg', batch: 'PAR2024001', quantity: 150, expiry: '2025-06-15', price: 12.50},
    {id: 2, name: 'Amoxicillin 250mg', batch: 'AMOX2024002', quantity: 8, expiry: '2024-12-20', price: 25.00},
    {id: 3, name: 'Ibuprofen 400mg', batch: 'IBU2024003', quantity: 0, expiry: '2025-02-10', price: 8.75},
    {id: 4, name: 'Aspirin 100mg', batch: 'ASP2024004', quantity: 50, expiry: '2024-11-30', price: 5.20},
    {id: 5, name: 'Metformin 500mg', batch: 'MET2024005', quantity: 200, expiry: '2025-08-20', price: 15.00},
    {id: 6, name: 'Omeprazole 20mg', batch: 'OME2024006', quantity: 75, expiry: '2025-03-10', price: 18.50}
];

let editingId = null;
let currentSortColumn = null;
let sortDirection = 'asc';

// Dark mode toggle
function toggleDarkMode() {
    document.documentElement.classList.toggle('dark');
    showNotification('Theme changed successfully', 'success');
}

// Initialize the page
function init() {
    renderTable();
    updateAlerts();
    updateStats();
}

// Render inventory table
function renderTable(data = inventory) {
    const tbody = document.getElementById('inventoryTableBody');
    tbody.innerHTML = '';
    
    data.forEach(item => {
        const status = getStatus(item.quantity);
        const statusClass = getStatusClass(status);
        const expiryClass = isExpiringSoon(item.expiry) ? 'text-red-600 dark:text-red-400 font-semibold' : '';
        
        const row = `
            <tr class="bg-surface-light dark:bg-surface-dark border-b border-primary/20 dark:border-primary/30 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <th class="px-6 py-4 font-medium text-text-light dark:text-white whitespace-nowrap">${item.name}</th>
                <td class="px-6 py-4">${item.batch}</td>
                <td class="px-6 py-4 ${item.quantity <= 10 ? 'text-yellow-600 dark:text-yellow-400 font-semibold' : ''}">${item.quantity}</td>
                <td class="px-6 py-4 ${expiryClass}">${item.expiry}</td>
                <td class="px-6 py-4">₱${item.price.toFixed(2)}</td>
                <td class="px-6 py-4">
                    <span class="${statusClass}">${status}</span>
                </td>
                <td class="px-6 py-4 flex items-center gap-3">
                    <button onclick="editMedicine(${item.id})" class="text-gray-500 hover:text-primary dark:text-gray-400 dark:hover:text-primary">
                        <span class="material-icons">edit</span>
                    </button>
                    <button onclick="deleteMedicine(${item.id})" class="text-gray-500 hover:text-red-500 dark:text-gray-400 dark:hover:text-red-500">
                        <span class="material-icons">delete</span>
                    </button>
                </td>
            </tr>
        `;
        tbody.innerHTML += row;
    });
}

// Get status based on quantity
function getStatus(quantity) {
    if (quantity === 0) return 'Out of Stock';
    if (quantity <= 10) return 'Low Stock';
    return 'In Stock';
}

// Get status class for styling
function getStatusClass(status) {
    switch(status) {
        case 'In Stock': return 'bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-green-900 dark:text-green-300';
        case 'Low Stock': return 'bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-yellow-900 dark:text-yellow-300';
        case 'Out of Stock': return 'bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-red-900 dark:text-red-300';
    }
}

// Check if expiring soon (within 30 days)
function isExpiringSoon(expiryDate) {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 30 && diffDays >= 0;
}

// Update alerts
function updateAlerts() {
    // Low stock alerts
    const lowStockList = document.getElementById('lowStockList');
    const lowStock = inventory.filter(item => item.quantity <= 10);
    lowStockList.innerHTML = lowStock.length ? 
        lowStock.map(item => `<li>${item.name} - Batch: ${item.batch} (${item.quantity} units)</li>`).join('') :
        '<li>No low stock items</li>';

    // Expiry alerts
    const expiryList = document.getElementById('expiryList');
    const expiring = inventory.filter(item => isExpiringSoon(item.expiry));
    expiryList.innerHTML = expiring.length ?
        expiring.map(item => `<li>${item.name} - Batch: ${item.batch} (Expires: ${item.expiry})</li>`).join('') :
        '<li>No items expiring soon</li>';
}

// Update statistics
function updateStats() {
    const totalItems = inventory.reduce((sum, item) => sum + item.quantity, 0);
    const totalValue = inventory.reduce((sum, item) => sum + (item.quantity * item.price), 0);
    const lowStockCount = inventory.filter(item => item.quantity <= 10 && item.quantity > 0).length;
    const expiringCount = inventory.filter(item => isExpiringSoon(item.expiry)).length;

    document.getElementById('totalItems').textContent = totalItems;
    document.getElementById('totalValue').textContent = '₱' + totalValue.toFixed(2);
    document.getElementById('lowStockCount').textContent = lowStockCount;
    document.getElementById('expiringCount').textContent = expiringCount;
}

// Open modal for adding medicine
function openAddModal() {
    editingId = null;
    document.getElementById('modalTitle').textContent = 'Add New Medicine';
    document.getElementById('medicineForm').reset();
    document.getElementById('medicineModal').classList.remove('hidden');
}

// Edit medicine
function editMedicine(id) {
    const medicine = inventory.find(item => item.id === id);
    if (medicine) {
        editingId = id;
        document.getElementById('modalTitle').textContent = 'Edit Medicine';
        document.getElementById('medicineName').value = medicine.name;
        document.getElementById('batchNumber').value = medicine.batch;
        document.getElementById('quantity').value = medicine.quantity;
        document.getElementById('price').value = medicine.price;
        document.getElementById('expiryDate').value = medicine.expiry;
        document.getElementById('medicineModal').classList.remove('hidden');
    }
}

// Close modal
function closeModal() {
    document.getElementById('medicineModal').classList.add('hidden');
    document.getElementById('medicineForm').reset();
    editingId = null;
}

// Save medicine (add or update)
function saveMedicine(event) {
    event.preventDefault();
    
    const medicineData = {
        name: document.getElementById('medicineName').value,
        batch: document.getElementById('batchNumber').value,
        quantity: parseInt(document.getElementById('quantity').value),
        price: parseFloat(document.getElementById('price').value),
        expiry: document.getElementById('expiryDate').value
    };

    if (editingId) {
        // Update existing medicine
        const index = inventory.findIndex(item => item.id === editingId);
        inventory[index] = { ...inventory[index], ...medicineData };
        showNotification('Medicine updated successfully', 'success');
    } else {
        // Add new medicine
        const newId = Math.max(...inventory.map(item => item.id), 0) + 1;
        inventory.push({ id: newId, ...medicineData });
        showNotification('Medicine added successfully', 'success');
    }

    closeModal();
    renderTable();
    updateAlerts();
    updateStats();
}

// Delete medicine
function deleteMedicine(id) {
    if (confirm('Are you sure you want to delete this medicine?')) {
        inventory = inventory.filter(item => item.id !== id);
        renderTable();
        updateAlerts();
        updateStats();
        showNotification('Medicine deleted successfully', 'error');
    }
}

// Search table
function searchTable() {
    const searchTerm = document.getElementById('tableSearch').value.toLowerCase();
    const filtered = inventory.filter(item => 
        item.name.toLowerCase().includes(searchTerm) ||
        item.batch.toLowerCase().includes(searchTerm)
    );
    renderTable(filtered);
}

// Quick search (global)
function quickSearch(value) {
    const searchTerm = value.toLowerCase();
    if (searchTerm) {
        const filtered = inventory.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.batch.toLowerCase().includes(searchTerm)
        );
        renderTable(filtered);
    } else {
        renderTable();
    }
}

// Filter by status
function filterByStatus() {
    const status = document.getElementById('statusFilter').value;
    if (status === '') {
        renderTable();
    } else {
        const filtered = inventory.filter(item => getStatus(item.quantity) === status);
        renderTable(filtered);
    }
}

// Sort table
function sortTable(column) {
    if (currentSortColumn === column) {
        sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        currentSortColumn = column;
        sortDirection = 'asc';
    }

    const sorted = [...inventory].sort((a, b) => {
        let aVal, bVal;
        switch(column) {
            case 'name': aVal = a.name; bVal = b.name; break;
            case 'quantity': aVal = a.quantity; bVal = b.quantity; break;
            case 'price': aVal = a.price; bVal = b.price; break;
            case 'expiry': aVal = new Date(a.expiry); bVal = new Date(b.expiry); break;
        }

        if (typeof aVal === 'string') {
            return sortDirection === 'asc' ? 
                aVal.localeCompare(bVal) : 
                bVal.localeCompare(aVal);
        } else {
            return sortDirection === 'asc' ? 
                aVal - bVal : 
                bVal - aVal;
        }
    });

    renderTable(sorted);
}

// Export data
function exportData() {
    const csvContent = [
        ['Medicine Name', 'Batch Number', 'Quantity', 'Expiry Date', 'Price', 'Status'],
        ...inventory.map(item => [
            item.name,
            item.batch,
            item.quantity,
            item.expiry,
            `₱${item.price.toFixed(2)}`,
            getStatus(item.quantity)
        ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `inventory_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    showNotification('Data exported successfully', 'success');
}

// Show notifications panel
function showNotifications() {
    const notifications = [
        { type: 'warning', message: `${inventory.filter(i => i.quantity <= 10 && i.quantity > 0).length} items are low in stock` },
        { type: 'error', message: `${inventory.filter(i => i.quantity === 0).length} items are out of stock` },
        { type: 'info', message: `${inventory.filter(i => isExpiringSoon(i.expiry)).length} items expiring soon` }
    ];
    
    let message = 'Current Alerts:\n\n';
    notifications.forEach(n => {
        message += `• ${n.message}\n`;
    });
    
    alert(message);
}

// Show notification toast
function showNotification(message, type) {
    const toast = document.getElementById('notificationToast');
    const icon = document.getElementById('notificationIcon');
    const msg = document.getElementById('notificationMessage');
    
    msg.textContent = message;
    
    // Set icon and color based on type
    switch(type) {
        case 'success':
            icon.textContent = 'check_circle';
            icon.className = 'material-icons text-green-500';
            break;
        case 'error':
            icon.textContent = 'error';
            icon.className = 'material-icons text-red-500';
            break;
        case 'warning':
            icon.textContent = 'warning';
            icon.className = 'material-icons text-yellow-500';
            break;
        case 'info':
            icon.textContent = 'info';
            icon.className = 'material-icons text-blue-500';
            break;
    }
    
    toast.classList.remove('hidden');
    
    setTimeout(() => {
        toast.classList.add('hidden');
    }, 3000);
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl+N for new medicine
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        openAddModal();
    }
    // Escape to close modal
    if (e.key === 'Escape') {
        closeModal();
    }
    // Ctrl+F for search
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        document.getElementById('tableSearch').focus();
    }
});

// Auto-save to localStorage (for persistence)
function autoSave() {
    // Note: Not using localStorage as per requirements, 
    // but keeping function structure for potential future use
    console.log('Auto-save triggered - data stored in memory');
}

// Initialize on page load
window.onload = function() {
    init();
    
    // Update notification badge
    const lowStockCount = inventory.filter(i => i.quantity <= 10).length;
    const expiringCount = inventory.filter(i => isExpiringSoon(i.expiry)).length;
    if (lowStockCount + expiringCount === 0) {
        document.getElementById('notificationBadge').classList.add('hidden');
    }
    
    // Set min date for expiry to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('expiryDate').setAttribute('min', today);
    
    // Auto-refresh alerts every minute
    setInterval(() => {
        updateAlerts();
        updateStats();
    }, 60000);
};