/*
  main.js - Global JS for Pharmacy Management Frontend
  - Handles modal open/close with animation
  - Handles search bar live filtering (tables)
  - Handles navbar active highlight
  - Prepares toast notification system (showToast function)
  - All functions use vanilla JS and are commented for backend integration points.
*/

document.addEventListener('DOMContentLoaded', function () {
  // Highlight active nav link based on filename
  highlightActiveNav();

  // Attach search handlers for inputs with data-search-target attribute
  document.querySelectorAll('[data-search-target]').forEach(function(input){
    const selector = input.getAttribute('data-search-target');
    const table = document.querySelector(selector);
    if(!table) return;
    input.addEventListener('input', function(e){
      const q = e.target.value.toLowerCase().trim();
      filterTableRows(table, q);
    });
  });

  // Attach open modal buttons (data-open-modal attribute)
  document.querySelectorAll('[data-open-modal]').forEach(function(btn){
    btn.addEventListener('click', function(e){
      const id = btn.getAttribute('data-open-modal');
      openModalById(id, btn);
    });
  });

  // Attach modal close by overlay click or close buttons
  document.querySelectorAll('.modal-overlay').forEach(function(overlay){
    overlay.addEventListener('click', function(e){
      // close when clicking overlay but not when clicking modal content
      if(e.target === overlay) closeModal(overlay.querySelector('.modal-container'));
    });
  });
  document.querySelectorAll('[data-close-modal]').forEach(function(btn){
    btn.addEventListener('click', function(){
      const container = btn.closest('.modal-container');
      closeModal(container);
    });
  });

  // Toast container exists? if not, create
  if(!document.getElementById('toastContainer')){
    const tc = document.createElement('div');
    tc.id = 'toastContainer';
    tc.style.position = 'fixed';
    tc.style.right = '1rem';
    tc.style.bottom = '1rem';
    tc.style.zIndex = '99999';
    document.body.appendChild(tc);
  }

});

/* ----------------------- Utility functions ----------------------- */

/**
 * highlightActiveNav - adds 'active' class to nav link matching current page filename
 */
function highlightActiveNav(){
  const path = window.location.pathname.split('/').pop();
  const navLinks = document.querySelectorAll('nav a[data-page]');
  navLinks.forEach(function(a){
    if(a.getAttribute('data-page') === path){
      a.classList.add('active-nav');
    } else {
      a.classList.remove('active-nav');
    }
  });
}

/**
 * filterTableRows - basic row filter for <table> elements
 * @param {HTMLElement} table - table element whose tbody rows will be filtered
 * @param {string} q - search query lowercased
 */
function filterTableRows(table, q){
  const rows = table.tBodies[0].rows;
  for(let r of rows){
    const text = r.textContent.toLowerCase();
    r.style.display = text.includes(q) ? '' : 'none';
  }
}

/* ----------------------- Modal functions ----------------------- */

/**
 * openModalById - opens a modal by id and optionally populates it with dataset from the clicked button
 * The button that opens the modal can have data-* attributes which will be copied into modal fields:
 * e.g., <button data-open-modal="patientModal" data-name="Sarah Johnson" data-id="PT001">View</button>
 */
function openModalById(modalId, openerBtn){
  const modal = document.getElementById(modalId);
  if(!modal) return;
  // If openerBtn provided, populate fields inside modal that have data-field attributes
  if(openerBtn){
    for(const attr of openerBtn.attributes){
      if(attr.name.startsWith('data-field-')){
        const fieldName = attr.name.replace('data-field-','');
        const target = modal.querySelector('[data-modal-field="'+fieldName+'"]');
        if(target) target.textContent = attr.value;
      }
    }
  }
  // show with animation classes
  modal.classList.remove('hidden');
  // small timeout to allow CSS transitions
  setTimeout(()=>{
    modal.classList.add('modal-open');
  }, 10);
}

/**
 * closeModal - closes modal by removing modal-open then hiding after transition
 */
function closeModal(container){
  const modal = container ? container.closest('.modal') : null;
  if(!modal) return;
  modal.classList.remove('modal-open');
  // wait for CSS animation to finish (300ms default)
  setTimeout(()=> modal.classList.add('hidden'), 300);
}

/* ----------------------- Toasts ----------------------- */

/**
 * showToast - prepares a toast notification. The backend can call this by executing 
 * window.showToast("Message", {type: "success" | "error" | "info", duration: 4000})
 */
window.showToast = function(message, options){
  options = options || {};
  const type = options.type || 'info';
  const duration = options.duration || 4000; // ms
  const container = document.getElementById('toastContainer');
  if(!container) return;
  const toast = document.createElement('div');
  toast.className = 'toast toast-'+type;
  toast.style.minWidth = '200px';
  toast.style.marginTop = '0.5rem';
  toast.style.padding = '0.75rem 1rem';
  toast.style.borderRadius = '0.5rem';
  toast.style.boxShadow = '0 6px 18px rgba(0,0,0,0.08)';
  toast.style.background = (type==='success')? 'linear-gradient(90deg,#e6fffa,#f0fff4)' : (type==='error')? 'linear-gradient(90deg,#fff5f5,#fff0f0)' : 'linear-gradient(90deg,#f0f9ff,#f7fdff)';
  toast.style.color = '#111827';
  toast.style.opacity = '0';
  toast.style.transform = 'translateY(8px)';
  toast.style.transition = 'all 250ms ease';
  toast.textContent = message;

  // Append, then animate
  container.appendChild(toast);
  requestAnimationFrame(()=>{
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
  });

  // Auto dismiss
  setTimeout(()=>{
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(8px)';
    setTimeout(()=> toast.remove(), 250);
  }, duration);

  return toast;
};

// Add these functions to your main script in each module
function initUserDropdown() {
    const dropdownButton = document.getElementById('userDropdownButton');
    const dropdownMenu = document.getElementById('userDropdownMenu');

    if (dropdownButton && dropdownMenu) {
        // Toggle dropdown
        dropdownButton.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdownMenu.classList.toggle('hidden');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!dropdownButton.contains(e.target) && !dropdownMenu.contains(e.target)) {
                dropdownMenu.classList.add('hidden');
            }
        });

        // Close dropdown when pressing Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                dropdownMenu.classList.add('hidden');
            }
        });
    }
}

function updateUserInfo() {
    const user = AuthManager.getCurrentUser();
    if (!user) return;

    // Update all user info elements
    const elements = {
        userName: user.name,
        userRole: user.role,
        dropdownUserName: user.name,
        dropdownUserRole: user.role,
        userEmail: user.email,
        lastLoginTime: formatLastLogin(user.lastLogin)
    };

    Object.keys(elements).forEach(id => {
        const element = document.getElementById(id);
        if (element) element.textContent = elements[id];
    });

    // Update avatars
    const avatars = ['userAvatar', 'dropdownAvatar'];
    avatars.forEach(id => {
        const avatar = document.getElementById(id);
        if (avatar) {
            avatar.textContent = AuthManager.getInitials(user.name);
            AuthManager.updateAvatarColor(user.role);
        }
    });
}

function formatLastLogin(timestamp) {
    if (!timestamp) return 'First login';
    
    const now = new Date();
    const lastLogin = new Date(timestamp);
    const diffMs = now - lastLogin;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays === 1) return 'Yesterday';
    return `${diffDays}d ago`;
}

// Enhanced logout function
function logoutUser() {
    Swal.fire({
        title: 'Logout Confirmation',
        text: 'Are you sure you want to log out?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#007A7A',
        cancelButtonColor: '#6B7280',
        confirmButtonText: 'Yes, log out',
        cancelButtonText: 'Cancel',
        background: document.documentElement.classList.contains('dark') ? '#1f2937' : '#ffffff',
        color: document.documentElement.classList.contains('dark') ? '#f9fafb' : '#111827',
    }).then((result) => {
        if (result.isConfirmed) {
            // Show loading state
            Swal.fire({
                title: 'Logging out...',
                text: 'Please wait while we secure your session.',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Simulate logout process
            setTimeout(() => {
                AuthManager.handleLogout();
                Swal.close();
            }, 1000);
        }
    });
}

// Remove the old logout button event listener and use the dropdown instead
document.addEventListener('DOMContentLoaded', function() {
    initUserDropdown();
    updateUserInfo();
    
    // Remove any existing standalone logout buttons
    const oldLogoutBtn = document.querySelector('button[onclick="logoutUser()"]');
    if (oldLogoutBtn) {
        oldLogoutBtn.remove();
    }
});