// middleware/authMiddleware.js

export const isAdmin = (req, res, next) => {
    // Temporary hardcoded admin user for testing
    req.user = { role: 'admin' };

    if (req.user.role === 'admin') {
        next();
    } else {
        res.status(403).json({ message: 'Access denied: Admins only' });
    }
};
