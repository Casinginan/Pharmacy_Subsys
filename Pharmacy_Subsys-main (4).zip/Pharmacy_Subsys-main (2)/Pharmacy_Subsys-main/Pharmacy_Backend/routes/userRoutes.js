import express from 'express';
import User from '../models/User.js';

const router = express.Router();

// Get all users
router.get('/', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create user
router.post('/', async (req, res) => {
  try {
    const { username, password, role } = req.body;
    const newUser = new User({ username, email,  password, role });
    await newUser.save();
    res.json({ message: 'User created successfully!' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update user
router.put('/:id', async (req, res) => {
  try {
    const { username, email, password, role } = req.body;
    await User.findByIdAndUpdate(req.params.id, { username, email, password, role });
    res.json({ message: 'User updated successfully!' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete user
router.delete('/:id', async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted successfully!' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
