// routes/admin.js
import express from 'express';
import { addUser } from '../controllers/adminController.js';
import { isAdmin } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/add-user', isAdmin, addUser);

export default router; // default export
