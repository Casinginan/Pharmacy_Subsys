import mongoose from 'mongoose';
import { emrConnection } from '../config/db.js';

// DEFINING THE SCHEMA
// 'strict: false' means: "I don't care what fields are in there, just give me all of them."
const prescribeSchema = new mongoose.Schema({}, { 
    strict: false, 
    timestamps: true 
});

// CREATING THE MODEL
// The 3rd argument 'prescribes' MUST match the collection name in their database exactly.
// If 'prescribes' doesn't work, try 'medications' or 'Prescribe'.
const Prescription = emrConnection.model('Prescribe', prescribeSchema, 'prescribes');

export default Prescription;