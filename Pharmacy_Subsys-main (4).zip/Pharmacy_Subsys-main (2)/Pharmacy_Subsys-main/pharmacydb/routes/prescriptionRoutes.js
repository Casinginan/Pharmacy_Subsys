import express from 'express';
import { protect} from '../middleware/authMiddleware.js';
import Prescription from '../models/Prescription.js';

const router = express.Router();

// @route   POST /api/prescriptions
// @desc    Create a new prescription (for Postman testing)
// @access  Private/Admin
// @route   POST /api/prescriptions
// @desc    Create a new prescription (for Postman testing)
// @access  Private/Admin
router.post('/', protect, async (req, res) => {
  try {
    // --- UPDATED to include notes and frequency ---
    const { patient, pharmacist, medicines, notes } = req.body; 

    const newPrescription = new Prescription({
      patient,
      pharmacist,
      medicines, // medicines array (with frequency) is passed directly
      notes: notes || "No notes provided.", // Save the notes
      isFilled: false,
    });
    
    const prescription = await newPrescription.save();
    res.status(201).json(prescription);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   GET /api/prescriptions
// @desc    Get all prescriptions (for the main queue)
// @access  Private/Admin
router.get('/', protect, async (req, res) => {
  try {
    const prescriptions = await Prescription.find({})
      .populate('patient', 'name') 
      .sort({ createdAt: -1 }); 
    res.json(prescriptions);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// --- THIS ROUTE IS NOW FIRST ---
// @route   GET /api/prescriptions/bypatient/:patientId
// @desc    Get all prescriptions for a single patient
// @access  Private/Admin
router.get('/bypatient/:patientId', protect, async (req, res) => {
  try {
    const prescriptions = await Prescription.find({ patient: req.params.patientId })
      .populate('pharmacist', 'name')
      .populate({
        path: 'medicines.medicine',
        model: 'Medicine',
        select: 'name strength'
      })
      .sort({ createdAt: -1 });

    if (!prescriptions) {
      return res.status(44).json({ message: 'No prescriptions found for this patient' });
    }
    res.json(prescriptions);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// --- THIS GENERIC ROUTE IS NOW SECOND ---
// @route   GET /api/prescriptions/:id
// @desc    Get a single prescription by its ID (for the "View Details" modal)
// @access  Private/Admin
router.get('/:id', protect, async (req, res) => {
  try {
    const prescription = await Prescription.findById(req.params.id)
      .populate('patient') 
      .populate('pharmacist', 'name') 
      .populate({
        path: 'medicines.medicine',
        model: 'Medicine',
        select: 'name strength'
      });

    if (!prescription) {
      return res.status(404).json({ message: 'Prescription not found' });
    }
    res.json(prescription);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

export default router;