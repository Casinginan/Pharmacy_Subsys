import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import Patient from '../models/PatientModel.js'; 

const router = express.Router();

// @route   GET /api/patients
// @desc    Search patients in EMR
router.get('/', protect, async (req, res) => {
  try {
    const keyword = req.query.search
      ? {
          $or: [
            // Search EMR fields
            { firstname: { $regex: req.query.search, $options: 'i' } },
            { lastname: { $regex: req.query.search, $options: 'i' } },
            { patientId: { $regex: req.query.search, $options: 'i' } },
          ],
        }
      : {};

    const patients = await Patient.find({}); 
    console.log("EMR Patients Found:", patients);

    // ADAPTER: Convert EMR format to Pharmacy Frontend format
    const formattedPatients = patients.map(p => ({
        _id: p._id, // Internal Mongo ID
        patientId: p.patientId, // The "P-101" string ID
        name: `${p.firstname} ${p.lastname}`, // Combine names for your table
        age: p.dob ? calculateAge(p.dob) : 'N/A',
        gender: p.gender,
        contactNo: 'N/A', // EMR Schema didn't have contact info
        status: p.status || 'Active'
    }));

    res.json(formattedPatients);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error connecting to EMR' });
  }
});

function calculateAge(dob) {
    const diff = Date.now() - new Date(dob).getTime();
    const ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}

export default router;