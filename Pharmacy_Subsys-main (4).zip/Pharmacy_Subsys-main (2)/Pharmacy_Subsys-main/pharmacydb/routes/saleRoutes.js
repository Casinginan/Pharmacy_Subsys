import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import Prescription from '../models/Prescription.js';
import Inventory from '../models/Inventory.js';
import Sale from '../models/Sale.js';
import Medicine from '../models/Medicine.js';
import Order from '../models/Order.js';
import Supplier from '../models/Supplier.js';

const router = express.Router();

// ==============================================================================
// 1. GET ALL SALES (History)
// ==============================================================================
router.get('/', protect, async (req, res) => {
    try {
        const sales = await Sale.find({})
            .populate('pharmacist', 'name')
            .populate('patient', 'name patientId') 
            .sort({ date: -1 }); 
        res.json(sales);
    } catch (err) {
        console.error("GET Sales Error:", err);
        res.status(500).json({ message: 'Server Error' });
    }
});

// ==============================================================================
// 2. DISPENSE MEDICINE (FEFO + AUTO-ORDER)
// ==============================================================================
router.post('/dispense/:patientId', protect, async (req, res) => {
    try {
        const { patientId } = req.params;
        console.log(`➡️ Dispensing request for Patient: ${patientId}`);

        // 1. Find Pending Prescriptions
        const prescriptions = await Prescription.find({ 
            patient: patientId, 
            status: 'Pending' 
        });

        if (!prescriptions || prescriptions.length === 0) {
            return res.status(404).json({ message: 'No pending prescriptions found.' });
        }

        let totalAmount = 0;
        const itemsSold = [];

        // 2. Process Each Prescription
        for (const prescription of prescriptions) {
            
            // Process Each Medicine in the Prescription
            for (const med of prescription.medicines) {
                
                // A. Find Medicine Info
                const medicineDoc = await Medicine.findById(med.medicine);
                if (!medicineDoc) {
                    throw new Error(`Medicine ID not found: ${med.medicine}`);
                }

                // --- START OF FEFO LOGIC (Replaces B, C, D) ---
                
                // B. Find ALL active batches, sorted by Expiry Date (Oldest First)
                const batches = await Inventory.find({ 
                    medicine: med.medicine, 
                    quantity: { $gt: 0 },
                    isArchived: false 
                }).sort({ expiryDate: 1 }); // 1 = Ascending (Oldest date first)

                let quantityNeeded = med.quantity;
                let sellingPrice = 0; // We'll use the price of the first batch used
                
                if (batches.length === 0) {
                    throw new Error(`No stock available for ${medicineDoc.name}`);
                }

                // C. Loop through batches and deduct
                for (let batch of batches) {
                    if (quantityNeeded <= 0) break; 

                    let takeAmount = 0;

                    // Capture price for the record (using the first batch's price)
                    if (sellingPrice === 0) sellingPrice = batch.sellingPrice;

                    if (batch.quantity >= quantityNeeded) {
                        // This batch has enough to cover the rest
                        takeAmount = quantityNeeded;
                        batch.quantity -= quantityNeeded;
                        quantityNeeded = 0; 
                    } else {
                        // This batch runs out, take all of it and move to next
                        takeAmount = batch.quantity;
                        quantityNeeded -= batch.quantity;
                        batch.quantity = 0;
                    }
                    
                    await batch.save(); // Save the updated batch
                    
                    // Record the specific batch usage for sales history
                    const itemTotal = batch.sellingPrice * takeAmount;
                    totalAmount += itemTotal;

                    itemsSold.push({
                        medicine: medicineDoc._id,
                        inventory: batch._id, // Link to specific batch
                        name: medicineDoc.name,
                        quantity: takeAmount,
                        priceAtSale: batch.sellingPrice,
                        total: itemTotal
                    });

                    // --- AUTO-ORDER CHECK (Per Batch) ---
                    if (batch.quantity <= batch.minStockLevel) {
                       // Pass current price so auto-order has a value even if stock hits 0
                       await checkAndAutoOrder(medicineDoc, batch.sellingPrice);
                    }
                }

                // D. Final Stock Validation
                if (quantityNeeded > 0) {
                    throw new Error(`Insufficient total stock for ${medicineDoc.name}. Short by ${quantityNeeded} units.`);
                }
                // --- END OF FEFO LOGIC ---
            }
            
            // 3. Mark Prescription as Filled
            prescription.status = 'Filled';
            await prescription.save();
        }

        // 4. Create Sale Record
        const sale = await Sale.create({
            patient: patientId,
            pharmacist: req.user._id,
            items: itemsSold,
            totalAmount: totalAmount,
            date: Date.now()
        });

        console.log("✅ Dispensing Success!");
        res.status(200).json({ message: 'Dispensing successful', sale });

    } catch (err) {
        console.error("❌ Dispense Error:", err.message);
        res.status(500).json({ message: err.message || 'Server Error' });
    }
    // ... inside the route ...

// 1. Find the EMR Patient first
const emrPatient = await Patient.findById(req.params.patientId);

if (!emrPatient) {
    console.log("❌ Patient not found in EMR DB");
    return res.status(404).json({ message: "Patient not found" });
}

// --- DEBUG LOG ---
console.log("🔍 Searching for prescriptions for Patient ID:", emrPatient.patientId); 
// -----------------

// 2. Find Prescriptions using that string
const prescriptions = await Prescription.find({ 
    patientId: emrPatient.patientId 
});

console.log(`✅ Found ${prescriptions.length} prescriptions.`);
});

// ==============================================================================
// HELPER FUNCTION: AUTO-ORDER LOGIC
// ==============================================================================
async function checkAndAutoOrder(medicineDoc, lastSoldPrice = 0) {
    try {
        // 1. Re-fetch medicine to get Supplier info (if not fully populated)
        const fullMedicine = await Medicine.findById(medicineDoc._id).populate('supplier');
        const medicineName = fullMedicine ? fullMedicine.name : "Unknown Medicine";

        // 2. Check total stock across all batches 
        const allBatches = await Inventory.find({ 
            medicine: medicineDoc._id,
            isArchived: false 
        });
        const totalStock = allBatches.reduce((sum, b) => sum + b.quantity, 0);
        
        // Hardcoded threshold for safety, or use minStockLevel from a batch if consistent
        const THRESHOLD = 20; 

        if (totalStock <= THRESHOLD) {
            if (fullMedicine && fullMedicine.supplier) {
                // 3. Check duplicates
                const existingOrder = await Order.findOne({
                    medicineName: medicineName,
                    status: 'Pending'
                });

                if (!existingOrder) {
                    // --- ROBUST PRICE LOGIC ---
                    let orderPrice = lastSoldPrice; 
                    
                    if (!orderPrice || orderPrice === 0) {
                        // Try finding ANY previous batch with a price
                        const lastBatch = await Inventory.findOne({ medicine: medicineDoc._id }).sort({ createdAt: -1 });
                        if (lastBatch) orderPrice = lastBatch.costPrice || lastBatch.sellingPrice || 0;
                    }
                    
                    if (!orderPrice) orderPrice = 10; // Final fallback

                    // 4. Create Order
                    const newOrder = new Order({
                        orderId: `ORD-${Date.now().toString().slice(-6)}`,
                        supplier: fullMedicine.supplier._id,
                        supplierName: fullMedicine.supplier.name,
                        medicineName: medicineName,
                        quantity: 100, // Default reorder amount
                        unitPrice: orderPrice,
                        totalPrice: (100 * orderPrice),
                        expectedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
                        status: 'Pending',
                        autoOrdered: true
                    });

                    await newOrder.save();
                    console.log(`[AUTO-ORDER] Triggered for ${medicineName}`);
                }
            } else {
                console.log(`[AUTO-ORDER] Failed: ${medicineName} has no supplier.`);
            }
        }
    } catch (e) {
        console.error("[AUTO-ORDER ERROR]", e);
    }
}

export default router;