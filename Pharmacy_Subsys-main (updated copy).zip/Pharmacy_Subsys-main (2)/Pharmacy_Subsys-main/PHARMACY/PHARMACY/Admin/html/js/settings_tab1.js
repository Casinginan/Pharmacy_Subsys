const API_BASE_URL = 'http://localhost:5001'; // Change to 5000 if you haven't switched ports yet

class SettingsManager {
    constructor() {
        this.init();
    }

    async init() {
        if (!this.getToken()) {
            window.location.href = '../../html/login.html';
            return;
        }
        // Load current settings when page opens
        await this.fetchSettings();
        this.setupListeners();
    }

    getToken() {
        const userInfo = localStorage.getItem('userInfo');
        return userInfo ? JSON.parse(userInfo).token : null;
    }

    async apiCall(endpoint, method = 'GET', body = null) {
        try {
            const options = {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.getToken()}`
                }
            };
            if (body) options.body = JSON.stringify(body);

            const res = await fetch(`${API_BASE_URL}${endpoint}`, options);
            return await res.json();
        } catch (err) {
            console.error(err);
            return null;
        }
    }

    async fetchSettings() {
        const settings = await this.apiCall('/api/settings');
        if (settings) {
            // Set initial visual state based on DB
            this.updateUI('emr', settings.emr.enabled);
            this.updateUI('billing', settings.billing.enabled);
        }
    }

    async handleToggle(system, isEnabled) {
        // 1. Visual Feedback (Immediate)
        this.updateStatusBadge(system, isEnabled);
        this.log(`Syncing ${system.toUpperCase()} configuration...`);

        // 2. Prepare Data
        const payload = {};
        payload[system] = { enabled: isEnabled };

        // 3. Send to Backend
        const result = await this.apiCall('/api/settings', 'PUT', payload);

        if (result) {
            this.log(`[SUCCESS] ${system.toUpperCase()} Integration is now ${isEnabled ? 'ACTIVE' : 'DISABLED'}.`);
            
            const Toast = Swal.mixin({
                toast: true, position: 'top-end', showConfirmButton: false, timer: 3000,
                timerProgressBar: true,
            });
            Toast.fire({
                icon: isEnabled ? 'success' : 'info',
                title: `${system.toUpperCase()} System ${isEnabled ? 'Connected' : 'Disconnected'}`
            });
        } else {
            // Revert if failed
            document.getElementById(`${system}-toggle`).checked = !isEnabled;
            this.updateStatusBadge(system, !isEnabled);
            Swal.fire('Error', 'Failed to update settings.', 'error');
        }
    }

    updateUI(system, isEnabled) {
        const toggle = document.getElementById(`${system}-toggle`);
        if(toggle) toggle.checked = isEnabled;
        this.updateStatusBadge(system, isEnabled);
    }

    updateStatusBadge(system, isEnabled) {
        const badge = document.getElementById(`${system}-status-badge`);
        if (badge) {
            if (isEnabled) {
                badge.textContent = "Connected";
                badge.className = "px-2 py-1 rounded-full text-xs font-bold bg-green-100 text-green-600";
            } else {
                badge.textContent = "Disconnected";
                badge.className = "px-2 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-500";
            }
        }
    }

    log(message) {
        const el = document.getElementById('log-entry');
        if(el) el.innerHTML = `<span class="text-primary font-mono">[${new Date().toLocaleTimeString()}]</span> ${message}`;
    }

    setupListeners() {
        const emrToggle = document.getElementById('emr-toggle');
        const billingToggle = document.getElementById('billing-toggle');

        if (emrToggle) {
            emrToggle.addEventListener('change', (e) => {
                this.handleToggle('emr', e.target.checked);
            });
        }
        if (billingToggle) {
            billingToggle.addEventListener('change', (e) => {
                this.handleToggle('billing', e.target.checked);
            });
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.settingsManager = new SettingsManager();
});