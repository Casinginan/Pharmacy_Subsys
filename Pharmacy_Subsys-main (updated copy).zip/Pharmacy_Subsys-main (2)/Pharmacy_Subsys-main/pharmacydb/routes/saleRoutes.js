import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import Prescription from '../models/Prescription.js';
import Inventory from '../models/Inventory.js';
import Sale from '../models/Sale.js';
import Medicine from '../models/Medicine.js';
import Order from '../models/Order.js';
import Patient from '../models/Patient.js'; // Import Patient to get the String ID

const router = express.Router();

// ==============================================================================
// 1. GET ALL SALES (History)
// ==============================================================================
router.get('/', protect, async (req, res) => {
    try {
        const sales = await Sale.find({})
            .populate('pharmacist', 'name')
            
            .sort({ date: -1 }); 
        res.json(sales);
    } catch (err) {
        console.error("GET Sales Error:", err);
        res.status(500).json({ message: 'Server Error' });
    }
});

// ==============================================================================
// 2. DISPENSE MEDICINE (FEFO + AUTO-ORDER)
// ==============================================================================
router.post('/dispense/:patientId', protect, async (req, res) => {
    try {
        const { patientId } = req.params; // This is the Mongo ID from the URL
        console.log(`➡️ Dispensing request for Patient Mongo ID: ${patientId}`);

        // 1. Get the Patient to find their "EMR String ID" (e.g. P-001)
        const emrPatient = await Patient.findById(patientId);
        if (!emrPatient) {
            return res.status(404).json({ message: 'Patient not found in EMR' });
        }

        console.log(`   Mapped to EMR Patient ID: ${emrPatient.patientId}`);

        // 2. Find Prescriptions using the String ID
        // NOTE: We removed 'status: Pending' because EMR schema doesn't have it!
        const allPrescriptions = await Prescription.find({ 
            patientId: emrPatient.patientId 
        });

        if (!allPrescriptions || allPrescriptions.length === 0) {
            return res.status(404).json({ message: 'No prescriptions found for this patient.' });
        }

        // 3. Filter out items ALREADY dispensed
        // We check our local Sales history for this patient
        const pastSales = await Sale.find({ patient: patientId });
        const dispensedMedicineNames = pastSales.flatMap(sale => sale.items.map(i => i.name));

        // Keep only medicines that haven't been sold to this patient yet
        // (Matching by name is the safest bet with EMR integration)
        const prescriptions = allPrescriptions.filter(p => !dispensedMedicineNames.includes(p.medicname));

        if (prescriptions.length === 0) {
            return res.status(400).json({ message: 'All prescriptions for this patient have already been filled.' });
        }

        let totalAmount = 0;
        const itemsSold = [];

        // --- PROCESS PRESCRIPTIONS ---
        // Note: EMR structure is flat (one doc per medicine), not nested array
        for (const med of prescriptions) {
            
            // A. Find Local Medicine ID by Name (EMR gives string name, we need ID)
            const medicineDoc = await Medicine.findOne({ 
                name: { $regex: new RegExp(`^${med.medicname}$`, 'i') } 
            });

            if (!medicineDoc) {
                // Skip medicines we don't carry, or throw error? Let's throw for safety.
                throw new Error(`Medicine not found in Inventory: ${med.medicname}`);
            }

            // B. FEFO Logic
            const batches = await Inventory.find({ 
                medicine: medicineDoc._id, 
                quantity: { $gt: 0 },
                isArchived: false 
            }).sort({ expiryDate: 1 }); 

            // EMR quantity is a String, convert to Number
            let quantityNeeded = parseInt(med.quantity) || 0;

            if (batches.length === 0) {
                throw new Error(`No stock available for ${medicineDoc.name}`);
            }

            // C. Deduct Loop
            for (let batch of batches) {
                if (quantityNeeded <= 0) break; 

                let takeAmount = 0;
                const currentBatchPrice = batch.sellingPrice || batch.price || 0;

                if (batch.quantity >= quantityNeeded) {
                    takeAmount = quantityNeeded;
                    batch.quantity -= quantityNeeded;
                    quantityNeeded = 0; 
                } else {
                    takeAmount = batch.quantity;
                    quantityNeeded -= batch.quantity;
                    batch.quantity = 0;
                }

                await batch.save(); 

                const itemTotal = currentBatchPrice * takeAmount;
                totalAmount += itemTotal;

                itemsSold.push({
                    medicine: medicineDoc._id,
                    inventory: batch._id,
                    name: medicineDoc.name,
                    quantity: takeAmount,
                    priceAtSale: currentBatchPrice,
                    total: itemTotal
                });

                // D. Auto-Order Check
                console.log(`🔍 Checking auto-order for: ${medicineDoc.name}`);
                await checkAndAutoOrder(medicineDoc._id, currentBatchPrice);
            }

            if (quantityNeeded > 0) {
                throw new Error(`Insufficient total stock for ${medicineDoc.name}. Short by ${quantityNeeded} units.`);
            }
        }

        const pName = `${emrPatient.firstname} ${emrPatient.lastname}`;

        // 4. Create Sale Record
        const sale = await Sale.create({
            patient: patientId, // Use Mongo ID for our records
            patientName: pName,
            pharmacist: req.user._id,
            items: itemsSold,
            totalAmount: totalAmount,
            date: Date.now()
        });

        console.log("✅ Dispensing Success!");
        res.status(200).json({ message: 'Dispensing successful', sale });

    } catch (err) {
        console.error("❌ Dispense Error:", err.message);
        res.status(500).json({ message: err.message || 'Server Error' });
    }
});

// ==============================================================================
// HELPER: AUTO-ORDER LOGIC
// ==============================================================================
async function checkAndAutoOrder(medicineId, lastSoldPrice = 0) {
    try {
        const allBatches = await Inventory.find({ 
            medicine: medicineId,
            isArchived: false 
        });
        
        const totalStock = allBatches.reduce((sum, b) => sum + b.quantity, 0);
        const THRESHOLD = 20; 

        if (totalStock <= THRESHOLD) {
            const fullMedicine = await Medicine.findById(medicineId).populate('supplier');
            
            if (!fullMedicine) return;

            if (fullMedicine && fullMedicine.supplier) {
                const existingOrder = await Order.findOne({
                    medicineName: fullMedicine.name,
                    status: 'Pending'
                });

                if (!existingOrder) {
                    let orderPrice = lastSoldPrice; 
                    if (!orderPrice || orderPrice === 0) {
                        const lastBatch = await Inventory.findOne({ medicine: medicineId }).sort({ createdAt: -1 });
                        if (lastBatch) orderPrice = lastBatch.sellingPrice || lastBatch.costPrice || 0;
                    }
                    if (!orderPrice) orderPrice = 10;

                    const newOrder = new Order({
                        orderId: `ORD-${Date.now().toString().slice(-6)}`,
                        supplier: fullMedicine.supplier._id,
                        supplierName: fullMedicine.supplier.name,
                        medicineName: fullMedicine.name,
                        quantity: 100, 
                        unitPrice: orderPrice,
                        totalPrice: (100 * orderPrice),
                        expectedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
                        status: 'Pending',
                        autoOrdered: true
                    });

                    await newOrder.save();
                    console.log(`   🚀 [AUTO-ORDER] Created for ${fullMedicine.name}`);
                }
            }
        }
    } catch (e) {
        console.error("   ❌ Auto-Order Logic Error:", e);
    }
}

export default router;