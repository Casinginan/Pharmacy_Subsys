import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import Inventory from '../models/Inventory.js';
import Sale from '../models/Sale.js';
import Prescription from '../models/Prescription.js';
import Medicine from '../models/Medicine.js';

const router = express.Router();

// @route   GET /api/dashboard/stats
// @desc    Get ALL dashboard stats (Counters + Charts)
router.get('/stats', protect, async (req, res) => {
  try {
    // --- 1. COUNTERS (Existing Logic) ---
    const totalItems = await Inventory.countDocuments({ isArchived: false });
    const outOfStock = await Inventory.countDocuments({ quantity: 0, isArchived: false });
    const lowStock = await Inventory.countDocuments({ quantity: { $gt: 0, $lte: 10 }, isArchived: false });
    
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
    const expiringSoon = await Inventory.countDocuments({
      expiryDate: { $lte: thirtyDaysFromNow },
      isArchived: false
    });

    // Today's Sales
    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date(); todayEnd.setHours(23, 59, 59, 999);
    
    const todaySales = await Sale.find({ date: { $gte: todayStart, $lte: todayEnd } });
    const todayRevenue = todaySales.reduce((acc, sale) => acc + sale.totalAmount, 0);
    const todayTransactions = todaySales.length;
    const avgTransaction = todayTransactions > 0 ? todayRevenue / todayTransactions : 0;

    // Prescriptions
    const todayPrescriptions = await Prescription.find({ createdAt: { $gte: todayStart, $lte: todayEnd } });
    const pendingReview = await Prescription.countDocuments({ status: 'Pending' }); // Adjust status based on your EMR logic
    const readyForPickup = await Prescription.countDocuments({ status: 'Filled' });

    // --- 2. CHARTS: SALES TREND (Last 7 Days) ---
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
    sevenDaysAgo.setHours(0, 0, 0, 0);

    const salesTrendRaw = await Sale.aggregate([
      { $match: { date: { $gte: sevenDaysAgo } } },
      { $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$date" } },
          dailyRevenue: { $sum: "$totalAmount" }
      }},
      { $sort: { _id: 1 } }
    ]);

    // Fill in missing days with 0
    const salesTrend = [];
    for (let i = 0; i < 7; i++) {
        const d = new Date();
        d.setDate(d.getDate() - (6 - i));
        const dateStr = d.toISOString().split('T')[0];
        const found = salesTrendRaw.find(s => s._id === dateStr);
        
        salesTrend.push({
            date: d.toLocaleDateString('en-US', { weekday: 'short' }), // "Mon", "Tue"
            revenue: found ? found.dailyRevenue : 0
        });
    }

    // --- 3. CHARTS: STOCK DISTRIBUTION (By Type) ---
    // We need to look up the 'type' from the Medicine model
    const inventoryRaw = await Inventory.find({ isArchived: false }).populate('medicine', 'type');
    
    const stockDistribution = {};
    inventoryRaw.forEach(item => {
        const type = (item.medicine && item.medicine.type) ? item.medicine.type : "Other";
        if (!stockDistribution[type]) stockDistribution[type] = 0;
        stockDistribution[type] += item.quantity;
    });

    // Format for Chart.js
    const stockChartData = {
        labels: Object.keys(stockDistribution),
        data: Object.values(stockDistribution)
    };

    // --- FINAL RESPONSE ---
    res.json({
      inventory: { totalItems, outOfStock, lowStock, expiringSoon },
      sales: { todayRevenue, todayTransactions, avgTransaction },
      prescriptions: { todayTotal: todayPrescriptions.length, pendingReview, readyForPickup },
      charts: {
          salesTrend: {
              labels: salesTrend.map(s => s.date),
              data: salesTrend.map(s => s.revenue)
          },
          stockDistribution: stockChartData
      }
    });

  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

export default router;