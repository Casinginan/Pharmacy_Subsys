import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import Patient from '../models/Patient.js'; 
import SystemSettings from '../models/SystemSettings.js';

const router = express.Router();

// @route   GET /api/patients
// @desc    Search patients in EMR (Controlled by Settings)
router.get('/', protect, async (req, res) => {
  try {
    // --- 1. DISINTEGRATION LOGIC (Start) ---
    // Check if EMR integration is enabled in the database
    const settings = await SystemSettings.findOne();
    
    // If settings don't exist OR emr.enabled is false, return empty list
    if (!settings || !settings.emr.enabled) {
        return res.json([]); // effectively "disintegrating" the view
    }
    // --- DISINTEGRATION LOGIC (End) ---

    const keyword = req.query.search
      ? {
          $or: [
            // Search EMR fields
            { firstname: { $regex: req.query.search, $options: 'i' } },
            { lastname: { $regex: req.query.search, $options: 'i' } },
            { patientId: { $regex: req.query.search, $options: 'i' } },
          ],
        }
      : {};

    // FIX: Use 'keyword' here instead of '{}' so the search bar works!
    const patients = await Patient.find(keyword); 

    // ADAPTER: Convert EMR format to Pharmacy Frontend format
    const formattedPatients = patients.map(p => ({
        _id: p._id,
        patientId: p.patientId,
        name: `${p.firstname} ${p.lastname}`,
        age: p.dob ? calculateAge(p.dob) : 'N/A',
        gender: p.gender,
        contactNo: 'N/A',
        status: p.status || 'Active'
    }));

    res.json(formattedPatients);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error connecting to EMR' });
  }
});

function calculateAge(dob) {
    const diff = Date.now() - new Date(dob).getTime();
    const ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}

export default router;