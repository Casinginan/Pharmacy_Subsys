importConfiguration() {
    // Create a file input element
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.json';
    fileInput.style.display = 'none';
    
    fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (!file) return;

        // Validate file type
        if (!file.name.endsWith('.json')) {
            Swal.fire({
                title: 'Invalid File',
                text: 'Please select a valid JSON configuration file.',
                icon: 'error',
                confirmButtonText: 'OK',
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
            return;
        }

        const reader = new FileReader();
        
        reader.onload = (e) => {
            try {
                const config = JSON.parse(e.target.result);
                
                // Validate configuration structure
                if (!this.validateConfiguration(config)) {
                    Swal.fire({
                        title: 'Invalid Configuration',
                        text: 'The selected file does not contain valid PharmaCare configuration data.',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                        color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
                    });
                    return;
                }

                // Show confirmation dialog
                Swal.fire({
                    title: 'Import Configuration?',
                    html: `
                        <div class="text-left">
                            <p>This will import configuration from:</p>
                            <div class="mt-2 p-2 bg-gray-100 dark:bg-gray-800 rounded text-sm">
                                <strong>File:</strong> ${file.name}<br>
                                <strong>Size:</strong> ${(file.size / 1024).toFixed(2)} KB<br>
                                <strong>Date:</strong> ${new Date(file.lastModified).toLocaleDateString()}
                            </div>
                            <p class="mt-3 text-red-600 dark:text-red-400 font-semibold">
                                Warning: This will overwrite your current system settings!
                            </p>
                        </div>
                    `,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, Import',
                    cancelButtonText: 'Cancel',
                    background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                    color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.applyConfiguration(config);
                    }
                });
                
            } catch (error) {
                console.error('Error parsing configuration file:', error);
                Swal.fire({
                    title: 'Parse Error',
                    text: 'Unable to read the configuration file. Please ensure it is a valid JSON file.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                    color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
                });
            }
        };
        
        reader.onerror = () => {
            Swal.fire({
                title: 'Read Error',
                text: 'Unable to read the selected file.',
                icon: 'error',
                confirmButtonText: 'OK',
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
        };
        
        reader.readAsText(file);
    });

    // Trigger the file input click
    document.body.appendChild(fileInput);
    fileInput.click();
    document.body.removeChild(fileInput);
}

validateConfiguration(config) {
    // Basic validation - check if it has expected structure
    return config && 
           (config.systemSettings !== undefined || 
            config.emr !== undefined || 
            config.billing !== undefined ||
            config.timestamp !== undefined);
}

applyConfiguration(config) {
    // Show loading state
    Swal.fire({
        title: 'Importing Configuration...',
        text: 'Please wait while we apply your settings',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        },
        background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
        color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
    });

    // Simulate import process
    setTimeout(() => {
        try {
            let importedSettings = 0;

            // Apply system settings
            if (config.systemSettings) {
                localStorage.setItem('systemSettings', config.systemSettings);
                importedSettings++;
            }

            // Apply system status
            if (config.systemStatus) {
                localStorage.setItem('systemStatus', JSON.stringify(config.systemStatus));
                importedSettings++;
            }

            // Apply individual settings if present
            if (config.emr) {
                const currentSettings = JSON.parse(localStorage.getItem('systemSettings') || '{}');
                currentSettings.emr = config.emr;
                localStorage.setItem('systemSettings', JSON.stringify(currentSettings));
                importedSettings++;
            }

            if (config.billing) {
                const currentSettings = JSON.parse(localStorage.getItem('systemSettings') || '{}');
                currentSettings.billing = config.billing;
                localStorage.setItem('systemSettings', JSON.stringify(currentSettings));
                importedSettings++;
            }

            Swal.fire({
                title: 'Configuration Imported!',
                html: `
                    <div class="text-left">
                        <p>Successfully imported configuration with:</p>
                        <div class="mt-2 p-2 bg-green-100 dark:bg-green-900 rounded text-sm">
                            <strong>Settings Applied:</strong> ${importedSettings} configuration sections<br>
                            <strong>Timestamp:</strong> ${config.timestamp ? new Date(config.timestamp).toLocaleString() : 'Unknown'}
                        </div>
                        <p class="mt-3 text-green-600 dark:text-green-400">
                            The page will reload to apply the new settings.
                        </p>
                    </div>
                `,
                icon: 'success',
                timer: 3000,
                showConfirmButton: false,
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            }).then(() => {
                // Refresh the page to show new settings
                window.location.reload();
            });

        } catch (error) {
            console.error('Error applying configuration:', error);
            Swal.fire({
                title: 'Import Failed',
                text: 'There was an error applying the configuration. Some settings may not have been imported.',
                icon: 'error',
                confirmButtonText: 'OK',
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
        }
    }, 2000);
}