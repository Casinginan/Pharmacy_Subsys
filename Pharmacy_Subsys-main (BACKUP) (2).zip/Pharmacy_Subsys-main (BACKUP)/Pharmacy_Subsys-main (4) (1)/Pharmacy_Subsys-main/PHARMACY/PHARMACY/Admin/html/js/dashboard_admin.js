tailwind.config = {
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primary: "#358E83",
        "background-light": "#F9FAFB",
        "background-dark": "#111827",
        "surface-light": "#FFFFFF",
        "surface-dark": "#1F2937",
        "text-light": "##1F2937",
        "text-dark": "#F9FAFB",
        "subtext-light": "#6B7280",
        "subtext-dark": "#9CA3AF",
        "border-light": "#E5E7EB",
        "border-dark": "#374151",
        "success": "#22C55E",
        "warning": "#F59E0B",
        "danger": "#EF4444"
      },
      fontFamily: {
        display: ["Inter", "sans-serif"],
      },
      borderRadius: {
        DEFAULT: "0.5rem",
      },
    },
  },
};

// Search Manager Class
class SearchManager {
    constructor() {
        this.searchableItems = [
            { 
                id: 'total-medicines', 
                title: 'Total Medicines', 
                category: 'Dashboard Stats', 
                type: 'stat',
                value: '1,247',
                description: 'Total number of medicines in inventory'
            },
            { 
                id: 'out-of-stock', 
                title: 'Out of Stock Items', 
                category: 'Dashboard Stats', 
                type: 'stat',
                value: '23',
                description: 'Medicines currently out of stock'
            },
            { 
                id: 'expiries', 
                title: 'Upcoming Expiries', 
                category: 'Dashboard Stats', 
                type: 'stat',
                value: '45',
                description: 'Medicines expiring in next 30 days'
            },
            { 
                id: 'sales-summary', 
                title: 'Sales Summary', 
                category: 'Dashboard Stats', 
                type: 'stat',
                value: '₱45,890',
                description: 'Total sales for current period'
            },
            { 
                id: 'generateReportBtn', 
                title: 'Generate Report', 
                category: 'Actions', 
                type: 'button',
                description: 'Generate various system reports'
            },
            { 
                id: 'viewDetailsBtn', 
                title: 'View Analytics Details', 
                category: 'Actions', 
                type: 'button',
                description: 'View detailed analytics and statistics'
            },
            { 
                id: 'inventory-section', 
                title: 'Inventory Management', 
                category: 'Navigation', 
                type: 'link',
                description: 'Go to inventory management page',
                url: 'inventory_admin.html'
            },
            { 
                id: 'user-management', 
                title: 'User Management', 
                category: 'Navigation', 
                type: 'link',
                description: 'Go to user management page',
                url: 'user_management.html'
            },
            { 
                id: 'system-settings', 
                title: 'System Settings', 
                category: 'Navigation', 
                type: 'link',
                description: 'Go to system settings page',
                url: 'settings_tab1.html'
            }
        ];
        
        this.searchInput = document.querySelector('input[placeholder="Search..."]');
        this.searchDropdown = this.createSearchDropdown();
        this.initializeSearch();
    }

    createSearchDropdown() {
        const dropdown = document.createElement('div');
        dropdown.className = 'search-results-dropdown absolute top-full left-0 right-0 mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg shadow-xl z-50 max-h-80 overflow-y-auto hidden';
        dropdown.innerHTML = `
            <div class="p-3 border-b border-gray-200 dark:border-gray-600">
                <div class="flex justify-between items-center">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300">Search Results</h3>
                    <button class="text-xs text-primary hover:underline clear-search">Clear</button>
                </div>
            </div>
            <div class="search-results-container"></div>
        `;
        
        // Insert dropdown after search input
        this.searchInput.parentNode.appendChild(dropdown);
        return dropdown;
    }

    initializeSearch() {
        // Add event listeners
        this.searchInput.addEventListener('input', (e) => this.handleSearch(e.target.value));
        this.searchInput.addEventListener('focus', () => {
            if (this.searchInput.value.length > 0) {
                this.showDropdown();
            }
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.searchInput.contains(e.target) && !this.searchDropdown.contains(e.target)) {
                this.hideDropdown();
            }
        });

        // Clear search button
        this.searchDropdown.querySelector('.clear-search').addEventListener('click', () => {
            this.clearSearch();
        });

        // Keyboard navigation
        this.searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.hideDropdown();
                this.searchInput.blur();
            }
            if (e.key === 'Enter' && this.searchInput.value.trim()) {
                this.performQuickAction(this.searchInput.value.trim());
            }
        });
    }

    handleSearch(query) {
        if (query.length === 0) {
            this.hideDropdown();
            return;
        }

        const results = this.searchableItems.filter(item =>
            item.title.toLowerCase().includes(query.toLowerCase()) ||
            item.category.toLowerCase().includes(query.toLowerCase()) ||
            item.description.toLowerCase().includes(query.toLowerCase())
        );

        if (results.length > 0) {
            this.renderSearchResults(results);
            this.showDropdown();
        } else {
            this.showNoResults(query);
        }
    }

    renderSearchResults(results) {
        const container = this.searchDropdown.querySelector('.search-results-container');
        const groupedResults = this.groupByCategory(results);

        let html = '';
        Object.keys(groupedResults).forEach(category => {
            html += `
                <div class="p-3 border-b border-gray-100 dark:border-gray-700 last:border-b-0">
                    <h4 class="font-semibold text-gray-700 dark:text-gray-300 text-sm mb-2">${category}</h4>
                    <div class="space-y-1">
            `;
            
            groupedResults[category].forEach(item => {
                html += `
                    <button onclick="searchManager.navigateToItem('${item.id}')" 
                            class="w-full text-left p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-3 transition-colors">
                        <span class="material-icons text-primary text-sm">${this.getItemIcon(item.type)}</span>
                        <div class="flex-1 min-w-0">
                            <div class="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">${item.title}</div>
                            <div class="text-xs text-gray-500 dark:text-gray-400 truncate">${item.description}</div>
                            ${item.value ? `<div class="text-xs font-semibold text-primary mt-1">${item.value}</div>` : ''}
                        </div>
                        <span class="material-icons text-gray-400 text-sm">chevron_right</span>
                    </button>
                `;
            });
            
            html += `</div></div>`;
        });

        container.innerHTML = html;
    }

    showNoResults(query) {
        const container = this.searchDropdown.querySelector('.search-results-container');
        container.innerHTML = `
            <div class="p-6 text-center text-gray-500 dark:text-gray-400">
                <span class="material-icons text-4xl mb-3 opacity-50">search_off</span>
                <p class="font-medium">No results found for</p>
                <p class="text-sm">"${query}"</p>
                <div class="mt-4 text-xs text-gray-400 dark:text-gray-500">
                    Try searching for "medicines", "reports", or "inventory"
                </div>
            </div>
        `;
        this.showDropdown();
    }

    groupByCategory(items) {
        return items.reduce((groups, item) => {
            const category = item.category;
            if (!groups[category]) {
                groups[category] = [];
            }
            groups[category].push(item);
            return groups;
        }, {});
    }

    getItemIcon(type) {
        const icons = {
            stat: 'analytics',
            button: 'play_arrow',
            link: 'open_in_new',
            navigation: 'navigation'
        };
        return icons[type] || 'search';
    }

    navigateToItem(itemId) {
        const item = this.searchableItems.find(i => i.id === itemId);
        if (!item) return;

        switch(item.type) {
            case 'stat':
                this.highlightStatCard(itemId);
                break;
            case 'button':
                this.clickButton(itemId);
                break;
            case 'link':
                if (item.url) {
                    window.location.href = item.url;
                }
                break;
        }
        
        this.hideDropdown();
        this.searchInput.value = '';
    }

    highlightStatCard(statId) {
        const card = document.querySelector(`[data-stat="${statId}"]`);
        if (card) {
            // Add highlight animation
            card.style.transform = 'scale(1.05)';
            card.style.boxShadow = '0 0 0 3px rgba(53, 142, 131, 0.3)';
            
            setTimeout(() => {
                card.style.transform = 'scale(1)';
                card.style.boxShadow = '';
            }, 2000);
            
            card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    clickButton(buttonId) {
        const button = document.getElementById(buttonId);
        if (button) {
            // Add click feedback
            button.classList.add('bg-opacity-80');
            button.click();
            
            setTimeout(() => {
                button.classList.remove('bg-opacity-80');
            }, 300);
        }
    }

    performQuickAction(query) {
        const exactMatch = this.searchableItems.find(item =>
            item.title.toLowerCase() === query.toLowerCase()
        );

        if (exactMatch) {
            this.navigateToItem(exactMatch.id);
        } else {
            // Show quick actions modal for ambiguous searches
            this.showQuickActionsModal(query);
        }
    }

    showQuickActionsModal(query) {
        const similarItems = this.searchableItems.filter(item =>
            item.title.toLowerCase().includes(query.toLowerCase()) ||
            item.description.toLowerCase().includes(query.toLowerCase())
        );

        if (similarItems.length > 0) {
            let html = `
                <div class="text-left max-h-96 overflow-y-auto">
                    <h4 class="font-semibold text-gray-900 dark:text-gray-100 mb-4">Quick Actions for "${query}"</h4>
                    <div class="space-y-2">
            `;

            similarItems.forEach(item => {
                html += `
                    <button onclick="searchManager.navigateToItem('${item.id}'); Swal.close();" 
                            class="w-full text-left p-3 rounded-lg border border-gray-200 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3">
                        <span class="material-icons text-primary text-sm">${this.getItemIcon(item.type)}</span>
                        <div class="flex-1">
                            <div class="font-medium text-gray-900 dark:text-gray-100">${item.title}</div>
                            <div class="text-sm text-gray-500 dark:text-gray-400">${item.description}</div>
                        </div>
                    </button>
                `;
            });

            html += `</div></div>`;

            Swal.fire({
                title: 'Search Results',
                html: html,
                showConfirmButton: false,
                showCloseButton: true,
                width: 500,
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            });
        }
    }

    showDropdown() {
        this.searchDropdown.classList.remove('hidden');
    }

    hideDropdown() {
        this.searchDropdown.classList.add('hidden');
    }

    clearSearch() {
        this.searchInput.value = '';
        this.hideDropdown();
        this.searchInput.focus();
    }

    // Add recent searches functionality
    addToRecentSearches(item) {
        let recentSearches = JSON.parse(localStorage.getItem('recentSearches') || '[]');
        recentSearches = recentSearches.filter(search => search.id !== item.id);
        recentSearches.unshift({
            id: item.id,
            title: item.title,
            timestamp: new Date().toISOString()
        });
        
        // Keep only last 5 searches
        recentSearches = recentSearches.slice(0, 5);
        localStorage.setItem('recentSearches', JSON.stringify(recentSearches));
    }
}

// Initialize Search Manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Add data-stat attributes to stat cards for search functionality
    const statCards = document.querySelectorAll('.bg-card-light, .bg-card-dark');
    const statIds = ['total-medicines', 'out-of-stock', 'expiries', 'sales-summary'];
    
    statCards.forEach((card, index) => {
        if (statIds[index]) {
            card.setAttribute('data-stat', statIds[index]);
        }
    });

    // Initialize search manager
    window.searchManager = new SearchManager();
});


const searchStyles = `
.search-results-dropdown {
    backdrop-filter: blur(10px);
    background: rgba(255, 255, 255, 0.95);
}

.dark .search-results-dropdown {
    background: rgba(31, 41, 55, 0.95);
}

.search-results-dropdown {
    animation: slideDown 0.2s ease-out;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Search input focus styles */
.search-input:focus {
    box-shadow: 0 0 0 3px rgba(53, 142, 131, 0.1);
}

/* Stat card highlight animation */
.highlight-stat {
    animation: pulseHighlight 2s ease-in-out;
}

@keyframes pulseHighlight {
    0%, 100% {
        box-shadow: 0 0 0 0 rgba(53, 142, 131, 0.4);
    }
    50% {
        box-shadow: 0 0 0 10px rgba(53, 142, 131, 0);
    }
}
`;

// Inject search styles
const styleSheet = document.createElement('style');
styleSheet.textContent = searchStyles;
document.head.appendChild(styleSheet);

// Enhanced search functionality with hotkeys
document.addEventListener('keydown', function(e) {
    // Ctrl+K or Cmd+K for quick search focus
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }
    
    // Forward slash (/) for quick search
    if (e.key === '/' && !e.ctrlKey && !e.metaKey) {
        const searchInput = document.querySelector('');
        if (searchInput && document.activeElement !== searchInput) {
            e.preventDefault();
            searchInput.focus();
        }
    }
});

// Add search placeholder with hotkey hint
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.querySelector('input[placeholder="Search..."]');
    if (searchInput) {
        // Update placeholder to show hotkey
        searchInput.placeholder = 'Search...';
        searchInput.classList.add('search-input');
    }
});

class NotificationManager {
    constructor() {
        this.notifications = [];
        this.unreadCount = 0;
        this.permissionAsked = false;
        this.loadNotifications();
        this.setupEventListeners();
        this.startAutoRefresh();
    }

    loadNotifications() {
        // Sample notifications data
        this.notifications = [
            {
                id: 1,
                type: 'warning',
                title: 'Low Stock Alert',
                message: 'Paracetamol 500mg is running low. Current stock: 15 units',
                timestamp: new Date(Date.now() - 300000), // 5 minutes ago
                read: false,
                action: 'inventory'
            },
            {
                id: 2,
                type: 'danger',
                title: 'Critical Stock Level',
                message: 'Amoxicillin 250mg is out of stock',
                timestamp: new Date(Date.now() - 900000), // 15 minutes ago
                read: false,
                action: 'inventory'
            },
            {
                id: 3,
                type: 'info',
                title: 'New Prescription',
                message: 'Dr. Smith submitted a new prescription for patient John Doe',
                timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
                read: false,
                action: 'prescriptions'
            },
            {
                id: 4,
                type: 'success',
                title: 'Monthly Report Ready',
                message: 'October sales report has been generated successfully',
                timestamp: new Date(Date.now() - 3600000), // 1 hour ago
                read: true,
                action: 'reports'
            },
            {
                id: 5,
                type: 'warning',
                title: 'Expiry Alert',
                message: '5 medicines are expiring in the next 30 days',
                timestamp: new Date(Date.now() - 7200000), // 2 hours ago
                read: true,
                action: 'inventory'
            }
        ];
        this.updateUnreadCount();
        this.renderNotifications();
    }

    updateUnreadCount() {
        this.unreadCount = this.notifications.filter(n => !n.read).length;
        const badge = document.getElementById('notificationBadge');
        if (this.unreadCount > 0) {
            badge.textContent = this.unreadCount > 9 ? '9+' : this.unreadCount;
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }

    renderNotifications() {
        const container = document.getElementById('notificationList');
        container.innerHTML = '';

        if (this.notifications.length === 0) {
            container.innerHTML = `
                <div class="p-4 text-center text-gray-500">
                    <span class="material-icons text-4xl mb-2">notifications_off</span>
                    <p>No notifications</p>
                </div>
            `;
            return;
        }

        this.notifications.forEach(notification => {
            const notificationElement = this.createNotificationElement(notification);
            container.appendChild(notificationElement);
        });
    }

    createNotificationElement(notification) {
        const div = document.createElement('div');
        div.className = `notification-item ${!notification.read ? 'unread' : ''} notification-slide`;
        div.innerHTML = `
            <div class="flex gap-3">
                <div class="flex-shrink-0">
                    <span class="material-icons text-${notification.type === 'warning' ? 'yellow' : notification.type === 'danger' ? 'red' : notification.type === 'success' ? 'green' : 'blue'}-500">
                        ${this.getNotificationIcon(notification.type)}
                    </span>
                </div>
                <div class="flex-1 min-w-0">
                    <div class="flex justify-between items-start mb-1">
                        <h4 class="font-semibold text-sm truncate">${notification.title}</h4>
                        <span class="text-xs text-gray-500 whitespace-nowrap">${this.formatTime(notification.timestamp)}</span>
                    </div>
                    <p class="text-sm text-gray-600 dark:text-gray-300 mb-2">${notification.message}</p>
                    <div class="flex gap-2">
                        <button onclick="notificationManager.markAsRead(${notification.id}, event)" class="text-xs text-primary hover:underline">
                            Mark as read
                        </button>
                        <button onclick="notificationManager.handleNotificationAction(${notification.id}, event)" class="text-xs text-green-600 hover:underline">
                            View details
                        </button>
                    </div>
                </div>
            </div>
        `;
        return div;
    }

    getNotificationIcon(type) {
        const icons = {
            warning: 'warning',
            danger: 'error',
            info: 'info',
            success: 'check_circle'
        };
        return icons[type] || 'notifications';
    }

    formatTime(timestamp) {
        const now = new Date();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);

        if (minutes < 1) return 'Just now';
        if (minutes < 60) return `${minutes}m ago`;
        if (hours < 24) return `${hours}h ago`;
        return `${days}d ago`;
    }

    toggleDropdown() {
        const dropdown = document.getElementById('notificationDropdown');
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        // Close user dropdown when opening notifications
        document.getElementById('userDropdown').style.display = 'none';
    }

    markAsRead(id, event) {
        if (event) event.stopPropagation(); // Prevent dropdown from closing
        
        const notification = this.notifications.find(n => n.id === id);
        if (notification && !notification.read) {
            notification.read = true;
            this.updateUnreadCount();
            this.renderNotifications();
        }
    }

    markAllAsRead() {
        this.notifications.forEach(notification => {
            notification.read = true;
        });
        this.updateUnreadCount();
        this.renderNotifications();
        // No SweetAlert - just silently mark as read
    }

    clearAllNotifications() {
        Swal.fire({
            title: 'Clear all notifications?',
            text: 'This action cannot be undone',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, clear all',
            cancelButtonText: 'Cancel',
            background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
            color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
        }).then((result) => {
            if (result.isConfirmed) {
                this.notifications = [];
                this.updateUnreadCount();
                this.renderNotifications();
            }
        });
    }

    handleNotificationAction(id, event) {
        if (event) event.stopPropagation(); // Prevent dropdown from closing
        
        const notification = this.notifications.find(n => n.id === id);
        if (notification) {
            this.markAsRead(id);
            this.toggleDropdown();
            
            // Navigate based on notification action
            switch(notification.action) {
                case 'inventory':
                    window.location.href = 'inventory_admin.html';
                    break;
                case 'prescriptions':
                    // Navigate to prescriptions page
                    break;
                case 'reports':
                    openReportModal();
                    break;
                default:
                    console.log('Notification action:', notification.action);
            }
        }
    }

    addNotification(notification) {
        const newNotification = {
            id: Date.now(),
            ...notification,
            timestamp: new Date(),
            read: false
        };
        this.notifications.unshift(newNotification);
        this.updateUnreadCount();
        this.renderNotifications();
        
        // Show desktop notification if supported and permission granted
        this.showDesktopNotification(newNotification);
    }

    showDesktopNotification(notification) {
        if (!('Notification' in window)) return;
        
        // Only show desktop notification if permission is already granted
        if (Notification.permission === 'granted') {
            new Notification(notification.title, {
                body: notification.message,
                icon: '/favicon.ico',
                tag: 'pharmacare-notification'
            });
        }
    }

    setupEventListeners() {
        document.getElementById('notificationBtn').addEventListener('click', () => {
            this.toggleDropdown();
            // Only ask for permission when user interacts with notifications
            this.requestNotificationPermission();
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (event) => {
            const dropdown = document.getElementById('notificationDropdown');
            const button = document.getElementById('notificationBtn');
            if (!button.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        });
    }

    requestNotificationPermission() {
        // Only ask once per session
        if (this.permissionAsked || !('Notification' in window)) return;
        
        if (Notification.permission === 'default') {
            this.permissionAsked = true;
            
            // Show custom permission request instead of browser's native one
            Swal.fire({
                title: 'Enable Browser Notifications?',
                text: 'Get real-time alerts even when you\'re not on the dashboard',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Enable',
                cancelButtonText: 'Not Now',
                background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
                color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
            }).then((result) => {
                if (result.isConfirmed) {
                    // Only request browser permission if user agrees
                    Notification.requestPermission().then(permission => {
                        if (permission === 'granted') {
                            Swal.fire({
                                title: 'Notifications Enabled!',
                                text: 'You\'ll now receive browser notifications',
                                icon: 'success',
                                timer: 2000,
                                showConfirmButton: false
                            });
                        }
                    });
                }
            });
        }
    }

    startAutoRefresh() {
        // Simulate new notifications every 2 minutes
        setInterval(() => {
            if (Math.random() > 0.7) { // 30% chance of new notification
                const sampleNotifications = [
                    {
                        type: 'info',
                        title: 'System Update',
                        message: 'New system features are available',
                        action: 'system'
                    },
                    {
                        type: 'warning',
                        title: 'Backup Reminder',
                        message: 'Weekly system backup is scheduled for tonight',
                        action: 'system'
                    }
                ];
                const randomNotification = sampleNotifications[Math.floor(Math.random() * sampleNotifications.length)];
                this.addNotification(randomNotification);
            }
        }, 120000); // 2 minutes
    }

    loadMoreNotifications() {
        // In a real app, this would load more notifications from server
        // No SweetAlert for this action
    }
}

// Initialize Notification Manager
const notificationManager = new NotificationManager();

// User Dropdown Management
function setupUserDropdown() {
    const userBtn = document.getElementById('userBtn');
    const userDropdown = document.getElementById('userDropdown');

    userBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        userDropdown.style.display = userDropdown.style.display === 'block' ? 'none' : 'block';
        // Close notification dropdown when opening user dropdown
        document.getElementById('notificationDropdown').style.display = 'none';
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', () => {
        userDropdown.style.display = 'none';
    });

    // Prevent dropdown from closing when clicking inside
    userDropdown.addEventListener('click', (e) => {
        e.stopPropagation();
    });
}

// Logout Function
function logoutUser() {
    Swal.fire({
        title: 'Logout Confirmation',
        text: 'Are you sure you want to log out?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, log out',
        cancelButtonText: 'Cancel',
        background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
        color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
    }).then((result) => {
        if (result.isConfirmed) {
            // Clear session data
            sessionStorage.removeItem('currentUser');
            // Redirect to login page
            window.location.href = '../login.html';
        }
    });
}

// Back to HMS Confirmation
function confirmBackToHMS(event) {
    event.preventDefault();
    Swal.fire({
        title: 'Leave Admin Panel?',
        text: 'Are you sure you want to go back to the Hospital Management System?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, go back',
        cancelButtonText: 'Stay here',
        background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
        color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../assets/html/login.html';
        }
    });
}

// Add a demo notification after page load
setTimeout(() => {
    notificationManager.addNotification({
        type: 'info',
        title: 'Welcome to PharmaCare',
        message: 'Your admin dashboard is ready with new features',
        action: 'dashboard'
    });
}, 2000);

// Initialize user dropdown
document.addEventListener('DOMContentLoaded', function() {
    setupUserDropdown();
    
    // Initialize button event listeners
    document.getElementById('generateReportBtn').addEventListener('click', openReportModal);
    document.getElementById('viewDetailsBtn').addEventListener('click', openAnalyticsModal);
    document.getElementById('dateRange').addEventListener('change', toggleCustomDateRange);
});

// Report Functions
function openReportModal() {
    document.getElementById('reportModal').style.display = 'block';
}

function closeReportModal() {
    document.getElementById('reportModal').style.display = 'none';
}

function toggleCustomDateRange() {
    const dateRangeSelect = document.getElementById('dateRange');
    const customDateRange = document.getElementById('customDateRange');
    
    if (dateRangeSelect.value === 'custom') {
        customDateRange.classList.remove('hidden');
    } else {
        customDateRange.classList.add('hidden');
    }
}

function generateReport() {
    const reportType = document.getElementById('reportType').value;
    const dateRange = document.getElementById('dateRange').value;
    const format = document.querySelector('input[name="format"]:checked').value;
    
    // Show loading state
    const generateBtn = document.querySelector('#reportModal button:first-child');
    const originalText = generateBtn.innerHTML;
    generateBtn.innerHTML = '<span class="material-icons loading">autorenew</span> Generating...';
    generateBtn.disabled = true;
    
    // Simulate report generation
    setTimeout(() => {
        // Show success message
        Swal.fire({
            title: 'Report Generated!',
            text: `${format.toUpperCase()} report has been generated successfully.`,
            icon: 'success',
            confirmButtonText: 'Download',
            showCancelButton: true,
            cancelButtonText: 'Close',
            background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
            color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
        }).then((result) => {
            if (result.isConfirmed) {
                // Simulate download
                simulateDownload(reportType, format);
            }
        });
        
        // Reset button
        generateBtn.innerHTML = originalText;
        generateBtn.disabled = false;
        closeReportModal();
    }, 2000);
}

function simulateDownload(reportType, format) {
    const link = document.createElement('a');
    link.download = `${reportType}_report_${new Date().toISOString().split('T')[0]}.${format}`;
    link.href = '#'; // In real app, this would be the actual file URL
    link.click();
    
    Swal.fire({
        title: 'Download Started!',
        text: 'Your report download has begun.',
        icon: 'info',
        timer: 2000,
        showConfirmButton: false,
        background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
        color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
    });
}

// Analytics Functions
function openAnalyticsModal() {
    document.getElementById('analyticsModal').style.display = 'block';
}

function closeAnalyticsModal() {
    document.getElementById('analyticsModal').style.display = 'none';
}

function exportAnalytics() {
    Swal.fire({
        title: 'Export Analytics Data',
        text: 'Choose export format:',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Excel',
        cancelButtonText: 'PDF',
        showDenyButton: true,
        denyButtonText: 'CSV',
        background: document.documentElement.classList.contains('dark') ? '#1F2937' : '#ffffff',
        color: document.documentElement.classList.contains('dark') ? '#F9FAFB' : '#1F2937',
    }).then((result) => {
        if (result.isConfirmed) {
            simulateDownload('analytics', 'excel');
        } else if (result.dismiss === Swal.DismissReason.cancel) {
            simulateDownload('analytics', 'pdf');
        } else if (result.isDenied) {
            simulateDownload('analytics', 'csv');
        }
    });
}

// Print Dashboard
function printDashboard() {
    window.print();
}

// Close modals on outside click
window.addEventListener('click', (event) => {
    const reportModal = document.getElementById('reportModal');
    const analyticsModal = document.getElementById('analyticsModal');
    
    if (event.target === reportModal) {
        closeReportModal();
    }
    if (event.target === analyticsModal) {
        closeAnalyticsModal();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (event) => {
    if (event.ctrlKey && event.key === 'p') {
        event.preventDefault();
        printDashboard();
    }
    if (event.key === 'Escape') {
        closeReportModal();
        closeAnalyticsModal();
    }
});

// Initialize with today's date for custom range
const today = new Date().toISOString().split('T')[0];
const oneWeekAgo = new Date();
oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
const oneWeekAgoStr = oneWeekAgo.toISOString().split('T')[0];

document.getElementById('startDate').value = oneWeekAgoStr;
document.getElementById('endDate').value = today;