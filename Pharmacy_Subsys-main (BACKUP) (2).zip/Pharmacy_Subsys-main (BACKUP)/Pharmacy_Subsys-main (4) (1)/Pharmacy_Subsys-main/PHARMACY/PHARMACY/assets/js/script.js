function sendEmail(order, notes) {
  // Simple test email first
  const templateParams = {
    to_email: 'jercasinginan@gmail.com',
    to_name: 'Jer Casinginan',
    from_name: 'PharmaCare PMS',
    subject: 'Test from PharmaCare',
    message: 'This is a test email from the supplier management system.',
    order_id: 'TEST123',
    medicine_name: 'Test Medicine'
  };

  console.log('Sending test email with service:', 'service_pzibd67');
  console.log('Template ID:', 'template_udbte6d');
  console.log('Parameters:', templateParams);

  emailjs.send('service_pzibd67', 'template_udbte6d', templateParams)
    .then(function(response) {
      console.log('SUCCESS!', response);
      showToast('Email sent successfully!', 'success');
    }, function(error) {
      console.log('FAILED...', error);
      
      // Try with default EmailJS template
      sendWithDefaultTemplate();
    });
}

function sendWithDefaultTemplate() {
  // Use the default template that comes with EmailJS
  const templateParams = {
    to_name: 'Jer Casinginan',
    from_name: 'PharmaCare PMS',
    message: 'This is a test using default template.'
  };

  emailjs.send('service_pzibd67', 'template_udbte6d', templateParams)
    .then(function(response) {
      console.log('Default template worked!', response);
      showToast('Email sent with default template!', 'success');
    }, function(error) {
      console.log('Default template also failed:', error);
      showToast(`Email failed: ${error.status} - Check EmailJS setup`, 'error');
    });
}