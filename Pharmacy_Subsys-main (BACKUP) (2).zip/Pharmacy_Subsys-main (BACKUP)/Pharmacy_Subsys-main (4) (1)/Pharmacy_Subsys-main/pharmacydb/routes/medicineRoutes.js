import express from 'express';
import Medicine from '../models/Medicine.js';

const router = express.Router();

// @route   POST /api/medicines
// @desc    Add a new medicine
router.post('/', async (req, res) => {
  try {
    const { name, genericName, type, strength, manufacturer, requiresPrescription } =
      req.body;

    const newMedicine = new Medicine({
      name,
      genericName,
      type,
      strength,
      manufacturer, // This will be the ObjectId of the manufacturer
      requiresPrescription,
    });

    const medicine = await newMedicine.save();
    res.status(201).json(medicine);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

export default router;