import express from 'express';
import { protect, admin } from '../middleware/authMiddleware.js';
import Patient from '../models/Patient.js';
import { getNextSequenceValue, formatPatientId } from '../utils/counters.js';
const router = express.Router();

// @route   POST /api/patients
// @desc    Create a new patient
// @access  Private/Admin
router.post('/', protect, admin, async (req, res) => {
  try {
    // --- UPDATED ---
    const { name, address, contactNo, age, gender, allergies, status } = req.body;
    
    const nextId = await getNextSequenceValue('patientId');
    const newPatientId = formatPatientId(nextId);

    const patient = await Patient.create({
      patientId: newPatientId,
      name,
      address,
      contactNo,
      age,
      gender,
      allergies: allergies || [],
      status: status || 'active', // <-- ADDED THIS
    });
    res.status(201).json(patient);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   GET /api/patients
// @desc    Get all patients (for your front-end to use)
// @access  Private/Admin
router.get('/', protect, admin, async (req, res) => {
  try {
    const { search } = req.query;
    let query = {};

    if (search) {
      query = {
        name: { $regex: search, $options: 'i' }, // Case-insensitive search by name
      };
    }
    
    const patients = await Patient.find(query);
    res.json(patients);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

export default router;