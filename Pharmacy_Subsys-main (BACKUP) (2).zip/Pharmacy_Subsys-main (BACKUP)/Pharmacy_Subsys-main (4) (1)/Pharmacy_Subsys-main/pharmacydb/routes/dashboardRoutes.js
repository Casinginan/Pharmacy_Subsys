import express from 'express';
import { protect, admin } from '../middleware/authMiddleware.js';
import Inventory from '../models/Inventory.js';
import Sale from '../models/Sale.js';
import Prescription from '../models/Prescription.js';

const router = express.Router();

// @route   GET /api/dashboard/stats
// @desc    Get all dashboard summary stats
// @access  Private/Admin
router.get('/stats', protect, admin, async (req, res) => {
  try {
    // --- 1. Inventory Stats ---
    const totalItems = await Inventory.countDocuments();
    const outOfStock = await Inventory.countDocuments({ quantity: 0 });
    
    // Low stock threshold (e.g., <= 10 items)
    const lowStock = await Inventory.countDocuments({ 
      quantity: { $gt: 0, $lte: 10 } 
    });
    
    // Expiring soon (e.g., within the next 30 days)
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
    const expiringSoon = await Inventory.countDocuments({
      expiryDate: { $lte: thirtyDaysFromNow }
    });

    // --- 2. Sales Stats ---
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0); // Start of today
    
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999); // End of today

    const todaySales = await Sale.find({
      createdAt: { $gte: todayStart, $lte: todayEnd }
    });
    
    const todayRevenue = todaySales.reduce((acc, sale) => acc + sale.totalAmount, 0);
    const todayTransactions = todaySales.length;
    const avgTransaction = todayTransactions > 0 ? todayRevenue / todayTransactions : 0;

    // --- 3. Prescription Stats ---
    const todayPrescriptions = await Prescription.find({
      createdAt: { $gte: todayStart, $lte: todayEnd }
    });
    
    const pendingReview = await Prescription.countDocuments({
        isFilled: false,
        createdAt: { $gte: todayStart, $lte: todayEnd }
    });
    
    // You might need a "Ready for Pickup" status, but for now we'll use "Filled"
    const readyForPickup = await Prescription.countDocuments({
        isFilled: true,
        createdAt: { $gte: todayStart, $lte: todayEnd }
    });

    // --- 4. Send all stats in one response ---
    res.json({
      inventory: {
        totalItems,
        outOfStock,
        lowStock,
        expiringSoon
      },
      sales: {
        todayRevenue,
        todayTransactions,
        avgTransaction
      },
      prescriptions: {
        todayTotal: todayPrescriptions.length,
        pendingReview,
        readyForPickup
      }
    });

  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

export default router;