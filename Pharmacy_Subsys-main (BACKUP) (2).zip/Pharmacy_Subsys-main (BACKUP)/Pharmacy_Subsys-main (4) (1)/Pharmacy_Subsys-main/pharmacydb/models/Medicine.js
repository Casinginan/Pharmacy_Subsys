import mongoose, { version } from 'mongoose';

const medicineSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    genericName: {
      type: String,
    },
    type: {
      type: String, // e.g., 'Tablet', 'Syrup', 'Ointment'
      required: true,
    },
    strength: {
      type: String, // e.g., '500mg', '10mg/5ml'
    },
    manufacturer: {
      type: mongoose.Schema.Types.ObjectId, // This is a reference
      ref: 'Manufacturer', // Tells Mongoose which model to connect to
      required: true,
    },
    requiresPrescription: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true },
  {versionKey: false}
);

const Medicine = mongoose.model('Medicine', medicineSchema);

export default Medicine;