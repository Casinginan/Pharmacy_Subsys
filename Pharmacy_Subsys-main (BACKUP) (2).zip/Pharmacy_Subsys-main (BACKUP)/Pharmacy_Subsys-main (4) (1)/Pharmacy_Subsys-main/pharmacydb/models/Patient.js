import mongoose from 'mongoose';

const patientSchema = new mongoose.Schema(
  {
    patientId: {
      type: String,
      unique: true,
      required: true, // Makes sure the friendly ID is always there
    },
    name: {
      type: String,
      required: true, // Makes sure 'name' is not undefined
    },
    address: { 
      type: String 
    },
    contactNo: { 
      type: String, 
      required: true, // Makes sure 'contactNo' is not undefined
    },
    age: { 
      type: Number, 
      required: true, // Makes sure 'age' is not undefined
    },
    gender: { 
      type: String, 
      required: true, // Makes sure 'gender' is not undefined
    },
    allergies: {
      type: [String], // An array of strings
      default: [],    // Defaults to an empty list
    },
    status: {
      type: String,
      enum: ['active', 'inactive'],
      default: 'active',
    }
  },
  { timestamps: true }
);

const Patient = mongoose.model('Patient', patientSchema);
export default Patient;