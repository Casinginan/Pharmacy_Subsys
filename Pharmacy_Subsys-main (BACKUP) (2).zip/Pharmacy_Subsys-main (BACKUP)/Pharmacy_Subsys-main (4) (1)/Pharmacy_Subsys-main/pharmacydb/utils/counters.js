import mongoose from 'mongoose';

// Define the schema for the counters collection
const counterSchema = new mongoose.Schema({
  _id: { type: String, required: true },
  sequence_value: { type: Number, default: 0 }
});

const Counter = mongoose.model('Counter', counterSchema);

// This function safely finds and increments the counter
export async function getNextSequenceValue(sequenceName) {
  const sequenceDocument = await Counter.findByIdAndUpdate(
    sequenceName,
    { $inc: { sequence_value: 1 } },
    { new: true, upsert: true } // 'new: true' returns the updated doc, 'upsert' creates it if it doesn't exist
  );
  return sequenceDocument.sequence_value;
}

// Function to format the ID
export function formatPatientId(sequenceNumber) {
    return `P${String(sequenceNumber).padStart(3, '0')}`; // Formats 1 -> P001, 10 -> P010
}