import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import Sale from '../models/Sale.js';
import Prescription from '../models/Prescription.js';
import Inventory from '../models/Inventory.js';

const router = express.Router();

// @route   GET /api/dashboard/stats
// @desc    Get Comprehensive Dashboard Metrics
router.get('/stats', protect, async (req, res) => {
    try {
        const todayStart = new Date();
        todayStart.setHours(0, 0, 0, 0);
        const todayEnd = new Date();
        todayEnd.setHours(23, 59, 59, 999);

        // --- 1. SALES METRICS (Today) ---
        const salesStats = await Sale.aggregate([
            { $match: { createdAt: { $gte: todayStart, $lte: todayEnd } } },
            { $group: { 
                _id: null, 
                totalRevenue: { $sum: "$totalAmount" },
                count: { $sum: 1 } 
            }}
        ]);
        const revenue = salesStats.length > 0 ? salesStats[0].totalRevenue : 0;
        const transactions = salesStats.length > 0 ? salesStats[0].count : 0;

        // --- 2. PRESCRIPTION METRICS ---
        // Created Today
        const rxToday = await Prescription.countDocuments({ 
            createdAt: { $gte: todayStart, $lte: todayEnd } 
        });
        // Status: Pending (All time)
        const rxPending = await Prescription.countDocuments({ 
            $or: [{ status: 'Pending' }, { status: { $exists: false } }, { status: '' }]
        });
        // Status: Dispensed/Ready (Today)
        const rxReady = await Prescription.countDocuments({ 
            status: 'Dispensed',
            createdAt: { $gte: todayStart, $lte: todayEnd }
        });

        // --- 3. INVENTORY METRICS ---
        const totalStock = await Inventory.countDocuments({ isArchived: false });
        
        // Low Stock (Quantity <= MinStockLevel)
        const lowStock = await Inventory.countDocuments({
            $expr: { $lte: ["$quantity", "$minStockLevel"] },
            isArchived: false
        });

        // Expiring Soon (Next 30 Days)
        const thirtyDaysFromNow = new Date();
        thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
        const expiring = await Inventory.countDocuments({
            expiryDate: { $lte: thirtyDaysFromNow, $gte: new Date() },
            isArchived: false
        });

        res.json({
            sales: { revenue, transactions, average: transactions > 0 ? Math.round(revenue / transactions) : 0 },
            prescriptions: { today: rxToday, pending: rxPending, ready: rxReady },
            inventory: { total: totalStock, low: lowStock, expiring: expiring }
        });

    } catch (err) {
        console.error("Dashboard Stats Error:", err);
        res.status(500).json({ message: 'Server Error' });
    }
});

export default router;