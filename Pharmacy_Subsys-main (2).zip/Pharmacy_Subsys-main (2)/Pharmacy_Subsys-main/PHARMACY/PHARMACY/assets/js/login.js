tailwind.config = {
    darkMode: "class",
    theme: {
        extend: {
            colors: {
                primary: "#358E83", // Updated primary color
                "background-light": "#F0FDF4",
                "background-dark": "#18181B",
                "surface-light": "#FFFFFF",
                "surface-dark": "#27272A",
                "text-light": "#333333",
                "text-dark": "#E4E4E7",
                "muted-light": "#6B7280",
                "muted-dark": "#A1A1AA",
                "border-light": "#E5E7EB",
                "border-dark": "#3F3F46"
            },
            fontFamily: {
                display: ["Poppins", "sans-serif"],
            },
            borderRadius: {
                DEFAULT: "0.5rem",
            },
        },
    },
};

// In login.js or your login page script
function handleLogin(email, password) {
    // Your authentication logic here...
    const userData = {
        id: 1,
        name: "Dr. Smith",
        role: "Pharmacist",
        email: "dr.smith@pharmacare.com",
        department: "Pharmacy",
        permissions: ["view_inventory", "manage_prescriptions", "view_reports"],
        lastLogin: new Date().toISOString()
    };

    if (AuthManager.loginUser(userData)) {
        window.location.href = '../Admin/dashboard_admin.html';
    } else {
        alert('Login failed. Please try again.');
    }
}