tailwind.config = {
    darkMode: "class",
    theme: {
        extend: {
            colors: {
                primary: "#007A7A", // A deep teal for a professional, healthcare feel
                "background-light": "#F0F7F7", // Light teal background
                "background-dark": "#0A1919", // Very dark teal background
                "surface-light": "#FFFFFF",
                "surface-dark": "#112222", // Dark teal surface
                "text-light": "#0D1A1A", // Dark teal text
                "text-dark": "#E0F2F2", // Light teal text
                "subtext-light": "#4D6969", // Muted teal text
                "subtext-dark": "#80B3B3", // Lighter muted teal text
            },
            fontFamily: {
                sans: ['Inter', 'sans-serif'],
            },
            borderRadius: {
                'lg': '0.75rem',
                'xl': '1rem',
                '2xl': '1.5rem',
            },
        },
    },
};