// Tailwind Configuration
tailwind.config = {
    darkMode: "class",
    theme: {
        extend: {
            colors: {
                primary: "#007A7A",
                "background-light": "#F0F7F7",
                "background-dark": "#0A1919",
                "surface-light": "#FFFFFF",
                "surface-dark": "#112222",
                "text-light": "#0D1A1A",
                "text-dark": "#E0F2F2",
                "subtext-light": "#4D6969",
                "subtext-dark": "#80B3B3",
            },
            fontFamily: {
                sans: ['Inter', 'sans-serif'],
            },
            borderRadius: {
                'lg': '0.75rem',
                'xl': '1rem',
                '2xl': '1.5rem',
            },
        },
    },
};

// ==================== DATA ====================
let transactions = [
    { id: 1, date: '2024-01-23', patientId: 'PID-00123', medicine: 'Paracetamol', amount: 10.50, status: 'Paid' },
    { id: 2, date: '2024-01-22', patientId: 'PID-00122', medicine: 'Amoxicillin', amount: 25.00, status: 'Pending' },
    { id: 3, date: '2024-01-21', patientId: 'PID-00121', medicine: 'Ibuprofen', amount: 8.25, status: 'Failed' },
    { id: 4, date: '2024-01-20', patientId: 'PID-00120', medicine: 'Aspirin', amount: 5.50, status: 'Paid' },
    { id: 5, date: '2024-01-19', patientId: 'PID-00119', medicine: 'Omeprazole', amount: 18.75, status: 'Paid' },
    { id: 6, date: '2024-01-18', patientId: 'PID-00118', medicine: 'Metformin', amount: 13.65, status: 'Paid' }
];

let filteredTransactions = [...transactions];
let currentSort = { field: null, ascending: true };
let selectedTransaction = null;
let statusFilters = ['all'];

// ==================== RENDERING ====================
function renderTransactions() {
    const tbody = document.getElementById('transactionsTableBody');
    const noResults = document.getElementById('noResults');
    
    if (filteredTransactions.length === 0) {
        tbody.innerHTML = '';
        noResults.classList.remove('hidden');
        return;
    }
    
    noResults.classList.add('hidden');
    tbody.innerHTML = filteredTransactions.map(t => `
        <tr class="border-b border-primary/10 dark:border-primary/20 hover:bg-primary/5 dark:hover:bg-primary/10 transition-colors">
            <td class="px-6 py-4">${formatDate(t.date)}</td>
            <td class="px-6 py-4">${t.patientId}</td>
            <td class="px-6 py-4">${t.medicine}</td>
            <td class="px-6 py-4">₱${t.amount.toFixed(2)}</td>
            <td class="px-6 py-4">
                <span class="px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(t.status)}">${t.status}</span>
            </td>
            <td class="px-6 py-4">
                <button onclick="showTransactionDetails(${t.id})" class="text-subtext-light dark:text-subtext-dark hover:text-primary transition-colors">
                    <span class="material-icons text-base">more_vert</span>
                </button>
            </td>
        </tr>
    `).join('');
    
    updateStats();
}

function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function getStatusClass(status) {
    switch(status) {
        case 'Paid': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
        case 'Pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
        case 'Failed': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
        default: return '';
    }
}

function updateStats() {
    const today = new Date().toISOString().split('T')[0];
    const todayTransactions = transactions.filter(t => t.date === today);
    const todaysSales = todayTransactions.reduce((sum, t) => t.status === 'Paid' ? sum + t.amount : sum, 0);
    
    const paidTransactions = transactions.filter(t => t.status === 'Paid');
    const totalRevenue = paidTransactions.reduce((sum, t) => sum + t.amount, 0);
    
    document.getElementById('todaysSales').textContent = `₱${todaysSales.toFixed(2)}`;
    document.getElementById('totalTransactions').textContent = transactions.length;
    document.getElementById('totalRevenue').textContent = `₱${totalRevenue.toFixed(2)}`;
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    const yesterdayTransactions = transactions.filter(t => t.date === yesterdayStr);
    const yesterdaysSales = yesterdayTransactions.reduce((sum, t) => t.status === 'Paid' ? sum + t.amount : sum, 0);
    
    let change = 0;
    if (yesterdaysSales > 0) {
        change = ((todaysSales - yesterdaysSales) / yesterdaysSales * 100).toFixed(0);
    } else if (todaysSales > 0) {
        change = 100;
    }
    
    document.getElementById('todaysChange').textContent = `${change >= 0 ? '+' : ''}${change}% from yesterday`;
}

// ==================== SORTING ====================
function sortTable(field) {
    if (currentSort.field === field) {
        currentSort.ascending = !currentSort.ascending;
    } else {
        currentSort.field = field;
        currentSort.ascending = true;
    }
    
    filteredTransactions.sort((a, b) => {
        let aVal = a[field];
        let bVal = b[field];
        
        if (field === 'amount') {
            aVal = parseFloat(aVal);
            bVal = parseFloat(bVal);
        } else if (field === 'date') {
            aVal = new Date(aVal);
            bVal = new Date(bVal);
        } else {
            aVal = aVal.toString().toLowerCase();
            bVal = bVal.toString().toLowerCase();
        }
        
        if (aVal < bVal) return currentSort.ascending ? -1 : 1;
        if (aVal > bVal) return currentSort.ascending ? 1 : -1;
        return 0;
    });
    
    renderTransactions();
}

// ==================== FILTERING ====================
function filterTransactions() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    filteredTransactions = transactions.filter(t => {
        const matchesSearch = t.patientId.toLowerCase().includes(searchTerm) ||
                            t.medicine.toLowerCase().includes(searchTerm);
        
        const matchesStatus = statusFilters.includes('all') || statusFilters.includes(t.status);
        
        return matchesSearch && matchesStatus;
    });
    
    renderTransactions();
}

function toggleDateFilter() {
    const panel = document.getElementById('dateFilterPanel');
    panel.classList.toggle('hidden');
    if (!panel.classList.contains('hidden')) {
        document.getElementById('statusFilterPanel').classList.add('hidden');
    }
}

function toggleStatusFilter() {
    const panel = document.getElementById('statusFilterPanel');
    panel.classList.toggle('hidden');
    if (!panel.classList.contains('hidden')) {
        document.getElementById('dateFilterPanel').classList.add('hidden');
    }
}

function clearDateFilter() {
    document.getElementById('fromDate').value = '';
    document.getElementById('toDate').value = '';
    filteredTransactions = [...transactions];
    renderTransactions();
}

function applyDateFilter() {
    const fromDate = document.getElementById('fromDate').value;
    const toDate = document.getElementById('toDate').value;

    filteredTransactions = transactions.filter(t => {
        const tDate = new Date(t.date);
        return (!fromDate || tDate >= new Date(fromDate)) &&
               (!toDate || tDate <= new Date(toDate));
    });

    renderTransactions();
    toggleDateFilter();
}

function handleStatusFilter(checkbox) {
    if (checkbox.value === "all" && checkbox.checked) {
        document.querySelectorAll('#statusFilterPanel input[type="checkbox"]').forEach(cb => {
            if (cb.value !== "all") cb.checked = false;
        });
        statusFilters = ['all'];
    } else {
        document.querySelector('#statusFilterPanel input[value="all"]').checked = false;
        const checked = Array.from(document.querySelectorAll('#statusFilterPanel input[type="checkbox"]:checked')).map(cb => cb.value);
        statusFilters = checked.length > 0 ? checked : ['all'];
    }
    filterTransactions();
}

// ==================== MODAL HANDLING ====================
function showNewTransactionModal() {
    document.getElementById('newTransactionModal').classList.remove('hidden');
}

function closeNewTransactionModal() {
    document.getElementById('newTransactionModal').classList.add('hidden');
    document.getElementById('newTransactionForm').reset();
}

function addTransaction(event) {
    event.preventDefault();
    const id = transactions.length ? transactions[transactions.length - 1].id + 1 : 1;
    const newT = {
        id,
        date: new Date().toISOString().split('T')[0],
        patientId: document.getElementById('newPatientId').value,
        medicine: document.getElementById('newMedicine').value,
        amount: parseFloat(document.getElementById('newAmount').value),
        status: document.getElementById('newStatus').value,
    };
    transactions.push(newT);
    filteredTransactions = [...transactions];
    renderTransactions();
    closeNewTransactionModal();
}

function showTransactionDetails(id) {
    selectedTransaction = transactions.find(t => t.id === id);
    const details = document.getElementById('transactionDetails');
    details.innerHTML = `
        <p><strong>Date:</strong> ${formatDate(selectedTransaction.date)}</p>
        <p><strong>Patient ID:</strong> ${selectedTransaction.patientId}</p>
        <p><strong>Medicine:</strong> ${selectedTransaction.medicine}</p>
        <p><strong>Amount:</strong> ₱${selectedTransaction.amount.toFixed(2)}</p>
        <p><strong>Status:</strong> ${selectedTransaction.status}</p>
    `;
    document.getElementById('transactionModal').classList.remove('hidden');
}

function closeTransactionModal() {
    document.getElementById('transactionModal').classList.add('hidden');
}

function deleteTransaction() {
    if (!selectedTransaction) return;
    transactions = transactions.filter(t => t.id !== selectedTransaction.id);
    filteredTransactions = [...transactions];
    renderTransactions();
    closeTransactionModal();
}

function editTransaction() {
    if (!selectedTransaction) return;
    closeTransactionModal();
    showNewTransactionModal();
    document.getElementById('newPatientId').value = selectedTransaction.patientId;
    document.getElementById('newMedicine').value = selectedTransaction.medicine;
    document.getElementById('newAmount').value = selectedTransaction.amount;
    document.getElementById('newStatus').value = selectedTransaction.status;

    // Override submit
    const form = document.getElementById('newTransactionForm');
    form.onsubmit = function(e) {
        e.preventDefault();
        selectedTransaction.patientId = document.getElementById('newPatientId').value;
        selectedTransaction.medicine = document.getElementById('newMedicine').value;
        selectedTransaction.amount = parseFloat(document.getElementById('newAmount').value);
        selectedTransaction.status = document.getElementById('newStatus').value;
        renderTransactions();
        closeNewTransactionModal();
        form.onsubmit = addTransaction; // reset back
    }
}

// ==================== EXPORT FUNCTIONS ====================
function exportCSV() {
    let csv = "Date,Patient ID,Medicine,Amount,Status\n";
    transactions.forEach(t => {
        csv += `${t.date},${t.patientId},${t.medicine},${t.amount},${t.status}\n`;
    });
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "transactions.csv";
    a.click();
    URL.revokeObjectURL(url);
}

function exportPDF() {
    const printContent = document.getElementById('transactionsTableBody').innerHTML;
    const win = window.open("", "", "height=600,width=800");
    win.document.write("<h3>Sales & Billing Transactions</h3><table border='1'>" + printContent + "</table>");
    win.document.close();
    win.print();
}

// ==================== EVENT LISTENERS ====================
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('searchInput').addEventListener('input', filterTransactions);
    renderTransactions();
});

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        renderTransactions();
    });
} else {
    renderTransactions();
}

function deleteTransaction() {
  Swal.fire({
    title: "Delete Transaction?",
    text: "This action cannot be undone.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#007A7A", // ✅ teal like others
    cancelButtonColor: "#6B7280", // ✅ gray
    confirmButtonText: "Yes, delete it",
    cancelButtonText: "Cancel"
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: "Deleted!",
        text: "Transaction has been successfully deleted.",
        icon: "success",
        timer: 1500,
        showConfirmButton: false
      });

      // optional: close modal or refresh
      setTimeout(() => {
        const modal = document.getElementById('transactionModal');
        if (modal) modal.classList.add('hidden');
      }, 1500);
    }
  });
}
