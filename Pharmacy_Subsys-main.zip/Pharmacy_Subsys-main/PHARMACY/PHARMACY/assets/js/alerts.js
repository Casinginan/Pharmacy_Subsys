// ✅ alerts.js (constant alert badge count)

// --- Run when the page loads ---
document.addEventListener("DOMContentLoaded", () => {
  // Load saved alert count or set a default
  const savedCount = localStorage.getItem("alertCount");

  if (!savedCount) {
    // Set default alert count ONCE (e.g., 14)
    const defaultCount = 14;
    localStorage.setItem("alertCount", defaultCount);
    updateAlertCountDisplay(defaultCount);
  } else {
    updateAlertCountDisplay(savedCount);
  }
});

// --- Function to update the alert badge everywhere ---
function updateAlertCountDisplay(count = localStorage.getItem("alertCount")) {
  const navBadge = document.getElementById("navAlertCount");
  if (navBadge) {
    navBadge.textContent = count > 0 ? count : "";
    navBadge.style.display = count > 0 ? "inline-block" : "none";
  }

  const activeLabel = document.getElementById("activeAlertCount");
  if (activeLabel) activeLabel.textContent = `${count} Active Alerts`;
}

// --- Optional: Function to manually update or change alert count ---
function setAlertCount(newCount) {
  localStorage.setItem("alertCount", newCount);
  updateAlertCountDisplay(newCount);
}

// Example: Call `setAlertCount(20)` anywhere in your code to change it.
