// auth-manager.js - Centralized Authentication Manager
class AuthManager {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    init() {
        this.loadUserData();
        this.setupEventListeners();
    }

    loadUserData() {
        try {
            const userData = localStorage.getItem('pharmacyCurrentUser');
            const sessionData = sessionStorage.getItem('pharmacySession');
            
            if (userData && sessionData) {
                this.currentUser = JSON.parse(userData);
                this.updateUI();
            } else {
                this.redirectToLogin();
            }
        } catch (error) {
            console.error('Error loading user data:', error);
            this.redirectToLogin();
        }
    }

    setupEventListeners() {
        // Listen for storage changes (for multi-tab logout)
        window.addEventListener('storage', (e) => {
            if (e.key === 'pharmacySession' && !e.newValue) {
                this.handleLogout();
            }
        });
    }

    updateUI() {
        if (!this.currentUser) return;

        // Update user dropdown
        const userDropdown = document.getElementById('userDropdown');
        const userNameElement = document.getElementById('userName');
        const userRoleElement = document.getElementById('userRole');
        const userAvatarElement = document.getElementById('userAvatar');
        const sidebarUserName = document.getElementById('sidebarUserName');
        const sidebarUserRole = document.getElementById('sidebarUserRole');

        if (userNameElement) userNameElement.textContent = this.currentUser.name;
        if (userRoleElement) userRoleElement.textContent = this.currentUser.role;
        if (userAvatarElement) userAvatarElement.textContent = this.getInitials(this.currentUser.name);
        if (sidebarUserName) sidebarUserName.textContent = this.currentUser.name;
        if (sidebarUserRole) sidebarUserRole.textContent = this.currentUser.role;

        // Update avatar color based on role
        this.updateAvatarColor(this.currentUser.role);
    }

    getInitials(name) {
        return name.split(' ').map(n => n[0]).join('').toUpperCase();
    }

    updateAvatarColor(role) {
        const avatar = document.getElementById('userAvatar');
        if (!avatar) return;

        const colors = {
            'Pharmacist': 'bg-green-500',
            'Doctor': 'bg-blue-500',
            'Admin': 'bg-purple-500',
            'Technician': 'bg-orange-500'
        };

        // Remove existing color classes
        avatar.className = avatar.className.replace(/bg-\w+-\d+/g, '');
        
        // Add new color class
        avatar.classList.add(colors[role] || 'bg-primary');
    }

    handleLogout() {
        this.currentUser = null;
        localStorage.removeItem('pharmacyCurrentUser');
        sessionStorage.removeItem('pharmacySession');
        this.redirectToLogin();
    }

    redirectToLogin() {
        if (!window.location.href.includes('login.html')) {
            window.location.href = 'login.html';
        }
    }

    // Method to be called from login page
    static loginUser(userData) {
        try {
            localStorage.setItem('pharmacyCurrentUser', JSON.stringify(userData));
            sessionStorage.setItem('pharmacySession', 'active');
            return true;
        } catch (error) {
            console.error('Error saving user data:', error);
            return false;
        }
    }

    // Check if user is authenticated
    static isAuthenticated() {
        return !!(localStorage.getItem('pharmacyCurrentUser') && sessionStorage.getItem('pharmacySession'));
    }

    // Get current user info
    static getCurrentUser() {
        try {
            return JSON.parse(localStorage.getItem('pharmacyCurrentUser'));
        } catch {
            return null;
        }
    }
}

// Global instance
window.AuthManager = new AuthManager();